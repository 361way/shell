#!/bin/bash
output_dir=/var/log/log_collector
output_file=$output_dir/`hostname`_dfx_info

function comment
{
   echo " "
   echo " "
   echo -e "#------------------\t$1\t---------------------#" 
}
function host_name
{   comment "hostname"
    echo `hostname` 
}

function OS_type
{
    comment "OS type"
    [ -f /etc/SuSE-release ]&& cat /etc/SuSE-release 
}

function kernel_type
{
    comment "kernel type"
    uname -a
}
function blade_type
{
    comment "blade type"
    dmidecode | grep  Product | sed -n '$p' | awk '{print $NF}' 
}

function config_status
{
    ###VRET###
    comment "VRET configuration"
    if [ -f /opt/VRTSvcs/bin/triggers/resnotoff ];then
        if [ -f /etc/vret.conf ];then
            cat /etc/vret.conf 
        fi
    else
        echo "VRET is not installed !" 
    fi

    ###atop###
    comment "atop configuration"
    grep -q "ulimit -v" /etc/atop/atop.daily >/dev/null 2>&1
    if [ $? -eq 0 ];then
        cat /etc/atop/atop.daily  
        echo "###current running state"
        /etc/init.d/atop status 
        chkconfig -l | grep atop 
    else
        echo  "atop is not installed or version is too old !" 
    fi


    ###LKCD###
    comment "LKCD configuration"
    rpm -q lkcdutils >/dev/null 2>&1
    if [ $? -eq 0 ];then
        lkcd_config -q 
        echo "###current running state"
        cat /etc/sysconfig/dump | grep '^DUMP_ACTIVE' 
        chkconfig -l | grep lkcd 
    else
        echo "LKCD is not installed !" 
    fi

    ###KDUMP###
    comment "KDUMP configuration"
    grep "crashkernel" /boot/grub/menu.lst >/dev/null 2>&1
    if [ $? -eq 0 ];then
        cat /proc/cmdline 
        ps -ef | grep ttyS | grep -v grep 
        echo "###current running state" 
        /etc/init.d/kdump status 
        chkconfig -l | grep kdump 
    else
        echo "kdump is not installed !" 
    fi
    

    ###HPI###
    comment "HPI configuration"
    chkconfig -l | grep "^HPI" >/dev/null 2>&1
    if [ $? -eq 0 ];then
        echo "###current running state" 
        /opt/HPI/HPI_ALARM/HpiAlarm.sh status 
        chkconfig -l | grep '^HPI'
    else
        echo "HPI is not installed !" 
    fi
    
    ###AND###
    comment "AND configuration"
    if [ -f /opt/and/bin/and.py ];then
        cat /opt/and/conf/and.conf  2>&1
        echo "###current running state"
        /etc/init.d/and status 
        chkconfig -l | grep '^and' 
    else
        echo  "AND is not installed !" 
    fi

    ###KLU###
    comment "KLU configuration"
    if [ -f /usr/lrsp/klu/klu.ko -a -f /etc/klu.conf ];then
        cat /etc/klu.conf 
        echo "###current running state" 
        /etc/init.d/klu status  2>&1
        chkconfig -l | grep '^klu' 
    else
        echo "KLU is not installed !" 
    fi
    

    ###hang-handler###
    comment "hang-handler"
    if [ -f /etc/hang-handler.conf ];then
        cat /etc/hang-handler.conf  
        echo "###current running state" 
        /etc/init.d/hang-handler status 
        chkconfig -l | grep hang-handler 
    else
        echo "hang-handler is not installed !"      
    fi
}

function network_conf
{   
    comment "network configuration"
    echo "###eth_alias.sh" 
    /var/adm/autoinstall/scripts/eth_alias.sh 
    echo " " 
    echo " " 
    echo "###route table " 
    route 
    echo "###detail configuration " 
    ifconfig -a 
}
function log_collect
{
    ###atop
    ###no collection

    ###LKCD/KDUMP
    ###no collection

    ###HPI
    if [ -f /var/log/atae_hpi.log ];then
        comment "tail -300 /var/log/atae_hpi.log"
        echo "###only WARN level logs collected" 
        tail -300 /var/log/atae_hpi.log | grep "\[WARN\]" 

    fi

    ###AND

    if [ -f /var/log/and.log ];then
	comment "tail -300 /var/log/and.log"
        echo "### only ERROR level logs collected" 
        tail -500 /var/log/and.log | grep   ERROR 
    fi
    
    ###KLU
    if [ -e /var/log/dump/klu ];then
        comment "/var/log/dump/klu"
        echo "fore more details , cat the file listed " 
        echo "#ll /var/log/dump/klu " 
        ls /var/log/dump/klu 
    fi

    ###messages
    comment "tail -5000 /var/log/messages"
    tail -2000  /var/log/messages | grep -i -e "ERROR" -e "WARN" -e "1\.6\.8" -e warning -e fail 

}
function vcs_info
{
    rpm -qa | grep vcs 
    comment " vcs configuration"
    if [ $? -eq 0 ];then
        cat /etc/VRTSvcs/conf/config/main.cf  
    fi
}

function result_tips
{
    echo  "result: $output_file"
}



host_name
OS_type
kernel_type
blade_type
config_status
network_conf
vcs_info
log_collect

#result_tips





