#!/bin/bash

RUNPATH=$(cd `dirname $0` ;pwd)
LOG_DIR="/var/log/log_collector"

mkdir -p $LOG_DIR

function execute()
{
   command=$1
   log_file=$2
   $command >> $LOG_DIR/$log_file 2>&1
}

function execute_grep()
{
    command=$1
    grep_info=$2
    log_file=$3
    $command | grep $grep_info >> $LOG_DIR/$log_file 2>&1
}

function log_file()
{
   command=$1
   log_file=$2
   time=$(date +"%Y-%m-%d-%H:%M") 
   echo "----------$time execute $command result----------" >>$LOG_DIR/$log_file
   execute "$command" $log_file
   echo "" >>$LOG_DIR/$log_file
}

function log_file_grep()
{
   command=$1
   grep_info=$2
   log_file=$3
   time=$(date +"%Y-%m-%d-%H:%M")
   echo "----------$time execute $command | grep $grep_info result----------" >>$LOG_DIR/$log_file
   execute_grep "$command" "$grep_info" $log_file
   echo "" >>$LOG_DIR/$log_file
}

main ()
{
    #collect host infomation
    HOSTINFO_NAME="hostinfo.txt"
    rm $LOG_DIR/$HOSTINFO_NAME >/dev/null 2>&1
    [ -f $LOG_DIR/$HOSTINFO_NAME ] || touch $LOG_DIR/$HOSTINFO_NAME

    log_file "uname -a" $HOSTINFO_NAME
    log_file_grep "ls /etc" "ATAE" $HOSTINFO_NAME
    log_file_grep "dmidecode"  "Product" $HOSTINFO_NAME

    #collect net infomation
    NETINFO_NAME="netinfo.txt"
    rm $LOG_DIR/$NETINFO_NAME >/dev/null 2>&1
    [ -f $LOG_DIR/$NETINFO_NAME ] || touch $LOG_DIR/$NETINFO_NAME 
    
    log_file "ifconfig -a"  $NETINFO_NAME
    log_file "netstat -s"   $NETINFO_NAME
    log_file "cat /proc/net/bonding/bond*" $NETINFO_NAME

    #collect nic infomation
    for nic_name in $@ ;do
        NICINFO_NAME="${nic_name}info.txt"
        rm $LOG_DIR/$NICINFO_NAME >/dev/null 2>&1
        [ -f $LOG_DIR/$NICINFO_NAME ] || touch $LOG_DIR/$NICINFO_NAME
        
        log_file "ethtool $nic_name" $NICINFO_NAME
        log_file "ethtool -i $nic_name" $NICINFO_NAME
        log_file "ethtool -S $nic_name" $NICINFO_NAME
        log_file "ethtool -g $nic_name" $NICINFO_NAME
        log_file "ethtool -d $nic_name" $NICINFO_NAME
        log_file "ethtool -e $nic_name" $NICINFO_NAME
   done
}

main $@
