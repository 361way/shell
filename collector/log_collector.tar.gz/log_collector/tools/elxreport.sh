#!/bin/bash

#/*******************************************************************
# * This file is part of the Emulex Linux Device Driver for         *
# * Fibre Channel Host Bus Adapters.                                *
# * Copyright (C) 2004-2011 Emulex.  All rights reserved.           *
# * EMULEX and SLI are trademarks of Emulex.                        *
# * www.emulex.com                                                  *
# *                                                                 *
# * This program is free software; you can redistribute it and/or   *
# * modify it under the terms of version 2 of the GNU General       *
# * Public License as published by the Free Software Foundation.    *
# * This program is distributed in the hope that it will be useful. *
# * ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND          *
# * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,  *
# * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT, ARE      *
# * DISCLAIMED, EXCEPT TO THE EXTENT THAT SUCH DISCLAIMERS ARE HELD *
# * TO BE LEGALLY INVALID.  See the GNU General Public License for  *
# * more details, a copy of which can be found in the file COPYING  *
# * included with this package.                                     *
# *******************************************************************/
#
###########################################################################
#
#			    elxreport.sh
#	Utility that gathers system, HBA/UCNA and device driver/applications
#       information related to the functionality of Emulex Linux device 
#       drivers.
#       The intented users are Emulex customers with installed Linux device 
#       drivers.
#       This tool creates a zipped tar file which end customers will send 
#       to Emulex support for analysis.
#
#	Usage:
#		elxreport.sh [ -h | --help ]
#
#	Options:
#		-h, --help	Display this help message and exit.
#
###########################################################################

###########################################################################
# Constants
###########################################################################
PROGNAME=$(basename $0)
VERSION="1.6"

DATE=$(/bin/date +%m%d%y%H%M%S)
TOPDIR=/var/log/log_collector/${PROGNAME}
TMPDIR=${TOPDIR}/${PROGNAME}_${DATE}
TMPLOG=${TMPDIR}/${PROGNAME}.log
OS_REV=`uname -r | cut -c1-3`

###########################################################################
# Functions
###########################################################################

#
# Function to display usage message.
#
function usage()
{
	echo "Usage: ${PROGNAME} [-h | --help]"
	echo
	echo "Utility that gathers system, HBA/UCNA and device driver/applications"
        echo "information related to the functionality of Emulex Linux device drivers."
	echo "This tool creates a tarball file /var/log/log_collector/${PROGNAME}_<date>.tgz to be send" 
	echo "to Emulex support for analysis."
	echo
}

#
# Function to execute a shell command.
#
exec_cmd()
{
	echo "" >> $TMPLOG
	echo "Command: ${1} " >> $TMPLOG
	eval ${1}  >> $TMPLOG 2>&1
	echo "" >> $TMPLOG 
}

#
# Function to copy data to the log file.
#
exec_copy()
{
	echo "" >> $TMPLOG
	echo "Copying output from: ${1}" >> $TMPLOG
	
	if [ -f ${1} ] ; then 
		cp --parents ${1} $TMPDIR  >> $TMPLOG
	fi
	echo "" >> $TMPLOG
}

#
# Function to create temporary directories and files and display banner
# information.
#
init_files()
{
	# Must run as root
	if [ $UID != 0 ]; then
		echo "You must be logged on as root."
		exit 1
	fi

	# Create temp dir to store results
	rm -rf $TOPDIR
	mkdir -p $TMPDIR

	> $TMPLOG

	echo ""
	echo "Emulex Corporation - ELX Report Utility, version ${VERSION}" | tee -a $TMPLOG
	echo "Date:$(date)" | tee -a $TMPLOG

	echo "Initializing report environment for host:${HOSTNAME}" | tee -a $TMPLOG
}

#
# Function to clean-up temporary directories and files.
#
clean_up()
{
	rm -rf ${TOPDIR}
}

#
# instr p1 p2 - return 1 if p2 exists in p1 
#
instr()
{

let FOUND=0
for j in $2; do
   if [ $1 = $j ] ; then
      let FOUND=1
   fi
done

return $FOUND

}

#
# process_iosched C_DIR D_DIR parm
#
process_iosched()
{
local C_DIR
local D_DIR
local parm
local readok
local EXCLUDELIST
local RETURNVALUE

C_DIR="$1/$3"
D_DIR="$2-$3"

for parm in `ls $C_DIR` 
  do
        if  [ -d $C_DIR/$parm ] ; then 
            echo "$D_DIR: Unexpected directory found:$C_DIR/$parm"
        else 
    	    readok=`ls -l $C_DIR/$parm | cut -c2-2`
	    if  [ "$readok" = "r" ]  &&  [ ! -L $C_DIR/$parm ] && [ ! -d $C_DIR/$parm ] ; then 
		instr "$parm" "$EXCLUDELIST"
		RETURNVALUE=$?
		if [ ${RETURNVALUE} -eq 0 ]; then
		    echo "$D_DIR: $parm="`cat $C_DIR/$parm` >> $TMPLOG
		fi
            fi    
        fi
done
      
return
}

#
# process_queue C_DIR D_DIR parm
#
process_queue()
{
local C_DIR
local D_DIR
local parm
local readok
local EXCLUDELIST
local RETURNVALUE

C_DIR="$1/$3"
D_DIR="$2-$3"

for parm in `ls $C_DIR` 
  do
        if  [ -d $C_DIR/$parm ] ; then 
            if  [ "$parm" = "iosched" ]; then 
                process_iosched $C_DIR $D_DIR $parm
            fi
        else 
    	    readok=`ls -l $C_DIR/$parm | cut -c2-2`
	    if  [ "$readok" = "r" ]  &&  [ ! -L $C_DIR/$parm ] && [ ! -d $C_DIR/$parm ] ; then 
		instr "$parm" "$EXCLUDELIST"
		RETURNVALUE=$?
		if [ ${RETURNVALUE} -eq 0 ]; then
		    echo "$D_DIR: $parm="`cat $C_DIR/$parm` >> $TMPLOG
		fi
            fi    
        fi
done
      
return
}

#
# process_block C_DIR D_DIR parm
#
process_block()
{
local C_DIR
local D_DIR
local parm
local readok
local EXCLUDELIST
local RETURNVALUE

C_DIR="$1/$3"
D_DIR="$2-$3"

for parm in `ls $C_DIR` 
  do
        if  [ -d $C_DIR/$parm ] ; then 
            if  [ "$parm" = "queue" ]; then 
                process_queue $C_DIR $D_DIR $parm
            fi
        else 
    	    readok=`ls -l $C_DIR/$parm | cut -c2-2`
	    if  [ "$readok" = "r" ]  &&  [ ! -L $C_DIR/$parm ] && [ ! -d $C_DIR/$parm ] ; then 
		instr "$parm" "$EXCLUDELIST"
		RETURNVALUE=$?
		if [ ${RETURNVALUE} -eq 0 ]; then
		    echo "$D_DIR: $parm="`cat $C_DIR/$parm` >> $TMPLOG
		fi
            fi    
        fi
done
      
return
}

#
# process_lun C_DIR D_DIR parm
#
process_lun()
{
local C_DIR
local D_DIR
local parm
local readok
local EXCLUDELIST
local RETURNVALUE

C_DIR="$1/$3"
D_DIR="$2-$3"

for parm in `ls $C_DIR` 
  do
        if  [ -d $C_DIR/$parm ] ; then 
            if  [ "$parm" = "block" ]; then 
                echo "$D_DIR: "`ls -l $C_DIR/$parm` >> $TMPLOG
                process_block $C_DIR $D_DIR $parm
            fi
        else 
    	    readok=`ls -l $C_DIR/$parm | cut -c2-2`
	    if  [ "$readok" = "r" ]  &&  [ ! -L $C_DIR/$parm ] && [ ! -d $C_DIR/$parm ] ; then 
		instr "$parm" "$EXCLUDELIST"
		RETURNVALUE=$?
		if [ ${RETURNVALUE} -eq 0 ]; then
		    echo "$D_DIR: $parm="`cat $C_DIR/$parm` >> $TMPLOG
		fi
            fi    
        fi
done
      
return
}

#
# process_target C_DIR D_DIR parm
#
process_target()
{
local C_DIR
local D_DIR
local parm
local readok
local EXCLUDELIST
local RETURNVALUE

C_DIR="$1/$3"
D_DIR="$2-$3"

EXCLUDELIST="mbox ctlreg slimem ctpass menlo"

for parm in `ls $C_DIR` 
  do
        if  [ -d $C_DIR/$parm ] ; then 
            process_lun $C_DIR $D_DIR $parm
        else 
    	    readok=`ls -l $C_DIR/$parm | cut -c2-2`
	    if  [ "$readok" = "r" ]  &&  [ ! -L $C_DIR/$parm ] && [ ! -d $C_DIR/$parm ] ; then 
		instr "$parm" "$EXCLUDELIST"
		RETURNVALUE=$?
		if [ ${RETURNVALUE} -eq 0 ]; then
		    echo "$D_DIR: $parm="`cat $C_DIR/$parm` >> $TMPLOG
		fi
            fi    
        fi
done
      
return
}

#
# process_device C_DIR D_DIR parm
#
process_device()
{
local C_DIR
local D_DIR
local parm
local readok
local EXCLUDELIST
local RETURNVALUE

C_DIR="$1/$3"
D_DIR="$2-$3"

EXCLUDELIST="mbox ctlreg slimem ctpass menlo"

for parm in `ls $C_DIR` 
  do
        if  [ -d $C_DIR/$parm ] ; then 
            process_target $C_DIR $D_DIR $parm
        else 
	    readok=`ls -l $C_DIR/$parm | cut -c2-2`
	    if  [ "$readok" = "r" ]  &&  [ ! -L $C_DIR/$parm ] && [ ! -d $C_DIR/$parm ] ; then 
		instr "$parm" "$EXCLUDELIST"
		RETURNVALUE=$?
		if [ ${RETURNVALUE} -eq 0 ]; then
		    echo "$D_DIR: $parm="`cat $C_DIR/$parm` >> $TMPLOG
		fi
	    fi
        fi
done
      
return
}

#
# Function to gather /sys/class/scsi_host/ information.
#
dump_sys_class()
{
local f
local HOST_ID
local D_DIR
local parm
local EXCLUDELIST

EXCLUDELIST="mbox ctlreg slimem ctpass menlo"

for f in /sys/class/scsi_host/*
  do
    if [ -f $f/lpfc_drvr_version ]; then
	   HOST_ID=`echo $f | sed -e "s/.*host//"`
           echo "" >> $TMPLOG
           echo "Processing /sys/class/scsi_host/host$HOST_ID:" >> $TMPLOG
           D_DIR="host$HOST_ID"
	   for parm in `ls $f` 
	   do
		if [ $parm = "device" ]; then
		   process_device $f $D_DIR $parm 
		fi
		readok=`ls -l $f/$parm | cut -c2-2`
		if  [ $readok = r ]  &&  [ ! -L $f/$parm ] && [ ! -d $f/$parm ] ; then 
			instr "$parm" "$EXCLUDELIST"
			RETURNVALUE=$?
			if [ ${RETURNVALUE} -eq 0 ]; then
			 echo "$D_DIR: $parm="`cat $f/$parm` >> $TMPLOG
			fi
		fi
	   done 
    fi
done

echo "" >> $TMPLOG
}

#
# process_statistics C_DIR
#
process_statistics()
{
local C_DIR
local S_DIR="statistics"
local parm
local readok
# Exclude list are directories and write only parameters.
local EXCLUDELIST="reset_statistics"
local RETURNVALUE

C_DIR="$1"

for parm in `ls $C_DIR/$S_DIR` 
    do
	readok=`ls -l $C_DIR/$S_DIR/$parm | cut -c2-2`
	if  [ "$readok" = "r" ]  &&  [ ! -L $C_DIR/$S_DIR/$parm ] && [ ! -d $C_DIR/$S_DIR/$parm ] ; then 
	    instr "$parm" "$EXCLUDELIST"
	    RETURNVALUE=$?
	    if [ ${RETURNVALUE} -eq 0 ]; then
		exec_copy "$C_DIR/$S_DIR/$parm"
	    fi
	fi    
    done
      
return
}

#
# Function to gather /sys/class/fc_host/host* parameter values.
# Instead of using an exclude list just specify the parameters
# we are interested in.
#
get_fc_host_params()
{
local SYS_DIR="/sys/class/fc_host/"

if [ -d $SYS_DIR ] ; then
    for i in `ls -d $SYS_DIR/host*`
    do
	if  [ -d $i/statistics ] ; then 
	    process_statistics $i
	fi
	    exec_copy "$i/active_fc4s"
	    exec_copy "$i/fabric_name"
	    exec_copy "$i/maxframe_size"
	    exec_copy "$i/node_name"
	    exec_copy "$i/port_id"
	    exec_copy "$i/port_name"
	    exec_copy "$i/port_state"
	    exec_copy "$i/port_type"
	    exec_copy "$i/speed"
	    exec_copy "$i/supported_classes"
	    exec_copy "$i/supported_fc4s"
	    exec_copy "$i/supported_speeds"
	    exec_copy "$i/tgtid_bind_type"
    done
else
    echo "There is no $SYS_DIR in this system." >> $TMPLOG
fi

}

#
# Function to gather /sys/class/fc_remote_ports/rport* parameter values.
#
get_fc_remote_port_params()
{
local SYS_DIR="/sys/class/fc_remote_ports/"

if [ -d $SYS_DIR ] ; then
    for i in `ls -d $SYS_DIR/rport*`
    do
          exec_copy "$i/node_name"
	  exec_copy "$i/port_name"
	  exec_copy "$i/port_id"
	  exec_copy "$i/scsi_target_id"
	  exec_copy "$i/dev_loss_tmo"
	  exec_copy "$i/fast_io_fail_tmo" 
    done
else
    echo "There is no $SYS_DIR in this system." >> $TMPLOG
fi

}

#
# Function to gather /sys/class/fc_transport/target* parameter values.
#
get_fc_transport_params()
{
local SYS_DIR="/sys/class/fc_transport/"

if [ -d $SYS_DIR ] ; then
    for i in `ls -d $SYS_DIR/*`
    do
          exec_copy "$i/node_name"
	  exec_copy "$i/port_id"
	  exec_copy "$i/port_name"
    done
else
    echo "There is no $SYS_DIR in this system." >> $TMPLOG
fi

}

#
# Function to gather /sys/class/scsi_host/ information.
#
get_scsi_host_params()
{
local SYS_DIR="/sys/class/scsi_host/"
local parm
local EXCLUDELIST

EXCLUDELIST="ctlreg device issue_reset lpfc_soft_wwn_enable mbox menlo scan subsystem uevent issue_lip lpfc_soft_wwpn_enable lpfc_aer_state_cleanup vport_create vport_delete lpfc_authenticate lpfc_update_auth_config "

    for i in `ls -d $SYS_DIR/*`
    do
    	if [ -f "$i/lpfc_drvr_version" ] ; then
	    for parm in `ls $i`
	    do
		instr "$parm " "$EXCLUDELIST"
		RETURNVALUE=$?
		if [ ${RETURNVALUE} -eq 0 ]; then
		    exec_copy "$i/$parm"
		fi    
	    done
	fi
    done
}

#
# Function to gather SCSI midlayer command timeout and queue_depth values.
#
get_scsi_cmd_tmo()
{
local SYS_DIR="/sys/class/scsi_device/"

	for i in `ls -d $SYS_DIR/*:0:*:*`
	do
		exec_copy "$i/device/timeout"
		exec_copy "$i/device/queue_depth"
	done
}


#
# Function to gather SCSI midlayer command timeout values.
#
dump_scsi_cmd_tmo()
{
	cd /sys/class/scsi_device/
	echo "SCSI Command Timeouts:"  >> $TMPLOG
	for i in `ls -d *:0:*`
	do
		cd $i/device
		echo "    Device:`pwd`, Timeout:`cat timeout`"  >> $TMPLOG
		cd ../..
	done
	echo "" >> $TMPLOG
}


#
# Function to gather OS/distribution related information.
#
get_os_info()
{
	exec_cmd "/bin/uname -a"
	if [ -f /etc/redhat-release ] ; then
		exec_cmd  "cat /etc/redhat-release"
		exec_copy "/etc/redhat-release"
	elif [ -f /etc/SuSE-release ] ; then
		exec_cmd  "cat /etc/SuSE-release"
		exec_copy "/etc/SuSE-release"
	fi
}

#
# Function to gather system information related to the functionality
# of the linux device driver.
#
get_system_info()
{
	exec_cmd  "hostname"
	exec_cmd  "uptime " 

	exec_copy "/proc/partitions"
	exec_copy "/proc/cpuinfo"
	exec_copy "/proc/devices"
	exec_copy "/proc/cmdline"
	exec_copy "/proc/scsi/scsi"

	exec_cmd  "gcc -v"
	exec_cmd  "/sbin/lsmod"
}

#
# Function to gather system memory information.
#
get_memory_info()
{
	exec_cmd  "vmstat"
	exec_cmd  "free"
	exec_copy "/proc/slabinfo"
}

#
# Function to gather information about installed RPMs.
#
get_rpm_info()
{
	exec_cmd "rpm -qa | sort"
}

#
# Function to gather PCI device information.
#
get_pci_info()
{
	exec_cmd  "/sbin/lspci -v" 
	exec_cmd  "/sbin/lspci -n" 
	exec_cmd  "/sbin/lspci -nv" 
}

#
# Function to gather Linux kernel configuration information.
#
get_kernel_info()
{
	exec_cmd  "ls -la /usr/src"
	if [ -f /usr/src/linux/.config ]; then
	    exec_cmd  "cp /usr/src/linux/.config ${TMPDIR}/${KVER}.config"
	fi
}

#
# Function to gather messages files from /var/log directory.
#
get_message_files()
{
local messages_file
local warn_file

	find /var/log -name "messages-*.gz"  -ctime -7 -maxdepth 1 -exec cp -a --parents {} $LOG/ \; >/dev/null 2>&1
	find /var/log -name "messages-*.bz2"  -ctime -7 -maxdepth 1 -exec cp -a --parents {} $LOG/ \; >/dev/null 2>&1

	for warn_file in /var/log/warn*; do
	    exec_copy "${warn_file}"
	done

	exec_copy "/var/log/dmesg"
}

#
# Function to gather boot loader information.
#
get_boot_info()
{
	exec_copy "/etc/lilo.conf"
	exec_copy "/etc/elilo.conf"
	exec_copy "/etc/grub.conf"
	exec_copy "/boot/etc/yaboot.conf"
}

#
# Function to gather lpfc device driver information.
#
get_lpfc_info()
{
	exec_copy "/proc/scsi/scsi"
	exec_cmd  "ls /proc/scsi/lpfc"

	if [ -d /proc/scsi/lpfc ]; then
		echo "Copying output from: /proc/scsi/lpfc/*" >> $TMPLOG
		echo "" >> $TMPLOG
		cp --parents /proc/scsi/lpfc/* $TMPDIR  >> $TMPLOG
	fi

	echo "Command: 	find /lib/modules -name lpfc\* -exec ls -l {}" >> $TMPLOG
	find /lib/modules -name lpfc\* -exec ls -l {} \; >> $TMPLOG

	echo "" >> $TMPLOG

	# Any mention of Emulex driver in  /etc/...
	for f in $(find /etc -type f) ; do
	    if grep -q -s lpfc $f ; then
		echo "lpfc found in:$f" >> $TMPLOG
		cp --parents $f ${TMPDIR}
	    fi
	done

	echo "" >> $TMPLOG
}

#
# Function to gather Multipule driver information if available.
#
get_mp_info()
{
	if [ -d /proc/scsi/lpfcmpl ]; then
		echo "Getting Multipulse info from /proc/scsi/lpfcmpl/*..." | tee -a $TMPLOG
		echo "" >> $TMPLOG
		cp --parents /proc/scsi/lpfcmpl/* $TMPDIR  >> $TMPLOG
	fi
}

#
# Function to gather DM multipath related information if available.
#
get_DM_info()
{
    if [ -f /sbin/multipath ]; then
	echo "Gathering DM Multipath information ..." | tee -a $TMPLOG
	exec_cmd  "multipath -ll"
	exec_cmd  "service multipathd status"
    fi

    exec_copy "/etc/multipath.conf"
}

#
# Function to gather Dump data if available.
#
get_dump_data()
{
	# Dump exists and it is not empty
	if [ -d /usr/sbin/hbanyware/Dump ] && [ "$(ls -A /usr/sbin/hbanyware/Dump)" ]; then

	    echo "Gathering Dump data from /usr/sbin/hbanyware/Dump/..." | tee -a $TMPLOG
	    cp --parents /usr/sbin/hbanyware/Dump/* $TMPDIR  >> $TMPLOG
	fi
}

#
# Function to gather Emulex library information if available.
#
get_library_info()
{
	exec_cmd  "file /usr/lib/libdfc*.*"
	exec_cmd  "ls -la /usr/lib/libdfc*.*"
	exec_cmd  "file /usr/lib/libHBA*.*"
	exec_cmd  "ls -la /usr/lib/libHBA*.*"
	exec_cmd  "file /usr/lib/libemulexhbaapi*.*"
	exec_cmd  "ls -la /usr/lib/libemulexhbaapi*.*"
	exec_cmd  "cat /etc/hba.conf"
}

#
# Function to gather Applications (HBAnyware or OneCommand Manager) information
# if available.
#
get_apps_info()
{
HBACMD=""

	if [ -f /usr/sbin/hbanyware/hbacmd ] ; then
	    HBACMD=/usr/sbin/hbanyware/hbacmd
	fi
	if [ -f /usr/sbin/ocmanager/hbacmd ]; then
	    HBACMD=/usr/sbin/ocmanager/hbacmd
	fi

	exec_cmd  "ps -eaf | grep hbanyware"
	exec_cmd  "ps -eaf | grep ocmanager"

	if [ -n ${HBACMD} ] ; then
	    exec_cmd  "${HBACMD} version"

#	    echo "Getting WWPNs ($HBACMD ListHBAs) . . ."
	    WWPX=$($HBACMD ListHBAs | grep "Port WWN")
	    if [ $? -ne 0 ] ; then
		echo "ERROR $? running $HBACMD ListHBAs"
		return 1
	    fi

	    for i in ${WWPX[*]}
	    do
		if [ "$i" = "Port" ]; then
		    continue
		fi
		if [ "$i" = "WWN" ]; then
		    continue
		fi
		if [ "$i" = ":" ]; then
		    continue
		fi
		WWPN="$WWPN $i"
	    done

#	    echo "Available WWPNs: $WWPN"
	    if [ -z "$WWPN" ] ; then
		echo "ERROR failed to get WWPN"
		return 1
	    fi

	    for wwpn in $WWPN
	    do
		exec_cmd  "${HBACMD} GetCEEParams $wwpn"
	    done
	fi
}

#
# Function to gather be2net and be2iscsi driver specific information, if 
# available/applicable.
#
get_be_info()
{
local iparm
local ibe2
local intf
local BE2_LIST

	lspci -n | grep "19a2:0700" >/dev/null
	BE2_NIC_PRESENT=$?

	lspci -n | grep "19a2:0702" >/dev/null
	BE2_ISCSI_PRESENT=$?

	lspci -n | grep "19a2:0710" >/dev/null
	BE3_NIC_PRESENT=$?

	lspci -n | grep "19a2:0712" >/dev/null
	BE3_ISCSI_PRESENT=$?

	if [ ${BE2_NIC_PRESENT} -ne 0 -a ${BE2_ISCSI_PRESENT} -ne 0 -a ${BE3_NIC_PRESENT} -ne 0 -a ${BE3_ISCSI_PRESENT} -ne 0 ] ; then
	    return 0
	fi

	echo "-------------------------------------------------------------" >> $TMPLOG
	echo "Gathering be2 driver related info..." | tee -a $TMPLOG

	exec_copy "/proc/meminfo"
	exec_copy "/proc/version"
	exec_copy "/proc/uptime"
	exec_copy "/proc/cmdline"
	exec_copy "/proc/interrupts"
	exec_copy "/proc/net/dev"
	exec_copy "/proc/iomem"

	exec_cmd  "dmidecode"

	BE2_LIST="/sys/module/be2net /sys/module/be2iscsi"

	for ibe2 in $BE2_LIST
	do
	    if [ -d $ibe2 ] ; then 
	        echo "" >> $TMPLOG

	        for iparm in `ls $ibe2`
	        do
		    if [ -d $ibe2/$iparm ] ; then
		        cp --parents $ibe2/$iparm/* $TMPDIR  >> $TMPLOG
		    else
		        exec_copy $ibe2/$iparm
		    fi
	        done
	    fi
	done

	for intf in `ifconfig -a | grep eth | awk '{print $1}'`
	do
	    if [ `ethtool -i $intf | grep driver | awk '{print $2}'` == "be2net" ]
	    then
		exec_cmd "ethtool $intf"
		exec_cmd "ethtool -i $intf"
		exec_cmd "ethtool -k $intf"
		exec_cmd "ethtool -c $intf"
	    fi
	done

	exec_cmd "netstat -s"
	exec_cmd "netstat -stu"

	for iparm in /lib/firmware /usr/lib/hotplug/firmware; 
	do
	    if [ -d $iparm ]; then
		exec_cmd "ls -l $iparm/*.ufi"
	    fi
	done

	if [ -d /etc/sysconfig/network-scripts ] ; then
	    rh=1
	    exec_cmd "ls -l /etc/sysconfig/network-scripts/"
	fi

	if [ -d /etc/sysconfig/network ] ; then
	    rh=0
	    exec_cmd "ls -l /etc/sysconfig/network/"
	fi

	for intf in `ifconfig -a | grep eth | awk '{print $1}'`
	do
	    if [ `ethtool -i $intf | grep driver | awk '{print $2}'` == "be2net" ] ; then
		if [ $rh == 1 ] ; then
		    exec_cmd "cat /etc/sysconfig/network-scripts/ifcfg-$intf"
		else
		    if [ -f /etc/sysconfig/network/ifcfg-$intf ] ; then
			exec_cmd "cat /etc/sysconfig/network/ifcfg-$intf"
		    else
			mac=`ifconfig -a | grep -i $intf | awk '{print $5}'`
			exec_cmd "cat /etc/sysconfig/network/ifcfg-eth-id-$mac"
		    fi
		fi
	    fi
	done

	echo "Connection Info..." >> $TMPLOG
	exec_cmd "netstat -antp | grep \"ESTABLISHED \" | wc -l"

	echo "Initial Counters..." >> $TMPLOG
	for intf in `ifconfig -a | grep eth | awk '{print $1}'`
	do
	    if [ `ethtool -i $intf | grep driver | awk '{print $2}'` == "be2net" ]
	    then
		exec_cmd "ifconfig $intf"
		exec_cmd "ethtool -S $intf"
		exec_cmd "cat /proc/interrupts | grep -i $intf"
	fi
	done

	if [ -f /usr/bin/numastat ] ; then
	    echo "Get numastat information every 5 sec:" >> $TMPLOG
	    i="0"
	    while [ $i -lt 4 ]
	    do
		exec_cmd "numastat"
		sleep 5
		let i=$i+1
	    done
	else
	    echo "numastat not available" >> $TMPLOG
	fi

}


###########################################################################
#	Program starts here
###########################################################################

if [ "$1" = "--help" -o "$1" = "-h" ]; then
	usage
	exit 0
fi

# Create temp files
init_files

echo "Gathering OS information ..." | tee -a $TMPLOG
get_os_info

echo "Gathering System information ..." | tee -a $TMPLOG
get_system_info

echo "Checking System memory..." | tee -a $TMPLOG
get_memory_info

echo "Gathering RPM information..." | tee -a $TMPLOG
get_rpm_info

echo "Gathering PCI information ..." | tee -a $TMPLOG
get_pci_info

echo "Checking kernel information ..." | tee -a $TMPLOG
get_kernel_info

echo "Gathering message files ..." | tee -a $TMPLOG
get_message_files

echo "Gathering boot info ..." | tee -a $TMPLOG
get_boot_info

echo "Gathering LPFC information ..." | tee -a $TMPLOG
get_lpfc_info

if [ ${OS_REV} = 2.6 ]; then
   echo "Gathering SCSI Command Timeout values for all available SCSI devices ..." | tee -a $TMPLOG
   get_scsi_cmd_tmo

   echo "Gathering fc_host information ..." | tee -a $TMPLOG
   get_fc_host_params

   echo "Gathering fc_remote_port information ..." | tee -a $TMPLOG
   get_fc_remote_port_params

   echo "Gathering fc_transport information ..." | tee -a $TMPLOG
   get_fc_transport_params

   echo "Gathering scsi_host information ..." | tee -a $TMPLOG
   get_scsi_host_params

# Capture DM specific information
   get_DM_info
fi

# Copy Muiltipulse driver data if available
get_mp_info

# Gathering dump data if available
get_dump_data

echo "Gathering library information ..." | tee -a $TMPLOG
get_library_info

echo "Gathering HBAnyware/OneCommand Manager info..." | tee -a $TMPLOG
get_apps_info

# Get BE driver information, if present
get_be_info

find ${TMPDIR} -name "*" |xargs chmod 755

echo "Generating report..." | tee -a $TMPLOG
tar -C "/var/log/log_collector"  -zcvf "/var/log/log_collector/hba_emulex_${PROGNAME}_${DATE}.tgz" ${PROGNAME}/ >> $TMPLOG

#echo ""
#echo "Please send file /var/log/log_collector/${PROGNAME}_${DATE}.tgz to your Emulex Support Representative."
echo ""

clean_up

exit 0

