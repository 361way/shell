#! /bin/bash

readlink $0 >/dev/null 2>&1
if [ $? -ne 0 ];then
   RUN_PATHBAK=$(dirname $0)
   RUN_PATH=$RUN_PATHBAK/tools
else
   RUN_PATHBAK=$(readlink $0)
   RUN_PATHBAK=$(dirname $RUN_PATHBAK)
   RUN_PATH=$RUN_PATHBAK/tools
fi

LOG_DIR="/var/log/log_collector"
LOG_FILE="log_collector.txt"
SUPPORTCONFIG_FILE="supportconfig.tar.bz2"
SUPPORTCONFIG_SHELL="supportconfig.sh"
SUPPORTCONFIG_RES="supportconfig_res.txt"
VXEXPLORE_FILE="vxexplore_version5.5z.tar.Z"
VXEXPLORE_SHELL="VRTSexplorer"
VXEXPLORE_RES="vxexplore.txt"
SMM_FILE="hardware.tar.gz"
SMM_SHELL="hardware_log_collector.sh"
NIC_SHELL="nics_log_collector.sh"
FC_HBA_RES="fc_hba.txt"
CONF_FILE="atae_log_collector.conf"
is_blade=0
argc=$#
SLOT_NUM=""

function log_file()
{
    echo $@ >> $LOG_DIR/$LOG_FILE
}

function log_echo()
{
    echo "$@" | tee -a $LOG_DIR/$LOG_FILE
}
function show_help()
{
    echo " usage: log_collector [option]"   
    echo "    -h --help        display this help"
    echo "    -s --supportconfig  collect the OS system log"
    echo "    -f --fc_hba         collect the fc_hba log"
    echo "    -v --vxexplore      collect the vcs/vxvm log"
    echo "    -b --blade          collect blade hardware log"
    echo "    -n --nics           collect nics log"
    echo "    -V --version        version information"
}

function log_title() {
    echo ""
    echo "==========================================================="
    echo "                 Collecting $@ log"
    echo "==========================================================="
    echo ""
}

function check_cpu()
{
    #check the CPU and swap Share
    CPU_value_smm=0
    CPU_value_five=$(vmstat 1 5 | tail -5 | awk '{print $(NF-2)}')
    for CPU_value in $CPU_value_five ;do
        CPU_value_smm=`expr  $CPU_value_smm + $CPU_value`
    done

    CPU_value_smm=`expr $CPU_value_smm / 5`
    CPU_value_smm=`expr 100 - $CPU_value_smm `
    CPU_max_share=$(cat $RUN_PATHBAK/$CONF_FILE |grep "^cpu_limit" |awk -F= '{print $2}')
    [ -z $CPU_max_share ] && log_echo "[Error]the cpu_limit in $RUN_PATHBAK/$CONF_FILE is empty ." && exit 1
    expr $CPU_max_share + 0 >/dev/null 2>&1

    if [ $? -ne 0 ] ;then
        log_echo "[Error]the cpu_limit in $RUN_PATHBAK/$CONF_FILE is $CPU_max_share not in [1-100] ,can't collect OS log ." && exit 1
    fi
   
    if [ ! $CPU_max_share -le 100 -a $CPU_max_share -ge 0 ] ;then
        log_echo "[Error]the cpu_limit in $RUN_PATHBAK/$CONF_FILE is $CPU_max_share not in [1-100] ,can't collect OS log ." && exit 1
    fi
    
    [ $CPU_value_smm -gt $CPU_max_share ] && log_echo "the cpu_limit in $RUN_PATHBAK/$CONF_FILE is $CPU_max_share ,the cpu share is $CPU_value_smm currently ,can't collect OS log ." && exit 1
}

function supportconfig()
{
    check_cpu
    tar zxvf $RUN_PATH/$SUPPORTCONFIG_FILE -C $RUN_PATH > /dev/null 2>&1
    $RUN_PATH/$SUPPORTCONFIG_SHELL
    rm -r $RUN_PATH/$SUPPORTCONFIG_SHELL > /dev/null 2>&1    
}

function vxexplore()
{
    tar -xvzf $RUN_PATH/$VXEXPLORE_FILE -C $RUN_PATH/ > /dev/null 2>&1
    log_title "VCS/vxvm"
    $RUN_PATH/VRTSexplorer/$VXEXPLORE_SHELL
    rm -rf $RUN_PATH/VRTSexplorer/ >/dev/null
}

function smm()
{
    mkdir $RUN_PATH/smm > /dev/null 2>&1
    tar -zxvf $RUN_PATH/$SMM_FILE -C $RUN_PATH/smm > /dev/null 2>&1

    log_title "Blade"
    
    #smm paraments results
    blade_num=0
    smm_ip=""
    expect_res=0
    passwd=""    
    
    #read paraments results
    input_ip_values=0
    input_slot_values=0
    
    echo -n "Enter the ip of SMM :"
    read smm_ip
    while [ $input_ip_values -eq 0 ] ;do
        ping -c2 -W1 $smm_ip > /dev/null 2>&1
        if [ $? -ne 0 ] ;then
            echo "The ip can not reach, please confirm the ip of the SMM."
            echo ""
            echo -n "Enter the ip of SMM :"
            read smm_ip
            continue
        fi
        
        echo -n "Enter the password of SMM(ip:$smm_ip) :"
        read passwd
        result=$($RUN_PATH/check_login.exp $smm_ip $passwd "/smm/smmget -d redundancy |head -n 3 |grep '*'">/dev/null 2>&1)
        expect_res=$?
        
        if [ $expect_res -eq 1 ] ;then
            echo "The corresponding host is not a SMM, please confirm."
            echo ""
            echo -n "Enter the ip of SMM :"
            read smm_ip
            continue
        elif [ $expect_res -eq 0 ] ;then
            echo $result |grep "SMM2: Present\(standby\)*" >/dev/null 2>&1
            if [ $? -eq 0 ];then
                echo "The corresponding host is a standby SMM, please confirm."
                echo ""
                echo -n "Enter the ip of active SMM :"
                read smm_ip
                continue
            else
                input_ip_values=1
            fi
           
        elif [ $expect_res -eq 101 ] ;then
            echo "The password of the SMM(ip:$smm_ip) is error, please confirm. ."
            echo -n "Enter the password of SMM(ip:$smm_ip) :"
            read passwd
          
            result=$($RUN_PATH/check_login.exp $smm_ip $passwd "/smm/smmget -d redundancy |head -n 3 |grep '*'">/dev/null 2>&1)
            expect_res=$?
            if [ $expect_res -eq 1 ] ;then
                echo "The corresponding host is not a SMM, please confirm."
                echo ""
                echo -n "Enter the ip of SMM :"
                read smm_ip
                continue
            elif [ $expect_res -eq 0 ] ;then
                echo $result |grep "SMM2: Present\(standby\)*" >/dev/null 2>&1
                if [ $? -eq 0 ];then
                    echo "The corresponding host is a standby SMM, please confirm."
                    echo ""
                    echo -n "Enter the ip of active SMM :"
                    read smm_ip
                    continue
                else
                    input_ip_values=1
                fi
            elif [ $expect_res -eq 101 ] ;then
                echo "The password of the SMM(ip:$smm_ip) is error, please confirm. ."
                echo ""
                echo -n "Enter the ip of SMM :"
                read smm_ip
                continue
            else
                input_ip_values=1
            fi
        else
            input_ip_values=1       
        fi
    done    
    
    echo ""
    echo -n "Enter the blade num :"
    read blade_num

    while [ $input_slot_values -eq 0 ] ;do
        expr ${blade_num} + 0 1>/dev/null 2>&1
        if [ $? -ne 0 ] ;then
             echo "The blade num must between 1 to 14."
             echo ""                
             echo -n "Enter the blade num [1-14]:"
             read blade_num
             continue
        fi    
        
        if [ $blade_num -lt 1 ] || [ $blade_num -gt 14 ]  ;then 
            echo "The blade num must between 1 to 14."    
            echo ""
            echo -n "Enter the blade num [1-14]:"    
            read blade_num
            continue
        fi

        input_slot_values=1
    done

    SLOT_NUM=${blade_num}
    _smm $smm_ip $passwd $blade_num   
    
    rm -rf $RUN_PATH/smm >/dev/null 2>&1 
}

function _smm()
{
    # smm infomation
    smm_ip=$1
    passwd=$2
    blade_num=$3
    switch_inter=0    
    
    #input_switch_result
    input_switch_result=0
   
    if [ $blade_num -eq 7 ] || [ $blade_num -eq 8 ];then
        echo "The blade you chose is a switch"
        echo "[1]BMC"
        echo "[2]Fabric/Base"
        #echo "[3]GE"
        echo "[3]FC"
        echo -n "Select the interface :"    
        read switch_inter

        while [ $input_switch_result -eq 0 ] ;do
            expr ${switch_inter} + 0 1>/dev/null 2>&1
            if [ $? -ne 0 ] ;then
                echo "Please choose between 1 to 4."
                echo "[1]BMC"
                echo "[2]Fabric/Base"
                #echo "[3]GE"
                echo "[3]FC"
                echo -n "Select the interface :"
                read switch_inter
                continue
            fi

            if [ $switch_inter -lt 1 ] || [ $switch_inter -gt 4 ];then
                echo "Please choose between 1 to 4."
                echo "[1]BMC"
                echo "[2]Fabric/Base"
                #echo "[3]GE"
                echo "[3]FC"
               echo -n "Select the interface :"
                read switch_inter
                continue
            fi
            input_switch_result=1
        done
    
        case $switch_inter in
            1)
                $RUN_PATH/smm/hardware/$SMM_SHELL $smm_ip $passwd "-b 7 -t \"BMC\" -u root -p $passwd"
                ;;
            2)
                $RUN_PATH/smm/hardware/$SMM_SHELL $smm_ip $passwd "-b 7 -t \"BASE\" -u root -p $passwd"
                ;;
            #3)
            #    $RUN_PATH/smm/hardware/$SMM_SHELL $smm_ip $passwd "-b 7 -t \"GE\" -u root -p $passwd"
            #;;
            3)
                $RUN_PATH/smm/hardware/$SMM_SHELL $smm_ip $passwd "-b 7 -t \"FC\" -u root -p $passwd"
                ;;    
        esac    
    else
        $RUN_PATH/smm/hardware/$SMM_SHELL $smm_ip $passwd "-b $blade_num -t \"BMC\" -u root -p $passwd"    
    fi    
} 

function init()
{
    rm -rf $LOG_DIR
    [ -d $LOG_DIR ] || mkdir $LOG_DIR
    [ -f $LOG_DIR/$LOG_FILE ] || touch $LOG_DIR/$LOG_FILE 
    log_file "==========log_file begin==============="
    log_file `date`
    log_file ""
}

function end()
{
    log_file ""
    log_file `date`
    log_file "==========log_file end================="
    log_file ""
    
}

function check()
{
    dmidecode > /dev/null 2>&1
    [ $? -ne 0 ] && is_blade=1  
}

function printlog()
{
    echo "$@" | tee -a $LOG_DIR/$LOG_FILE 
}

function progress()
{
    echo -n "Collecting $1 in progress: "
    while [ 0 ]
    do
        for j in '-' '\\' '|' '/'
        do
            echo -ne "\033[1D$j"
            usleep 50000
        done
    done
}

function fc_hba()
{
    log_title "fc_hba"    
    lspci | grep Fi | grep Emulex > /dev/null 2>&1
    is_emulex=$?
    if [ $is_emulex -eq 0 ]
    then
        chmod +x $RUN_PATH/elxreport.sh
        $RUN_PATH/elxreport.sh
    fi
        lspci | grep Fi | grep QLogic > /dev/null 2>&1
        is_qlogic=$?
    if [ $is_qlogic -eq 0 ]
    then
            chmod +x $RUN_PATH/qla_linux_info.sh
            $RUN_PATH/qla_linux_info.sh
        fi
    if [ $is_emulex -ne 0 ] && [ $is_qlogic -ne 0 ]
    then
        printlog "This blade have no Emulex or QLogic hba card, can't collect the log."    
    fi
}

function nics()
{
    log_title "nics"
    echo "The nics name like eth1 or eth1,eth2,eth3 " 
    echo -n "Please input collect the nics name :"
    read nics_name 
    nic_name_value=0
    error_count=0

    while [ $nic_name_value -eq 0 ] ;do
        nics_name_error=""
        nics_name_right=""
        error_count=0
        nic_count=$(echo "$nics_name" | awk -F"," '{print NF}')
        for (( i=1 ;i<=$nic_count ;i++)) ;do
            nic_name=$(echo "$nics_name" | cut -d"," -f $i)
            echo $nic_name |grep -i "^ *eth[1-9][0-9]\{0,1\} *$" 
            if [ $? -ne 0 ];then
                ((error_count++))
                nics_name_error="$nics_name_error-$nic_name"
            else
                nic_name=$(echo $nic_name |sed "s/ *//g"| tr "A-Z" "a-z")
                nics_name_right="$nics_name_right $nic_name"
            fi
        done
            
        if [ $error_count -eq 0 ] ;then
            nic_name_value=1
        else
            echo "the put $nics_name_error is not regular "
            echo ""
            echo -n "Please input collect the nics name :"
            read nics_name
        fi
    done 
    $RUN_PATH/$NIC_SHELL $nics_name_right 
}

function show()
{
   clear
   echo "-------------------------------------------------------------------------"
   echo "|                 1:collect      board        log                       |"
   echo "|                 2:collect       HBA         log                       |"
   echo "|                 3:collect       OS          log                       |"
   echo "|                 4:collect     VCS/VXVM      log                       |"
   echo "|                 5:collect OS/HBA/VCS/VXVM   log                       |"
   echo "|                 6:collect      NICS         log                       |"
   echo "|                 7:collect      Version                                |"
   echo "|                 8:exit                                                |"
   echo "-------------------------------------------------------------------------"
   echo ""
   echo -n "please input you choose [1-8]:"
}

function main()
{
        show
        
        # input_value=0
        init
   
        # check enviroment
        check
       
        # input parameter 
        input_value=0
        error_count=0

        #collect result parameter 
        show_log_dir=1
        log_type=""
        
        read choose
        while [ $input_value -eq 0 ] ;do
            expr $choose + 1 >/dev/null 2>&1

            if [ $? -ne 0 ] ;then
                 echo "the choose is not 1-8 ,please choose again"
                 echo ""
                 echo -n "please input you choose [1-8]:"
                 read choose 
                 continue
            fi
            if [ ! $choose -le 8 -a $choose -ge 1 ] ;then
                 echo "the choose is not 1-8 ,please choose again"
                 echo ""
                 echo -n "please input you choose [1-8]:"
                 read choose
                 continue
            else
                input_value=1
            fi
        done
        
        if [ $choose -eq 1 ] ;then
            log_file "collect blade hardware log"
            [ $is_blade -eq 0 ] && smm && log_type="Blade${SLOT_NUM}_"&& show_log_dir=0
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE board now, can't collect blade log."
        fi
    
        if [ $choose -eq 2 ] ;then
            log_file "collect fc_hba"
            [ $is_blade -eq 0 ] && fc_hba && log_type="FC_" && show_log_dir=0
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect fc_hba."
        fi
    
        if [ $choose -eq 3 ] ;then
            log_file "collect supportconfig"
            [ $is_blade -eq 0 ] && supportconfig && log_type="OS_" && show_log_dir=0
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect supportconfig."
        fi

        if [ $choose -eq 4 ] ;then
            log_file "collect vxexplore"
            [ $is_blade -eq 0 ] && vxexplore && log_type="VCS_" && show_log_dir=0
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect vxexplore."
        fi

        if [ $choose -eq 5 ] ;then
            log_file "collect fc_hba|supportconfig|vxexplore"
            [ $is_blade -eq 0 ] && fc_hba && log_type="FC_OS_VCS_" && show_log_dir=0
            [ $is_blade -eq 0 ] && supportconfig && log_type="FC_OS_VCS_" && show_log_dir=0
            [ $is_blade -eq 0 ] && vxexplore && log_type="FC_OS_VCS_" && show_log_dir=0
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect c_hba|supportconfig|vxexplore."
        fi
   
        if [ $choose -eq 6 ] ;then
            log_file "collect nics"
            [ $is_blade -eq 0 ] && nics && log_type="NICS_" && show_log_dir=0
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect nics."
        fi
        
        if [ $choose -eq 7 ] ;then
            [ $is_blade -eq 0 ] && printlog "ATAE log_collector, version 1.0, 2012.11.11." && show_log_dir=0
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect blade log."
        exit 88
        fi
     
        if [ $choose -eq 8 ] ;then
            exit 0
        fi

        logtype="$log_type"
        if [ $show_log_dir -eq 0 ]
        then
                #if [ ${logtype} -eq "Blade_" ]
                #then
                #HOSTNAME_TIME=$(date +"%y%m%d_%H%M")
                #else
                HOSTNAME_TIME=`hostname`_$(date +"%y%m%d_%H%M")
                #fi
                TARBALL=log_${logtype}${HOSTNAME_TIME}.tar.gz
                LOG_BASIC=/var/log
                LOG_PLACE_BASIC=$LOG_BASIC/ataelog
                [ -d $LOG_PLACE_BASIC ] || mkdir -p $LOG_PLACE_BASIC
                cd $LOG_BASIC
                mv $LOG_BASIC/log_collector $LOG_BASIC/log_$HOSTNAME_TIME
                tar czf $LOG_PLACE_BASIC/$TARBALL log_$HOSTNAME_TIME/*
                LOGSIZE=$(ls -lh $LOG_PLACE_BASIC/${TARBALL} | awk '{print $5}')
                rm -rf log_$HOSTNAME_TIME
                echo ""
                cat << EOF1
==[ DONE ]=================================================
  Log file tarball: $LOG_PLACE_BASIC/${TARBALL}
  Log file size:    ${LOGSIZE}

  Please send log file tarball to HUAWEI support engineer.

===========================================================
EOF1

        fi
}

function main1()
{
        [ $argc -lt 1 ] && show_help
    init
    check
    show_log_dir=1
    log_type=""
    for((i=1; i<=argc; i++))
    do
        arg=$1
        if [ "$arg" == "--help" ] || [ "$arg" == "-h" ]
        then    
            log_file "show help"    
            show_help
        elif [ "$arg" == "--supportconfig" ] || [ "$arg" == "-s" ]
        then
            log_file "collect supportconfig"
            [ $is_blade -eq 0 ] && supportconfig && log_type="OS_"&& show_log_dir=0 
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect supportconfig."     
        elif [ "$arg" == "--vxexplore" ] || [ "$arg" == "-v" ]
        then
            log_file "collect vxexplore"
            [ $is_blade -eq 0 ] && vxexplore && log_type="VCS_"&&show_log_dir=0 
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect vxexplore."
        elif [ "$arg" == "--fc_hba" ] || [ "$arg" == "-f" ]
        then
            log_file "collect fc_hba"
            [ $is_blade -eq 0 ] && fc_hba && log_type="FC_"&&show_log_dir=0 
                        [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect fc_hba."
        elif [ "$arg" == "--blade" ] || [ "$arg" == "-b" ]
        then
            log_file "collect blade hardware log"
            [ $is_blade -eq 0 ] && smm && log_type="Blade${SLOT_NUM}_"&& show_log_dir=0
            [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect blade log."
                elif [ "$arg" == "--nics" ] || [ "$arg" == "-n" ]
                then
                        [ $is_blade -eq 0 ] && nics && log_type="NICS_" show_log_dir=0
                        [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect nics log." 
        elif [ "$arg" == "--version" ] || [ "$arg" == "-V" ]
                then
                        [ $is_blade -eq 0 ] && printlog "ATAE log_collector, version 1.0, 2012.11.11." && show_log_dir=0
                        [ $is_blade -eq 1 ] && printlog "It isn't on ATAE blade now, can't collect blade log."
            exit 88
        else
            echo " unrecognized option: $arg"
            show_help  
        fi
            logtype="$logtype$log_type"
        shift 1
    done
    
    if [ $show_log_dir -eq 0 ] 
    then
        #if [ ${logtype} -eq "Blade_" ]
        #then
        #HOSTNAME_TIME=$(date +"%y%m%d_%H%M")
        #else
        HOSTNAME_TIME=`hostname`_$(date +"%y%m%d_%H%M")
        #fi
        TARBALL=log_${logtype}${HOSTNAME_TIME}.tar.gz
        LOG_BASIC=/var/log
        cd $LOG_BASIC
        mv $LOG_BASIC/log_collector $LOG_BASIC/log_$HOSTNAME_TIME 
        tar czf $TARBALL log_$HOSTNAME_TIME/*
        LOGSIZE=$(ls -lh ${TARBALL} | awk '{print $5}')
        rm -rf log_$HOSTNAME_TIME
        echo ""
        cat << EOF1
==[ DONE ]=================================================
  Log file tarball: /var/log/${TARBALL}
  Log file size:    ${LOGSIZE}

  Please send log file tarball to HUAWEI support engineer.

===========================================================
EOF1

    fi 
}
main $@
