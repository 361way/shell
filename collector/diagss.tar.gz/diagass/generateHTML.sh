#! /bin/sh
#NAME: getenv.sh
#VERSION: v1.1
#DESCRIPTION: generate html data
#
#CREATED:  xuanziqiao@huawei.com 2013-08-28
#
#MODIFIED: <NONE>
#

OP=$1
TREE_NAME=$2
LAST_CATALOG=$3
DATA_PATH=$4
DATA_NAME=$5
ORDER=$6
LAST_ONE=$7


function generateHTMLheader
{
    echo "<html>" > $TREE_NAME
    echo "<head>" >> $TREE_NAME
    echo "<title>tree menu</title>" >> $TREE_NAME
    echo "<script src=\"js/viewtree.js\"> </script>" >> $TREE_NAME
    echo "<link href='css/treemenu.css' rel='stylesheet' type='text/css'>" >> $TREE_NAME
    echo "</head>" >> $TREE_NAME
    echo "<body topmargin='10' leftmargin='10' bgcolor=#EFF6FE >" >> $TREE_NAME
    echo "<table BORDER='0' CELLSPACING='0' CELLPADDING='0'>" >> $TREE_NAME
    echo "<tr>" >> $TREE_NAME
    echo "<td valign='top' align='left'><a target='mFrame' onClick=\"bottom_hide(0)\" id='link0'><b> Database & OS</b></a></td>" >> $TREE_NAME
    echo "</tr>" >> $TREE_NAME
    echo "</table>" >> $TREE_NAME
    echo "" >> $TREE_NAME
}

function generateHTMLbodyHeader
{
    echo "" >> $TREE_NAME
    
    echo "<table CELLSPACING='0' CELLPADDING='0'>" >> $TREE_NAME
    echo "<tr>" >> $TREE_NAME
    
    if [ "x$LAST_CATALOG" = "xnolast" ]; then
        echo "<td><a href='#' onClick=\"diva_show('$ORDER','','1','1','')\" id='linka${ORDER}'><img name='f${ORDER}' SRC='images/plus1.gif' border='0'></a></td>" >> $TREE_NAME
    else
        echo "<td><a href='#' onClick=\"diva_show('$ORDER','','1','1','')\" id='linka${ORDER}'><img name='F${ORDER}' SRC='images/plus1_end.gif' border='0'></a></td>" >> $TREE_NAME    
    fi

    echo "<td><a href='#' onClick=\"diva_show('$ORDER','',1,'1','')\" id='linkb${ORDER}'><img name='i${ORDER}' SRC='images/close.gif' border='0'></a></td>"   >> $TREE_NAME
    echo "<td><a href='$DATA_PATH' target=\"mFrame\" onClick=\"bottom_hide(${ORDER})\" id='link${ORDER}'>&nbsp;$DATA_NAME</a></td>" >> $TREE_NAME
    echo "</tr>" >> $TREE_NAME
    echo "</table>"  >> $TREE_NAME
    
    echo "" >> $TREE_NAME
    echo "<div id='a${ORDER}' style='display:none'>" >> $TREE_NAME
    
    echo "" >> $TREE_NAME
    
    echo "<table WIDTH='100%' BORDER='0' CELLSPACING='0' CELLPADDING='0'>" >> $TREE_NAME
}

function generateHTMLbodyData
{
    echo "" >> $TREE_NAME
    echo "<tr>"  >> $TREE_NAME
    
    if [ "x$LAST_CATALOG" = "xnolast" ]; then
        echo "<td width='16' background=''><img name='' SRC='images/Line.gif' border='0'></td>" >> $TREE_NAME
    else
        echo "<td width='16' background=''>&nbsp;&nbsp;</td>" >> $TREE_NAME
    fi
    
    echo "<td>" >> $TREE_NAME
    echo "   <table CELLSPACING='0' CELLPADDING='0'>" >> $TREE_NAME
    echo "   <tr>" >> $TREE_NAME
    
    if [ "x$LAST_ONE" = "xnolast" ]; then
        echo "   <td><a href='#' id='linka${ORDER}'><img SRC='images/noSonLine.gif' border='0'></a></td>" >> $TREE_NAME
    else
        echo "   <td><a href='#' id='linka${ORDER}'><img SRC='images/endline.gif' border='0'></a></td>" >> $TREE_NAME
    fi

    echo "   <td><a href='#' id='linkb${ORDER}'><img SRC='images/close.gif' border='0'></a></td>" >> $TREE_NAME
    echo "   <td><a href='$DATA_PATH' target=\"mFrame\" onClick=\"bottom_hide(${ORDER})\" id='link${ORDER}'>&nbsp;$DATA_NAME</a></td>" >> $TREE_NAME
    echo "   </tr>" >> $TREE_NAME
    echo "   </table>" >> $TREE_NAME
    echo "</td>" >> $TREE_NAME    
    echo "</tr>" >> $TREE_NAME
    echo "" >> $TREE_NAME
}

function generateHTMLbodyBottom
{
    echo "" >> $TREE_NAME
    echo "</table>" >> $TREE_NAME
    echo "</div>" >> $TREE_NAME
}

function generateHTMLbottom
{
    echo "" >> $TREE_NAME
    echo "</body>" >> $TREE_NAME
    echo "</html>" >> $TREE_NAME
}

case "$OP" in
    header)
           generateHTMLheader
           ;;
    bodyheader)
           generateHTMLbodyHeader
           ;;
    bodydata)
           generateHTMLbodyData
           ;;
    bodybottom)
           generateHTMLbodyBottom
           ;;
    bottom)
           generateHTMLbottom
           ;;
    *)
           echo "nothing to do"
           ;;
esac


