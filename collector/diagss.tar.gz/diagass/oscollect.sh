#! /bin/sh

#NAME: oscollect.sh
#VERSION: v1.1
#DESCRIPTION: collecting OS log, kernel, sar
#
#CREATED:  xuanziqiao@huawei.com 2013-08-28
#
#MODIFIED: xuanziqiao@huawei.com 2013-10-12 change /bin/bash to /bin/sh 
#


LOGFILE_PATH=$1

#collecting for performance
ISSUE_LEVEL=$2

if [ "x$LOGFILE_PATH" = "x" ]; then
    LOGFILE_PATH="_/log"
fi

SU=/bin/su
ECHO=/bin/echo
GREP=/bin/grep
CAT=/bin/cat

PLATFORM=`/bin/uname`

function osperf
{
    #OS sar&vmstat&iostat
    if [ "x$ISSUE_LEVEL" = "xperf" ]; then
        
        $ECHO "  |___ sar -u 3 20(please wait for one minute)" 
        $ECHO "SAR REPORT:(sar -u 3 20)" > ${LOGFILE_PATH}/collect.28_sar-u-3-20.txt
        sar -u 3 20 >> $LOGFILE_PATH/collect.28_sar-u-3-20.txt
    
        $ECHO "  |___ sar -q 3 20(please wait for one minute)" 
        $ECHO "SAR REPORT:(sar -q 3 20)" > $LOGFILE_PATH/collect.28_sar-q-3-20.txt
        sar -q 3 20 >> $LOGFILE_PATH/collect.28_sar-q-3-20.txt
        
        $ECHO "  |___ sar -d 3 20(please wait for one minute)"
        $ECHO "SAR REPORT:(sar -d 3 20)" > $LOGFILE_PATH/collect.28_sar-d-3-20.txt
        sar -b 3 20 >> $LOGFILE_PATH/collect.28_sar-d-3-20.txt
        
        $ECHO "  |___ sar -b 3 20(please wait for one minute)"
        $ECHO "SAR REPORT:(sar -b 3 20)" > $LOGFILE_PATH/collect.28_sar-b-3-20.txt
        sar -b 3 20 >> $LOGFILE_PATH/collect.28_sar-b-3-20.txt
        
        $ECHO "  |___ sar -v 3 20(please wait for one minute)"
        $ECHO "SAR REPORT:(sar -v 3 20)" > $LOGFILE_PATH/collect.28_sar-v-3-20.txt
        sar -v 3 20 >> $LOGFILE_PATH/collect.28_sar-v-3-20.txt
        
        $ECHO "  |___ vmstat 3 20(please wait for one minute)"
        $ECHO "VMSTAT REPORT:(vmstat 3 20)" > $LOGFILE_PATH/collect.29_vmstat-3-20.txt
        vmstat 3 20 >> $LOGFILE_PATH/collect.29_vmstat-3-20.txt
        
        $ECHO "  |___ iostat 3 20(please wait for one minute)"
        $ECHO "IOSTAT REPORT:(iostat 3 20)" >> $LOGFILE_PATH/collect.30_iostat-3-20.txt
        iostat 3 20 >> $LOGFILE_PATH/collect.30_iostat-3-20.txt
    fi
}

function network
{
       #ROUTE&network
       $ECHO "  |___ netstat -rn"
       $ECHO "ROUTE(netstat -rn):" >> $LOGFILE_PATH/collect.18_netstat-rn.txt
       netstat -rn >> $LOGFILE_PATH/collect.18_netstat-rn.txt
       
       if [ "x$PLATFORM" = "xLinux" ]; then
           $ECHO "  |___ netstat -nlp"
           $ECHO "NETWORK(netstat -nlp):" > $LOGFILE_PATH/collect.20_netstat-nlp.txt
           netstat -nlp >> $LOGFILE_PATH/collect.20_netstat-nlp.txt
       fi
       
       $ECHO "  |___ netstat -a"
       $ECHO "NETWORK(netstat -a):" > $LOGFILE_PATH/collect.21_nestat-a.txt
       netstat -a >> $LOGFILE_PATH/collect.21_nestat-a.txt
       
       $ECHO "  |___ netstat -i"
       $ECHO "NETWORK(netstat -i):" > $LOGFILE_PATH/collect.22_netstat-i.txt
       netstat -i >> $LOGFILE_PATH/collect.22_netstat-i.txt
       
       $ECHO "  |___ netstat -s"
       $ECHO "NETWORK(netstat -s):" > $LOGFILE_PATH/collect.23_netstat-s.txt
       netstat -s >> $LOGFILE_PATH/collect.23_netstat-s.txt
       
       $ECHO "  |___ ifconfig -a"
       $ECHO "IFCONFIG(ifconfig -a):" > $LOGFILE_PATH/collect.24_ifconfig-a.txt
       ifconfig -a >> $LOGFILE_PATH/collect.24_ifconfig-a.txt
       
       
       $ECHO "  |___ /etc/hosts"
       $ECHO "HOST(/etc/hosts):" > $LOGFILE_PATH/collect.25_host.txt
       $CAT /etc/hosts >> $LOGFILE_PATH/collect.25_host.txt
       
       if [ -f "/etc/resolv.conf" ]; then
           $ECHO "  |___ /etc/resolv.conf"
           $ECHO "resolve.conf(/etc/resolv.conf):" > $LOGFILE_PATH/collect.26_resolve_conf.txt
           $CAT /etc/resolv.conf  >> $LOGFILE_PATH/collect.26_resolve_conf.txt
       fi
       
       if [ -f "/etc/nsswitch.conf" ]; then
           $ECHO "  |___ /etc/nsswitch.conf"
           $ECHO "nsswitch.conf(/etc/nsswitch.conf):" > $LOGFILE_PATH/collect.27_nsswitch_conf.txt
           $CAT /etc/nsswitch.conf >> $LOGFILE_PATH/collect.27_nsswitch_conf.txt
       fi
}

##hostname
$ECHO "  |___ hostname"
$ECHO "HOSTNAME(hostname):" > $LOGFILE_PATH/collect.02_hostname.txt
hostname >> $LOGFILE_PATH/collect.02_hostname.txt

##platform
$ECHO "  |___ /bin/uname"
$ECHO "PLATFORM(/bin/uname -a):" > $LOGFILE_PATH/collect.03_platform.txt
/bin/uname -a >> $LOGFILE_PATH/collect.03_platform.txt

case $PLATFORM in
Linux) 
       #os version
       $ECHO "  |___ /etc/SuSE-release"
       $ECHO "OS VERSION(/etc/SuSE-release):" > $LOGFILE_PATH/collect.01_version.txt
       $CAT /etc/SuSE-release >> $LOGFILE_PATH/collect.01_version.txt
       
       #os kernel
       $ECHO "  |___ /etc/sysctl.conf"
       $ECHO "KERNEL(/etc/sysctl.conf):" > $LOGFILE_PATH/collect.04_sysctl_conf.txt
       $CAT /etc/sysctl.conf >> $LOGFILE_PATH/collect.04_sysctl_conf.txt
       
       #os kernel
       $ECHO "  |___ /etc/security/limits.conf"
       $ECHO "KERNEL(/etc/security/limits.conf):" > $LOGFILE_PATH/collect.04_limits.txt
       $CAT /etc/security/limits.conf >> $LOGFILE_PATH/collect.04_limits.txt
              
       #os packages
       $ECHO "  |___ rpm -qa"
       $ECHO "PACKAGES(rpm -qa):" > $LOGFILE_PATH/collect.05_patches.txt
       rpm -qa >> $LOGFILE_PATH/collect.05_patches.txt
       
       #CPU
       $ECHO "  |___ /proc/cpuinfo"
       $ECHO "CPU(/proc/cpuinfo):" > $LOGFILE_PATH/collect.06_cpuinfo.txt
       $CAT /proc/cpuinfo >> $LOGFILE_PATH/collect.06_cpuinfo.txt
       
       $ECHO "  |___ free"       
       $ECHO "FREE MEMORY(free):" > $LOGFILE_PATH/collect.07_freememory.txt
       free >> $LOGFILE_PATH/collect.07_freememory.txt
       
       $ECHO "  |___ free -m -t"
       $ECHO "FREE MEMORY(free -m -t):" >> $LOGFILE_PATH/collect.08_freememory-m-t.txt
       free -m -t >> $LOGFILE_PATH/collect.08_freememory-m-t.txt
       
       $ECHO "  |___ /pro/meminfo"       
       $ECHO "TOTAL MEMORY(/pro/meminfo):" > $LOGFILE_PATH/collect.09_meminfo.txt
       $CAT /proc/meminfo >> $LOGFILE_PATH/collect.09_meminfo.txt
       
       #swap
       $ECHO "  |___ /proc/swaps"
       $ECHO "SWAP(/proc/swaps):" > $LOGFILE_PATH/collect.10_swaps.txt
       $CAT /proc/swaps >> $LOGFILE_PATH/collect.10_swaps.txt
       
       #ipcs
       $ECHO "  |___ ipcs" 
       $ECHO "IPC(ipcs):" > $LOGFILE_PATH/collect.11_ipcs.txt
       ipcs >> $LOGFILE_PATH/collect.11_ipcs.txt
       
       #VG
       $ECHO "  |___ vgdisplay -v"
       $ECHO "VG(vgdisplay -v):" > $LOGFILE_PATH/collect.12_vgdisplay.txt
       vgdisplay -v >> $LOGFILE_PATH/collect.12_vgdisplay.txt 2>&1
       
       #filesystem
       $ECHO "  |___ df -k"
       $ECHO "FILESYSTEM(df -k):" > $LOGFILE_PATH/collect.13_df.txt
       df -k >> $LOGFILE_PATH/collect.13_df.txt
       
       #AIO
       $ECHO "  |___ /proc/slabinfo"
       $ECHO "AIO(/proc/slabinfo | grep kio):" > $LOGFILE_PATH/collect.14_kio.txt
       cat /proc/slabinfo | grep kio >> $LOGFILE_PATH/collect.14_kio.txt
       
       #HISTORY
       $ECHO "  |___ history" 
       $ECHO "HISTORY(history):" > $LOGFILE_PATH/collect.15_history.txt
       history >> $LOGFILE_PATH/collect.15_history.txt
       
       #LOG
       $ECHO "  |___ last"
       $ECHO "LOGON(last):" > $LOGFILE_PATH/collect.16_last.txt
       last >> $LOGFILE_PATH/collect.16_last.txt
       
       #PROCESS
       $ECHO "  |___ ps aux"
       $ECHO "PROCESS(ps aux):" > $LOGFILE_PATH/collect.17_ps_aux.txt
       ps aux >> $LOGFILE_PATH/collect.17_ps_aux.txt
                     
       $ECHO "  |___ arp -v"
       $ECHO "ROUTE(arp -v):" >> $LOGFILE_PATH/collect.19_arp-v.txt       
       arp -v >> $LOGFILE_PATH/collect.19_arp-v.txt
       
       #NETWORK
       network
       
       #OS PERFORMANCE
       osperf      
       ;;
HP-UX)
       #os version
       $ECHO "  |___ uname -a"
       $ECHO "uname -a:" >> $LOGFILE_PATH/collect.01_version.txt
       /bin/uname -a >> $LOGFILE_PATH/collect.01_version.txt
       
       #kernel
       $ECHO "  |___ kctune"
       $ECHO "kctune:" >> $LOGFILE_PATH/collect.01_kctune.txt
       kctune >> $LOGFILE_PATH/collect.01_kctune.txt
       
       #os packages
       $ECHO "  |___ swlist"
       $ECHO "OS PACKAGE:" >> $LOGFILE_PATH/collect.02_swlist.txt
       swlist >> $LOGFILE_PATH/collect.02_swlist.txt
       
       #cpu info
       $ECHO "  |___ ioscan -fnC processor"
       $ECHO "ioscan -fnC processor:" >> $LOGFILE_PATH/collect.03_cpuinfo.txt
       ioscan -fnC processor >> $LOGFILE_PATH/collect.03_cpuinfo.txt
       
       #memory
       $ECHO "  |___ dmesg | grep \"Physical:\""
       $ECHO "dmesg | grep \"Physical:\"" >> $LOGFILE_PATH/collect.04_memory.txt
       dmesg | grep "Physical:" >> $LOGFILE_PATH/collect.04_memory.txt
       
       $ECHO "  |___ free -m -t"
       $ECHO "FREE MEMORY(free -m -t):" >> $LOGFILE_PATH/collect.08_freememory-m-t.txt
       free -m -t >> $LOGFILE_PATH/collect.08_freememory_m_t.txt
       
       #swap
       $ECHO "  |___ swapinfo -q"
       $ECHO "SWAP(swapinfo -q):" > $LOGFILE_PATH/collect.10_swaps.txt
       swapinfo -q >> $LOGFILE_PATH/collect.10_swaps.txt
       
       #ipcs
       $ECHO "  |___ ipcs" 
       $ECHO "IPC(ipcs):" > $LOGFILE_PATH/collect.11_ipcs.txt
       ipcs >> $LOGFILE_PATH/collect.11_ipcs.txt
       
       #VG
       $ECHO "  |___ vgdisplay -v"
       $ECHO "VG(vgdisplay -v):" > $LOGFILE_PATH/collect.12_vgdisplay.txt
       vgdisplay -v >> $LOGFILE_PATH/collect.12_vgdisplay.txt 2>&1
       
       #filesystem
       $ECHO "  |___ bdf"
       $ECHO "FILESYSTEM(bdf):" > $LOGFILE_PATH/collect.13_bdf.txt
       bdf >> $LOGFILE_PATH/collect.13_bdf.txt
       
       #AIO
       $ECHO "  |___ fuser /dev/async"
       $ECHO "AIO(fuser /dev/async):" > $LOGFILE_PATH/collect.14_aio.txt
       fuser /dev/async >> $LOGFILE_PATH/collect.14_aio.txt
       
       #HISTORY
       $ECHO "  |___ history" 
       $ECHO "HISTORY(history):" > $LOGFILE_PATH/collect.15_history.txt
       history >> $LOGFILE_PATH/collect.15_history.txt
       
       #LOG
       $ECHO "  |___ last"
       $ECHO "LOGON(last):" > $LOGFILE_PATH/collect.16_last.txt
       last >> $LOGFILE_PATH/collect.16_last.txt
       
       #PROCESS
       $ECHO "  |___ ps aux"
       $ECHO "PROCESS(ps aux):" > $LOGFILE_PATH/collect.17_ps_aux.txt
       ps aux >> $LOGFILE_PATH/collect.17_ps_aux.txt
       
       #NETWORK
       network
       
       #OS PERFORMANCE
       osperf
       ;;
AIX)
       #OS version
       $ECHO "  |___ oslevel -s"
       $ECHO "OS VERSION:" >> $LOGFILE_PATH/collect.01_version.txt
       oslevel -s >> $LOGFILE_PATH/collect.01_version.txt
       
       #OS VMO
       $ECHO "  |___ vmo -a"
       $ECHO "OS VMO:" >> $LOGFILE_PATH/collect.01_vmo.txt
       vmo -a >> $LOGFILE_PATH/collect.01_vmo.txt
              
       $ECHO "  |___ uname -a"
       $ECHO "uname -a:" >> $LOGFILE_PATH/collect.02_platform.txt
       /bin/uname -a >> $LOGFILE_PATH/collect.02_platform.txt
       
       #os packages
       $ECHO "  |___ lslpp -L all"
       $ECHO "OS PACKAGE:" >> $LOGFILE_PATH/collect.03_lslpp.txt
       lslpp -L all >> $LOGFILE_PATH/collect.03_lslpp.txt
       
       #cpu info
       $ECHO "  |___ lsdev -C | grep -i processor"
       $ECHO "lsdev -C | grep -i processor:" >> $LOGFILE_PATH/collect.04_processor.txt
       lsdev -C | grep -i processor >> $LOGFILE_PATH/collect.04_processor.txt
       
       #memory
       $ECHO "  |___ lsattr -HE -l sys0 -a realmem"
       $ECHO "lsattr -HE -l sys0 -a realmem:" >> $LOGFILE_PATH/collect.05_realmem.txt
       lsattr -HE -l sys0 -a realmem >> $LOGFILE_PATH/collect.05_realmem.txt
       
       #svmon -G
       $ECHO "  |___ svmon -G"
       $ECHO "svmon -G:" >> $LOGFILE_PATH/collect.06_svmon.txt
       svmon -G >> $LOGFILE_PATH/collect.06_svmon.txt
       
       #swap
       $ECHO "  |___ /usr/sbin/lsps -a"
       $ECHO "/usr/sbin/lsps -a:" >> $LOGFILE_PATH/collect.07_lsps.txt
       /usr/sbin/lsps -a >> $LOGFILE_PATH/collect.07_lsps.txt

       #ipcs
       $ECHO "  |___ ipcs" 
       $ECHO "IPC(ipcs):" > $LOGFILE_PATH/collect.11_ipcs.txt
       ipcs >> $LOGFILE_PATH/collect.11_ipcs.txt

       #VG
       $ECHO "  |___ lsvg"
       $ECHO "VG(lsvg):" > $LOGFILE_PATH/collect.12_lsvg.txt
       lsvg >> $LOGFILE_PATH/collect.12_lsvg.txt 2>&1
       
       #filesystem
       $ECHO "  |___ df -k"
       $ECHO "FILESYSTEM(df -k):" > $LOGFILE_PATH/collect.13_df.txt
       df -k >> $LOGFILE_PATH/collect.13_df.txt
       
       #AIO
       $ECHO "  |___ pstat -a | grep aios | wc -l"
       $ECHO "AIO(pstat -a | grep aios | wc -l):" > $LOGFILE_PATH/collect.14_aio.txt
       pstat -a | grep aios | wc -l >> $LOGFILE_PATH/collect.14_aio.txt       
       
       #HISTORY
       $ECHO "  |___ history" 
       $ECHO "HISTORY(history):" > $LOGFILE_PATH/collect.15_history.txt
       history >> $LOGFILE_PATH/collect.15_history.txt
       
       #LOG
       $ECHO "  |___ last"
       $ECHO "LOGON(last):" > $LOGFILE_PATH/collect.16_last.txt
       last >> $LOGFILE_PATH/collect.16_last.txt
       
       #PROCESS
       $ECHO "  |___ ps aux"
       $ECHO "PROCESS(ps aux):" > $LOGFILE_PATH/collect.17_ps_aux.txt
       ps aux >> $LOGFILE_PATH/collect.17_ps_aux.txt
       
       #NETWORK
       network
       
       #OS PERFORMANCE
       osperf       
       ;;
SunOS)
       $ECHO "$PLATFORM DOES NOT SUPPORT"
       exit -1
       ;;
*)     $ECHO "ERROR: Unknown Operating System"
       exit -1
       ;;
esac

exit 0;
