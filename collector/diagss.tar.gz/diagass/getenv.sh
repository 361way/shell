#! /bin/sh

#NAME: getenv.sh
#VERSION: v1.2
#DESCRIPTION: get db\crs enviroment variables, and generates comm.config. diagass.pl then read data from comm.config,
#             after comm.config has been generated, you can edit comm.config, and launch ./diagass.pl --collect --noinit
#             without running getenv.sh.
#
#CREATED:  xuanziqiao@huawei.com 2013-08-28
#
#MODIFIED: xuanziqiao@huawei.com 2013-10-15 get the status of database
#

SU=/bin/su
ECHO=/bin/echo
GREP=/bin/egrep
CAT=/bin/cat
PLATFORM=`/bin/uname`

INITCSSD="/etc/init.d/init.cssd"
case $PLATFORM in
Linux) 
       INITCSSD="/etc/init.d/init.cssd"
       ;;
HP-UX)
       INITCSSD="/sbin/init.d/init.cssd"
       ;;
AIX)
       INITCSSD="/etc/init.cssd"
       ;;
SunOS)
       INITCSSD="/etc/init.d/init.cssd"
       ;;
*)     $ECHO "ERROR: Unknown Operating System"
       exit -1
       ;;
esac

# Location to TR differs in diff. platforms.
TR=/bin/tr
#solaris location (for both SPARC and amd)
[ 'SunOS' = `/bin/uname` ] && TR=/usr/xpg4/bin/tr
#on linux tr is at /usr/bin/tr
[ 'Linux' = `/bin/uname` ] && TR=/usr/bin/tr

GRID_ACCOUNT=$1
[ "x$GRID_ACCOUNT" = "x" ] && GRID_ACCOUNT="grid"

ORACLE_ACCOUNT=$2
[ "x$ORACLE_ACCOUNT" = "x" ] && ORACLE_ACCOUNT="oracle"

ISEXISTS=`$CAT /etc/passwd | grep $ORACLE_ACCOUNT | wc -l`

if [ $ISEXISTS -gt 0 ]; then
    CRS_ORA_HOME=`$SU - $ORACLE_ACCOUNT -c "env | $GREP \"^ORA_CRS_HOME=\"" | awk -F= '{print $2}'`
    ORACLE_HOME=`$SU - $ORACLE_ACCOUNT -c "env | $GREP \"^ORACLE_HOME=\"" | awk -F= '{print $2}'`
    ORACLE_BASE=`$SU - $ORACLE_ACCOUNT -c "env | $GREP \"^ORACLE_BASE=\"" | awk -F= '{print $2}'`
    ORACLE_SID=`$SU - $ORACLE_ACCOUNT -c "env  | $GREP \"^ORACLE_SID=\"" | awk -F= '{print $2}'`
    
    #the variable name of crs home might not CRS_ORA_HOME, so we
    #get crs home from init.css again.
    [ -f "/etc/init.d/init.cssd" ] && CRS_HOME=`/etc/init.d/init.cssd home`
    
    [ "x$CRS_ORA_HOME" = "x" -o "x$CRS_HOME" != "x" ] && CRS_ORA_HOME=$CRS_HOME
    
    #non RAC or crs is not installed.
    [ "x$CRS_ORA_HOME" = "x$ORACLE_HOME" ] && CRS_ORA_HOME=""

    #get ASM instance name
    INITFILE=`/bin/ls $ORACLE_HOME/dbs | $GREP init+`
    if [ "x$INITFILE" != "x" ]; then
        ASM_ORA_SID="+"`echo $INITFILE | awk -F+ '{print $2}' | awk -F\. '{print $1}'`
    else
       SPFILE=`/bin/ls $ORACLE_HOME/dbs | grep spfile+`
       if [ "x$SPFILE" != "x" ]; then
           ASM_ORA_SID="+"`echo $SPFILE | awk -F+ '{print $2}' | awk -F\. '{print $1}'`
       fi
    fi
    
    if [ "x$ASM_ORA_SID" = "x+" ]; then
        ASM_ORA_SID=""
    fi
else
   $ECHO "[ERROR] $2 does not exist!";
fi;

ISEXISTS=`cat /etc/passwd | grep $GRID_ACCOUNT | wc -l`
if [ $ISEXISTS -gt 0 ]; then 
    CRS_ORA_HOME=`$SU - $GRID_ACCOUNT -c "env | $GREP \"^ORACLE_HOME=\"" | awk -F= '{print $2}'`
    ORA_GRID_BASE=`$SU - $GRID_ACCOUNT -c "env | $GREP \"^ORACLE_BASE=\"" | awk -F= '{print $2}'`
    ASM_ORA_SID=`$SU - $GRID_ACCOUNT -c "env | $GREP \"^ORACLE_SID=\""  | awk -F= '{print $2}'`
fi

#get the status of database.
STATUS=`$SU - $ORACLE_ACCOUNT -c 'sqlplus -s /nolog <<EOF
conn / as sysdba
set heading off
set line 200
select open_mode from v\\$database;
exit;
EOF' | $GREP -e "^[A-Za-z]"`

DB_STATUS=""

case $STATUS in
   "MOUNTED")
        DB_STATUS=$STATUS
        ;;
   "READ ONLY")
        DB_STATUS="READONLY"
        ;;
   "READ WRITE")
        DB_STATUS="READWRITE"
        ;;
             
   *)
        DB_STATUS="INVALID"
esac

if [ "x$DB_STATUS" = "xMOUNTED" -o "x$DB_STATUS" = "xREADONLY" -o "x$DB_STATUS" = "xREADWRITE"  ] ; then
    DB_UNIQUE_NAME=`$SU - $ORACLE_ACCOUNT -c "sqlplus -s /nolog <<EOF
    conn / as sysdba
    set heading off
    set line 200
    show parameter db_unique_name;
    exit;
    EOF" | $GREP db_unique_name | awk '{print $3}' | $TR 'A-Z' 'a-z'`
fi

$ECHO "DB_STATUS=$DB_STATUS" > comm.config
$ECHO "ORACLE_HOME=$ORACLE_HOME" >> comm.config
$ECHO "ORACLE_BASE=$ORACLE_BASE" >> comm.config
$ECHO "DB_UNIQUE_NAME=$DB_UNIQUE_NAME" >> comm.config
$ECHO "ORACLE_SID=$ORACLE_SID" >> comm.config
$ECHO "ORA_CRS_HOME=$CRS_ORA_HOME" >> comm.config
$ECHO "ORA_GRID_BASE=$ORA_GRID_BASE" >> comm.config
$ECHO "ORA_ASM_SID=$ASM_ORA_SID" >> comm.config

exit 0;
