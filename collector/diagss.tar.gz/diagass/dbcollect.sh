#! /bin/sh

#NAME: dbcollect.sh
#VERSION: v1.1
#DESCRIPTION: collecting database views, awr & ash
#
#CREATED:  xuanziqiao@huawei.com 2013-08-28
#
#MODIFIED: xuanziqiao@huawei.com 2013-09-11 beautifier html format. the html resource code refer to "dba_snapshot_database" of Jeffrey M. Hunter. 
#          xuanziqiao@huawei.com 2013-09-11 collecting ash. 
#         
#         
#

ACCOUNT=$1
SELECT=$2
CONF_PATH=$3
ORACLE_SID=$4
SQLSCRIPT=$5
BEGIN_DATE=$6
END_DATE=$7

DBID=$8
INST_NUM=$9
     
if [ "x$ACCOUNT" = "x"  ]; then
    ACCOUNT="oracle"
fi

if [ "x$SELECT" = "x" ]; then
    SELECT="dbconf"
fi

if [ "x$CONF_PATH" = "x" ]; then
    CONF_PATH=`pwd`"/log"
fi

if [ "x$BEGIN_DATE" = "x" ]; then
    BEGIN_DATE=`date "+%Y%m%d000000"`
fi

if [ "x$END_DATE" = "x" ]; then
    END_DATE=`date "+%Y%m%d%H%M%S"`
fi

SU="su"
ECHO="echo"
MV="mv"

case $SELECT in
dbconf)

      $ECHO "  |___ v\$version"
      $ECHO "  |___ v\$parameter"
      $ECHO "  |___ v\$option"
      $ECHO "  |___ v\$instance"
      $ECHO "  |___ v\$database"
      $ECHO "  |___ database_properties"
      $ECHO "  |___ dba_services"
      $ECHO "  |___ v\$resource_limit"
      $ECHO "  |___ dba_feature_usage_statistics"
      $ECHO "  |___ v\$statistics_level"
      $ECHO "  |___ dba_high_water_mark_statistics"
      $ECHO "  |___ v\$sga"
      $ECHO "  |___ v\$sga_resize_ops"
      $ECHO "  |___ v\$sga_dynamic_components"
      $ECHO "  |___ v\$controlfile"
      $ECHO "  |___ v\$controlfile_record_section"
      $ECHO "  |___ v\$datafile"
      $ECHO "  |___ dba_data_files"
      $ECHO "  |___ v\$filestat"
      $ECHO "  |___ v\$undostat"
      $ECHO "  |___ dba_undo_extents"
      $ECHO "  |___ v\$logfile"
      $ECHO "  |___ v\$log"
      $ECHO "  |___ v\$log_history"
      $ECHO "  |___ v\$session"
      $ECHO "  |___ v\$bgprocess"
      $ECHO "  |___ v\$process"
      $ECHO "  |___ dba_mviews"
      $ECHO "  |___ dba_mview_logs"
      $ECHO "  |___ dba_mview_refresh_times"
      $ECHO "  |___ dba_autotask_job_history"
      $ECHO "  |___ dba_scheduler_windows"
      $ECHO "  |___ dba_jobs"
      $ECHO "  |___ dba_hist_wr_control"
      
 
      $SU - $ACCOUNT -c 'sqlplus -s /nolog <<EOF
      conn / as sysdba
      alter session set nls_date_format='\''yyyy-mm-dd hh24:mi:ss'\'';
      
      set termout       off
      set echo          off
      set feedback      off
      set verify        off
      set wrap          on
      set trimspool     on
      set serveroutput  on
      set escape        on
      
      set pagesize 50000
      set linesize 175
      set long     2000000000
      
      set heading on

      set markup html on spool on preformat off entmap on -
      head '\'' -
        <style type="text/css"> -
          body              {font-family: Lucida Grande,Lucida Sans,Arial,sans-serif; font-size: 13px; background:white;} -
          p                 {font-family: Lucida Grande,Lucida Sans,Arial,sans-serif; font-size: 13px;} -
          table,tr          {color: #000000;font-weight: bold;border-spacing: 0;outline: medium none;font-family: Lucida Grande,Lucida Sans,Arial,sans-serif;font-size: 12px;} -
          td                {background: #F2F5F7; border: 1px solid #AED0EA; font-weight: normal; padding: 5;} -
          th                {background: #D7EBF9;  border: 1px solid #AED0EA; font-size: 13px; font-weight: bold;} -
          h1                {color:blue;} -
          h2                {color:blue; background:white;} -
          a                 {color: #000000;} -
        </style> '\'' -         
      body   '\''BGCOLOR="#C0C0C0"'\'' -
      table  '\''WIDTH="90%" BORDER="1"'\''
      
      column dbname new_value _dbname noprint
      column dbid new_value _dbid noprint
      column platform_name new_value _platform_name noprint
      column platform_id new_value _platform_id noprint
      column resetlogs_time new_value _resetlogs_time noprint
      column log_mode new_value _log_mode noprint
      column checkpoint_change new_value _checkpoint_change noprint
      column archive_change new_value _archive_change noprint
      column controlfile_type new_value _controlfile_type noprint
      column controlfile_converted new_value _controlfile_converted noprint
      column open_resetlogs new_value _open_resetlogs noprint
      column open_mode new_value _open_mode noprint
      column remote_archive new_value _remote_archive noprint
      column protection_mode new_value _protection_mode noprint
      column protection_level new_value _protection_level noprint
      column database_role new_value _database_role noprint
      column switchover_status new_value _switchover_status noprint
      column guard_status new_value _guard_status noprint
      column force_logging new_value _force_logging noprint
      column current_scn new_value _current_scn noprint
      column flashback_on new_value _flashback_on noprint
      column db_unique_name new_value _db_unique_name noprint
      column primary_db_unique_name new_value _primary_db_unique_name noprint
      
      select dbid, name dbname, platform_name, platform_id,
             to_char(resetlogs_time, '\''yyyy-mm-dd hh24:mi:ss'\'') resetlogs_time, 
             log_mode, checkpoint_change# checkpoint_change, 
             archive_change# archive_change, controlfile_type, controlfile_converted,
             open_resetlogs, open_mode, remote_archive, protection_mode, 
             protection_level, database_role, switchover_status, guard_status, 
             force_logging, current_scn, flashback_on, db_unique_name, primary_db_unique_name
       from v\$database d;
      
      column host_name new_value _host_name noprint
      column instance_name new_value _instance_name noprint
      column instance_number new_value _instance_number noprint
      column thread_number new_value _thread_number noprint
      
      select host_name, instance_name, instance_number,
             thread# thread_number
       from v\$instance;
      
      column global_name new_value _global_name noprint
      select global_name global_name from global_name;
      
      column blocksize new_value _blocksize noprint
      select value blocksize from v\$parameter where name='\''db_block_size'\'';
      
      column startup_time new_value _startup_time noprint
      select to_char(startup_time, '\''yyyy-mm-dd hh24:mi:ss'\'') startup_time from v\$instance;
      
      column cluster_database new_value _cluster_database noprint
      select value cluster_database from v\$parameter where name='\''cluster_database'\'';
      
      column cluster_database_instances new_value _cluster_database_instances noprint
      select value cluster_database_instances from v\$parameter where name='\''cluster_database_instances'\'';

      set markup html on entmap off
      
      spool /tmp/collect.01_Overview.html
      
      prompt <script language="JavaScript">  -
                 function ShowHideRegion(divId) -
                 { -                
                    if(document.getElementById(divId).style.display == '\''none'\'') -
                    {  -
                        var divlist; -
                       if (document.all || document.getElementById) { divlist = document.getElementsByTagName("div"); } -
                       for(var i = 0; i< divlist.length; i++){ if(divlist[i].id != ""){  -
                          document.getElementById(divlist[i].id).style.display='\''none'\'';}} -
                       document.getElementById(divId).style.display = '\''block'\''; -
                    } -
                    else -
                    {  -
                       document.getElementById(divId).style.display = '\''none'\''; } -
                    }  - 
             </script>      
      --Index
      --
      prompt <a name="index"></a>
      prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Overview</b></font><hr align="center" width="250"></center> -
             <table width="90%" border="1"> -
                 <tr><th colspan="8">Database and Instance Information</th></tr> -
                 <tr> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''abstract'\'');">Database Abstract</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''version'\'');">Version</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''control_files'\'');">Control files</a></td> -          
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''init_params'\'');">Initial Params</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''option'\'');">Installation Options</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''database_properties'\'');">Database Properties</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''online_redo_logs'\'');">Online Redo Logs</a></td> -  
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''redo_log_switches'\'');">Redo Logs Switches</a></td> -     
                 </tr>
     prompt      <tr> -          
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''services'\'');">Services</a></td> -          
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''database_registry'\'');">Database Registry</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''resource_limit'\'');">Resource Limit</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''feature_usage_statistics'\'');">Feature Usage Statistics</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''database_properties'\'');">Database Properties</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''statistics_level'\'');">Statistics Level</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''cpu_usage_statistics'\'');">CPU Usage</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''high_water_mark_statistics'\'');">High Water Mark</a></td> -
                 </tr>
    prompt       <tr> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''control_file_records'\'');">Control File Records</a></td> -       
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''data_files'\'');">Data Files</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''tablespaces'\'');">Tablespaces</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''tablespace_extents'\'');">Tablespace Extents</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''undo_segments'\'');">Undo Segments</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sga'\'');">SGA Information</a></td> -     
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''profiler'\'');">User Profile</a></td> -  
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''users'\'');">User Information</a></td> -     
                 </tr>
    prompt       <tr><th colspan="8">Jobs and Objects Status</th></tr> -
                 <tr> -            
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''awr_settings'\'');">AWR Settings</a></td> -  
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''autotask'\'');">Auto Task running History</a></td> -  
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sheduler_window'\'');">Sheduler Window</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''jobs'\'');">Jobs</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''invalid_objects'\'');">Invalid Objects</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''dependency'\'');">Object Dependency</a></td> - 
                 </tr>                        
    prompt       <tr><th colspan="8">Backups</th></tr> -
                 <tr> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''rman_backup_jobs'\'');">RMAN Backup Jobs</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''rman_configuration'\'');">RMAN Configuration</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''rman_backup_sets'\'');">RMAN Backup Sets</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''rman_backup_pieces'\'');">RMAN Backup Pieces</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''rman_backup_control_files'\'');">RMAN Backup Control Files</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''rman_backup_spfile'\'');">RMAN Backup SPFILE</a></td> - 
                 </tr> -         
            </table>
      
      --overview
      --  
      prompt <div id="abstract" style="DISPLAY: block">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Abstract</b></font><hr align="left" width="460">
      
      prompt <table width="90%" border="1"> -
      <tr><th align="left" width="20%">Host Name</th><td width="30%"><tt>&_host_name</tt></td><th align="left" width="20%">Platform Name / ID</th><td width="30%"><tt>&_platform_name / &_platform_id</tt></td></tr> -
      <tr><th align="left" width="20%">Database Name</th><td width="30%"><tt>&_dbname</tt></td><th align="left" width="20%">Database ID</th><td width="30%"><tt>&_dbid</tt></td></tr> -
      <tr><th align="left" width="20%">DB_UNIQUE_NAME</th><td width="30%"><tt>&_db_unique_name</tt></td><th align="left" width="20%">PRIMARY_DB_UNIQUE_NAME</th><td width="30%"><tt>&_primary_db_unique_name</tt></td></tr> -
      <tr><th align="left" width="20%">Global Database Name</th><td width="30%"><tt>&_global_name</tt></td><th align="left" width="20%">Database Role</th><td width="30%"><tt>&_database_role</tt></td></tr> -
      <tr><th align="left" width="20%">Clustered Database?</th><td width="30%"><tt>&_cluster_database</tt></td><th align="left" width="20%">Clustered Database Instances</th><td width="30%"><tt>&_cluster_database_instances</tt></td></tr> -
      <tr><th align="left" width="20%">Instance Name</th><td width="30%"><tt>&_instance_name</tt></td><th align="left" width="20%">Instance Number</th><td width="30%"><tt>&_instance_number</tt></td></tr>
      
      prompt <tr><th align="left" width="20%">Thread Number</th><td width="30%"><tt>&_thread_number</tt></td><th align="left" width="20%">Database Startup Time</th><td width="30%"><tt>&_startup_time</tt></td></tr> -    
      <tr><th align="left" width="20%">Database Open Mode</th><td width="30%"><tt>&_open_mode</tt></td><th align="left" width="20%">Flashback On?</th><td width="30%"><tt>&_flashback_on</tt></td></tr> -  
      <tr><th align="left" width="20%">Log Archive?</th><td width="30%"><tt>&_log_mode</tt></td><th align="left" width="20%">Force Logging?</th><td width="30%"><tt>&_force_logging</tt></td></tr> -  
      <tr><th align="left" width="20%">Controlfile Type</th><td width="30%"><tt>&_controlfile_type</tt></td><th align="left" width="20%">Controlfile Converted?</th><td width="30%"><tt>&_controlfile_converted</tt></td></tr> -  
      <tr><th align="left" width="20%">Protection Mode</th><td width="30%"><tt>&_protection_mode</tt></td><th align="left" width="20%">Protection Level</th><td width="30%"><tt>&_protection_level</tt></td></tr> -
      <tr><th align="left" width="20%">Guard Status</th><td width="30%"><tt>&_guard_status</tt></td><th align="left" width="20%">Switchover Status</th><td width="30%"><tt>&_switchover_status</tt></td></tr> -  
      <tr><th align="left" width="20%">Current SCN</th><td width="30%"><tt>&_current_scn</tt></td><th align="left" width="20%">Checkpoint Change</th><td width="30%"><tt>&_checkpoint_change</tt></td></tr> -
      <tr><th align="left" width="20%">Remote Archive</th><td width="30%"><tt>&_remote_archive</tt></td><th align="left" width="20%">Archive Change</th><td width="30%"><tt>&_archive_change</tt></td></tr> -
      <tr><th align="left" width="20%">Open Resetlogs</th><td width="30%"><tt>&_open_resetlogs</tt></td><th align="left" width="20%">Resetlogs Time</th><td width="30%"><tt>&_resetlogs_time</tt></td></tr> -
      </table> -
      <center>[<a class="noLink" href="javascript:ShowHideRegion('\''abstract'\'');">close</a>]</center><p> -
      </div>
      
      --version
      --
      prompt <div id="version" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Version</b></font><hr align="left" width="460">
      
      clear columns breaks computes
      column banner   format a120   heading '\''Banner'\''

      select * from v\$version;
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''version'\'');">close</a>]</center><p></div>
      
      --parameter
      --
      prompt <div id="init_params" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Initialization Parameters</b></font><hr align="left" width="460">
      clear columns breaks computes      
      column spfile  heading '\''spfile usage'\''
      
      select
        '\''this database '\'' ||
        decode(   (1-sign(1-sign(count(*) - 0))), 1 , '\''<font color="#663300"><b>is</b></font>'\''
                , '\''<font color="#990000"><b>is not</b></font>'\'') ||  '\'' using an spfile.'\'' spfile
      from v\$spparameter
      where value is not null; 
               
      select name, value, isdefault, ismodified, isadjusted from v\$parameter
      union
      select
        x.ksppinm  name,
        y.ksppstvl  value,
        y.ksppstdf  isdefault,
        decode(bitand(y.ksppstvf,7),1,'\''MODIFIED'\'',4,'\''SYSTEM_MOD'\'','\''FALSE'\'')  ismodified,
        decode(bitand(y.ksppstvf,2),2,'\''TRUE'\'','\''FALSE'\'')  isadjusted
      from
        sys.x\$ksppi x,
        sys.x\$ksppcv y
      where
        x.inst_id = userenv('\''Instance'\'') and
        y.inst_id = userenv('\''Instance'\'') and
        x.indx = y.indx and
        x.ksppinm like '\''_%'\'';
        
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''init_params'\'');">close</a>]</center><p></div>
      
      --option
      prompt <div id="option" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Installation Options</b></font><hr align="left" width="460">
      
      clear columns breaks computes

      column parameter      heading '\''Option Name'\''      entmap off
      column value          heading '\''Installed?'\''       entmap off
      
      select
          decode(   value
                  , '\''FALSE'\''
                  , '\''<b><font color="#336699">'\'' || parameter || '\''</font></b>'\''
                  , '\''<b><font color="#336699">'\'' || parameter || '\''</font></b>'\'') parameter
        , decode(   value
                  , '\''FALSE'\''
                  , '\''<div align="center"><font color="#990000"><b>'\'' || value || '\''</b></font></div>'\''
                  , '\''<div align="center">'\'' || value || '\''</div>'\'' ) value
      from v\$option
      order by parameter;

      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''option'\'');">close</a>]</center><p></div>
      
      
      --DATABASE REGISTRY
      --      
      prompt <div id="database_registry" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Registry</b></font><hr align="left" width="460">
      
      clear columns breaks computes'"
      
      column comp_id       format a75   heading 'Component ID'       entmap off
      column comp_name     format a75   heading 'Component Name'     entmap off
      column version                    heading 'Version'            entmap off
      column status        format a75   heading 'Status'             entmap off
      column modified      format a75   heading 'Modified'           entmap off
      column control                    heading 'Control'            entmap off
      column schema                     heading 'Schema'             entmap off
      column procedure                  heading 'Procedure'          entmap off
      
      select
          '<font color=\"#336699\"><b>' || comp_id    || '</b></font>' comp_id
        , '<div nowrap>' || comp_name || '</div>'                    comp_name
        , version
        , DECODE(   status
                  , 'VALID',   '<div align="center"><b><font color="darkgreen">' || status || '</font></b></div>'
                  , 'INVALID', '<div align="center"><b><font color="#990000">'   || status || '</font></b></div>'
                  ,            '<div align="center"><b><font color="#663300">'   || status || '</font></b></div>' ) status
        , '<div nowrap align=\"right\">' || modified || '</div>'                      modified
        , control
        , schema
        , procedure
      FROM dba_registry
      ORDER BY comp_name;"'

      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''database_registry'\'');">close</a>]</center><p></div>
      
      --CONTROL FILES
      --      
      prompt <div id="control_files" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Control Files</b></font><hr align="left" width="460">
      
      clear columns breaks computes'"
      
      column name                           heading 'Controlfile Name'  entmap off
      column status           format a75    heading 'Status'            entmap off
      column file_size        format a75    heading 'File Size'         entmap off
      
      select
          '<tt>' || c.name || '</tt>'                                                                      name
        , decode(   c.status
                  , NULL
                  ,  '<div align="center"><b><font color="darkgreen">VALID</font></b></div>'
                  ,  '<div align="center"><b><font color="#663300">'   || c.status || '</font></b></div>') status
        , '<div align="right">' || TO_CHAR(block_size *  file_size_blks, '999,999,999,999') || '</div>'    file_size
      from"' 
          v\$controlfile c
      order by
          c.name;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''control_files'\'');">close</a>]</center><p></div>
            
      --database_properties
      prompt <div id="database_properties" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Properties</b></font><hr align="left" width="460">
      
      select d.property_name, d.property_value, d.description from database_properties d;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''database_properties'\'');">close</a>]</center><p></div>
      
      --services
      prompt <div id="services" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Services</b></font><hr align="left" width="460">
      select * from dba_services;
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''services'\'');">close</a>]</center><p></div>
      
      --resource limit
      prompt <div id="resource_limit" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Resource Limit</b></font><hr align="left" width="460">
      select * from v\$resource_limit;
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''resource_limit'\'');">close</a>]</center><p></div>
      
      --feature usage statistics
      prompt <div id="feature_usage_statistics" style="DISPLAY: none">      
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Feature Usage Statistics</b></font><hr align="left" width="460">      
      
      clear columns breaks computes

      column feature_name          format a115    heading '\''Feature|Name'\''
      column version               format a75     heading '\''Version'\''
      column detected_usages       format 9999    heading '\''Detected|Usages'\''
      column total_samples         format 99999   heading '\''Total|Samples'\''
      column currently_used        format a60     heading '\''Currently|Used'\''
      column first_usage_date      format a95     heading '\''First Usage|Date'\''
      column last_usage_date       format a95     heading '\''Last Usage|Date'\''
      column last_sample_date      format a95     heading '\''Last Sample|Date'\''
      column next_sample_date      format a95     heading '\''Next Sample|Date'\''
      
      select name feature_name, version, detected_usages, total_samples, currently_used, 
             first_usage_date, last_usage_date,  last_sample_date, last_sample_date + sample_interval/60/60/24 next_sample_date
        from dba_feature_usage_statistics
       order by name;
          
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''feature_usage_statistics'\'');">close</a>]</center><p></div>
      
      --database properties
      prompt <div id="database_properties" style="DISPLAY: none">      
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Properties</b></font><hr align="left" width="460">
      select * from database_properties;
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''database_properties'\'');">close</a>]</center><p></div>
            
      --statistics_level
      prompt <div id="statistics_level" style="DISPLAY: none">      
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Statistics Level</b></font><hr align="left" width="460">
      select * from v\$statistics_level;      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''statistics_level'\'');">close</a>]</center><p></div>

      --cpu_usage_statistics
      prompt <div id="cpu_usage_statistics" style="DISPLAY: none">      
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>CPU Usage</b></font><hr align="left" width="460"> 
      select * from dba_cpu_usage_statistics;
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''cpu_usage_statistics'\'');">close</a>]</center><p></div>
      
      --high_water_mark_statistics
      prompt <div id="high_water_mark_statistics" style="DISPLAY: none">      
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>High Water Mark</b></font><hr align="left" width="460">
      
      column dbid format 999999999999
      column name format a30
      column version format a10
      column highwater format 9999999999999999
      column last_value format 9999999999999999
      
      select dbid, name, version, highwater, last_value, description from dba_high_water_mark_statistics;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''high_water_mark_statistics'\'');">close</a>]</center><p></div>

      --redo file.
      prompt <div id="online_redo_logs" style="DISPLAY: none"> 
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Online Redo Logs</b></font><hr align="left" width="460">
      
      clear columns breaks computes
      
      column instance_name_print  format a95                heading '\''Instance Name'\'' entmap off
      column thread_number_print  format 999                heading '\''Thread Number'\'' entmap off
      column groupno                                        heading '\''Group Number'\''  entmap off
      column member                                         heading '\''Member'\''        entmap off
      column redo_file_type       format a75                heading '\''Redo Type'\''     entmap off
      column log_status           format a75                heading '\''Log Status'\''    entmap off
      column bytes                format 999,999,999,999    heading '\''Bytes'\''         entmap off
      column archived             format a75                heading '\''Archived?'\''     entmap off
      
      break on report on instance_name_print on thread_number_print
      
      select i.instance_name instance_name_print, i.thread# thread_number_print, f.group# groupno,
             f.member member, f.type redo_file_type, l.status log_status, 
             l.bytes bytes,l.archived archived
      from gv\$logfile  f, gv\$log l , gv\$instance i
      where f.group#  = l.group#
        and l.thread# = i.thread#
        and i.inst_id = f.inst_id
        and f.inst_id = l.inst_id
      order by i.instance_name, f.group#, f.member;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''online_redo_logs'\'');">close</a>]</center><p></div>
      
      --redo_log_switches
      --
      prompt <div id="redo_log_switches" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Redo Log Switches</b></font><hr align="left" width="460">
      
      clear columns breaks computes
      
      column day   format a75              heading '\''Day / Time'\''  entmap off
      column h00   format 999,999b         heading '\''00'\''          entmap off
      column h01   format 999,999b         heading '\''01'\''          entmap off
      column h02   format 999,999b         heading '\''02'\''          entmap off
      column h03   format 999,999b         heading '\''03'\''          entmap off
      column h04   format 999,999b         heading '\''04'\''          entmap off
      column h05   format 999,999b         heading '\''05'\''          entmap off
      column h06   format 999,999b         heading '\''06'\''          entmap off
      column h07   format 999,999b         heading '\''07'\''          entmap off
      column h08   format 999,999b         heading '\''08'\''          entmap off
      column h09   format 999,999b         heading '\''09'\''          entmap off
      column h10   format 999,999b         heading '\''10'\''          entmap off
      column h11   format 999,999b         heading '\''11'\''          entmap off
      column h12   format 999,999b         heading '\''12'\''          entmap off
      column h13   format 999,999b         heading '\''13'\''          entmap off
      column h14   format 999,999b         heading '\''14'\''          entmap off
      column h15   format 999,999b         heading '\''15'\''          entmap off
      column h16   format 999,999b         heading '\''16'\''          entmap off
      column h17   format 999,999b         heading '\''17'\''          entmap off
      column h18   format 999,999b         heading '\''18'\''          entmap off
      column h19   format 999,999b         heading '\''19'\''          entmap off
      column h20   format 999,999b         heading '\''20'\''          entmap off
      column h21   format 999,999b         heading '\''21'\''          entmap off
      column h22   format 999,999b         heading '\''22'\''          entmap off
      column h23   format 999,999b         heading '\''23'\''          entmap off
      column total format 999,999,999      heading '\''Total'\''       entmap off
      
      break on report
      compute sum label '\''<font color="#990000"><b>total:</b></font>'\'' avg label '\''<font color="#990000"><b>average:</b></font>'\'' of total on report
      
      select
          '\''<div align="center"><font color="#336699"><b>'\'' || substr(to_char(first_time, '\''mm/dd/rr hh:mi:ss'\''),1,5)  || '\''</b></font></div>'\''  day
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''00'\'',1,0)) h00
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''01'\'',1,0)) h01
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''02'\'',1,0)) h02
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''03'\'',1,0)) h03
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''04'\'',1,0)) h04
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''05'\'',1,0)) h05
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''06'\'',1,0)) h06
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''07'\'',1,0)) h07
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''08'\'',1,0)) h08
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''09'\'',1,0)) h09
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''10'\'',1,0)) h10
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''11'\'',1,0)) h11
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''12'\'',1,0)) h12
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''13'\'',1,0)) h13
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''14'\'',1,0)) h14
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''15'\'',1,0)) h15
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''16'\'',1,0)) h16
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''17'\'',1,0)) h17
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''18'\'',1,0)) h18
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''19'\'',1,0)) h19
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''20'\'',1,0)) h20
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''21'\'',1,0)) h21
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''22'\'',1,0)) h22
        , sum(decode(substr(to_char(first_time, '\''mm/dd/rr hh24:mi:ss'\''),10,2),'\''23'\'',1,0)) h23
        , count(*)                                                                           total
      from
        v\$log_history  a
      group by substr(to_char(first_time, '\''mm/dd/rr hh:mi:ss'\''),1,5)
      order by substr(to_char(first_time, '\''mm/dd/rr hh:mi:ss'\''),1,5)
      /
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''redo_log_switches'\'');">close</a>]</center><p></div>     
      
      
      -- CONTROL FILE RECORDS
      --
      
      prompt <div id="control_file_records" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Control File Records</b></font><hr align="left" width="460">
      
      clear columns breaks computes
      
      column type           format          a95    heading '\''Record Section Type'\''      entmap off
      column record_size    format       999,999   heading '\''Record Size|(in bytes)'\''   entmap off
      column records_total  format       999,999   heading '\''Records Allocated'\''        entmap off
      column bytes_alloc    format   999,999,999   heading '\''Bytes Allocated'\''          entmap off
      column records_used   format       999,999   heading '\''Records Used'\''             entmap off
      column bytes_used     format   999,999,999   heading '\''Bytes Used'\''               entmap off
      column pct_used       format          b999   heading '\''% Used'\''                   entmap off
      column first_index                           heading '\''First Index'\''              entmap off
      column last_index                            heading '\''Last Index'\''               entmap off
      column last_recid                            heading '\''Last RecID'\''               entmap off
      
      break on report
      compute sum label '\''<font color="#990000"><b>total: </b></font>'\''   of record_size records_total bytes_alloc records_used bytes_used on report
      compute avg label '\''<font color="#990000"><b>average: </b></font>'\'' of pct_used      on report
      
      select
          '\''<div align="left"><font color="#336699"><b>'\'' || type || '\''</b></font></div>'\''  type
        , record_size                                       record_size
        , records_total                                     records_total
        , (records_total * record_size)                     bytes_alloc
        , records_used                                      records_used
        , (records_used * record_size)                      bytes_used
        , NVL(records_used/records_total * 100, 0)          pct_used
        , first_index                                       first_index
        , last_index                                        last_index
        , last_recid                                        last_recid
      from v\$controlfile_record_section
      order by type;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''control_file_records'\'');">close</a>]</center><p></div>

      --  DATA FILES
      -- 
      prompt <div id="data_files" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Data Files</b></font><hr align="left" width="460">
      
      clear columns breaks computes
      
      column tablespace                                   heading '\''Tablespace Name / File Class'\''  entmap off
      column filename                                     heading '\''Filename'\''                      entmap off
      column filesize        format 999,999,999,999,999   heading '\''File Size'\''                     entmap off
      column autoextensible                               heading '\''Autoextensible'\''                entmap off
      column increment_by    format 999,999,999,999,999   heading '\''Next'\''                          entmap off
      column maxbytes        format 999,999,999,999,999   heading '\''Max'\''                           entmap off
      
      break on report
      compute sum label '\''<font color="#990000"><b>total: </b></font>'\'' of filesize on report
      
      select /*+ ordered */d.tablespace_name tablespace, d.file_name filename, d.bytes filesize, 
             d.autoextensible autoextensible, d.increment_by * e.value increment_by, d.maxbytes maxbytes
       from sys.dba_data_files d, v\$datafile v, (select value from v\$parameter where name = '\''db_block_size'\'') e
      where d.file_name = v.name
      union
      select d.tablespace_name tablespace, d.file_name filename , d.bytes filesize, d.autoextensible autoextensible, 
             d.increment_by * e.value increment_by, d.maxbytes maxbytes
       from sys.dba_temp_files d, (select value from v\$parameter where name = '\''db_block_size'\'') e;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''data_files'\'');">close</a>]</center><p></div>

      --tablespace
      --
      prompt <div id="tablespaces" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tablespaces</b></font><hr align="left" width="460">
      
      clear columns breaks computes
      
      column status                                  heading '\''Status'\''            entmap off
      column name                                    heading '\''Tablespace Name'\''   entmap off
      column type        format a12                  heading '\''TS Type'\''           entmap off
      column extent_mgt  format a10                  heading '\''Ext. Mgt.'\''         entmap off
      column segment_mgt format a9                   heading '\''Seg. Mgt.'\''         entmap off
      column ts_size     format 999,999,999,999,999  heading '\''Tablespace Size'\''   entmap off
      column free        format 999,999,999,999,999  heading '\''Free (in bytes)'\''   entmap off
      column used        format 999,999,999,999,999  heading '\''Used (in bytes)'\''   entmap off
      column pct_used                                heading '\''Pct. Used'\''         entmap off
      
      break on report
      compute sum label '\''Total:'\''   of ts_size used free on report
      
      select d.status, d.tablespace_name name, d.contents , d.extent_management extent_mgt, d.segment_space_management segment_mgt, 
             nvl(a.bytes, 0) ts_size, nvl(f.bytes, 0) free, nvl(a.bytes - nvl(f.bytes, 0), 0) used, 
             to_char(trunc(nvl((a.bytes - nvl(f.bytes, 0)) / a.bytes * 100, 0))) pct_used
      from  sys.dba_tablespaces d, ( select tablespace_name, sum(bytes) bytes from dba_data_files group by tablespace_name) a, ( select tablespace_name, sum(bytes) bytes from dba_free_space group by tablespace_name) f
      where d.tablespace_name = a.tablespace_name(+)
        and d.tablespace_name = f.tablespace_name(+)
        and not (d.extent_management like '\''LOCAL'\'' and d.contents like '\''TEMPORARY'\'')
      union all 
      select d.status, d.tablespace_name name, d.contents type, d.extent_management extent_mgt, d.segment_space_management segment_mgt, 
             nvl(a.bytes, 0) ts_size, nvl(a.bytes - nvl(t.bytes,0), 0) free, nvl(t.bytes, 0) used, 
             to_char(trunc(nvl(t.bytes / a.bytes * 100, 0))) pct_used
      from sys.dba_tablespaces d, ( select tablespace_name, sum(bytes) bytes from dba_temp_files group by tablespace_name) a, 
           (select tablespace_name, sum(bytes_cached) bytes from v\$temp_extent_pool group by tablespace_name ) t
      where d.tablespace_name = a.tablespace_name(+)
        and d.tablespace_name = t.tablespace_name(+)
        and d.extent_management like '\''LOCAL'\''
        and d.contents like '\''TEMPORARY'\''
      order by 2;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''tablespaces'\'');">close</a>]</center><p></div>

      prompt <div id="tablespace_extents" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tablespace Extents</b></font><hr align="left" width="460">
      
      column largest_ext  format  999,999,999,999,999
      column smallest_ext format  999,999,999,999,999
      column total_free   format  999,999,999,999,999
      
      break on report
      compute sum label '\''Total:'\'' of largest_ext smallest_ext total_free pieces on report
      
      select tablespace_name,
             max(bytes) largest_ext,
             min(bytes) smallest_ext,
             sum(bytes) total_free,
             count(*) pieces
        from dba_free_space
       group by tablespace_name
       order by tablespace_name;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''tablespace_extents'\'');">close</a>]</center><p></div>

      --undo segment
      --
      prompt <div id="undo_segments" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Undo Segments</b></font><hr align="left" width="460"> 
      
      clear columns breaks computes
      
      column instance_name format a75              heading '\''Instance Name'\''      entmap off
      column tablespace    format a85              heading '\''Tablspace'\''          entmap off
      column roll_name                             heading '\''UNDO Segment Name'\''  entmap off
      column in_extents                            heading '\''Init/Next Extents'\''  entmap off
      column m_extents                             heading '\''Min/Max Extents'\''    entmap off
      column status                                heading '\''Status'\''             entmap off
      column wraps         format 999,999,999      heading '\''Wraps'\''              entmap off
      column shrinks       format 999,999,999      heading '\''Shrinks'\''            entmap off
      column opt           format 999,999,999,999  heading '\''Opt. Size'\''          entmap off
      column bytes         format 999,999,999,999  heading '\''Bytes'\''              entmap off
      column extents       format 999,999,999      heading '\''Extents'\''            entmap off
      
      clear computes breaks
      break on report on instance_name on tablespace
      select i.instance_name, a.tablespace_name tablespace, a.owner || '\''.'\'' || a.segment_name roll_name,  
             to_char(a.initial_extent) || '\'' / '\'' || to_char(a.next_extent) in_extents, 
             to_char(a.min_extents) || '\'' / '\'' || to_char(a.max_extents) m_extents, a.status, b.bytes, 
             b.extents, d.shrinks, d.wraps, d.optsize opt
        from dba_rollback_segs a, dba_segments b, v\$rollname c, v\$rollstat d, gv\$parameter p, gv\$instance  i
       where a.segment_name  = b.segment_name
         and a.segment_name  = c.name (+)
         and c.usn           = d.usn (+)
         and p.name (+)      = '\''undo_tablespace'\''
         and  p.value (+)     = a.tablespace_name
         and  p.inst_id       = i.inst_id (+)
       order by a.tablespace_name, a.segment_name;

      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''undo_segments'\'');">close</a>]</center><p></div>

      --sga
      --
      prompt <div id="sga" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SGA Information</b></font><hr align="left" width="460"> 

      select * from v\$sga;
      
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SGA Statistics</b></font><hr align="left" width="460"> 
      select * from v\$sgastat order by bytes desc;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sga'\'');">close</a>]</center><p></div>

      --profile
      --
      prompt <div id="profiler" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>User Profile</b></font><hr align="left" width="460"> 
      
      break on report on profile 
      select d.profile, d.resource_name, d.resource_type, d.limit from dba_profiles d order by profile;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''profiler'\'');">close</a>]</center><p></div>
      
      --users
      --
      prompt <div id="users" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>User Information</b></font><hr align="left" width="460"> 

      select d.username, d.account_status, d.lock_date, d.expiry_date, 
             d.default_tablespace, d.temporary_tablespace, d.profile 
        from dba_users d;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''users'\'');">close</a>]</center><p></div>

      --RMAN BACKUP JOBS
      --
      prompt <div id="rman_backup_jobs" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Jobs</b></font><hr align="left" width="460">
      
      prompt <b>last 10 rman backup jobs</b>
      
      clear columns breaks computes
      
      column backup_name           format a130   heading '\''Backup Name'\''          entmap off
      column start_time            format a75    heading '\''Start Time'\''           entmap off
      column elapsed_time          format a75    heading '\''Elapsed Time'\''         entmap off
      column status                              heading '\''Status'\''               entmap off
      column input_type                          heading '\''Input Type'\''           entmap off
      column output_device_type                  heading '\''Output Devices'\''       entmap off
      column input_size                          heading '\''Input Size'\''           entmap off
      column output_size                         heading '\''Output Size'\''          entmap off
      column output_rate_per_sec                 heading '\''Output Rate Per Sec'\''  entmap off
      
      select r.command_id backup_name, to_char(r.start_time, '\''yyyy-mm-dd hh24:mi:ss'\'') start_time,
             r.time_taken_display elapsed_time, r.status, r.input_type, r.output_device_type, r.input_bytes_display input_size, 
             r.output_bytes_display output_size, r.output_bytes_per_sec_display output_rate_per_sec
        from(select command_id, start_time, time_taken_display, status, input_type, output_device_type, 
                    input_bytes_display, output_bytes_display, output_bytes_per_sec_display
               from v\$rman_backup_job_details
              order by start_time desc
            ) r
       where rownum < 11; 
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''rman_backup_jobs'\'');">close</a>]</center><p></div>
      
      --RMAN CONFIGURATION
      --
      prompt <div id="rman_configuration" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Configuration</b></font><hr align="left" width="460">
      
      prompt <b>All non-default RMAN configuration settings</b>
      
      clear columns breaks computes
      column name     format a130   heading '\''Name'\''   entmap off
      column value                  heading '\''Value'\''  entmap off
      
      select name, value
        from v\$rman_configuration
        order by name;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''rman_configuration'\'');">close</a>]</center><p></div>
      
      
      -- RMAN BACKUP SETS
      --
      prompt <div id="rman_backup_sets" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Sets</b></font><hr align="left" width="460">
      
      prompt <b>Available backup sets contained in the control file including available and expired backup sets</b>
      
      clear columns breaks computes
      
      column bs_key                 format 9999999999             heading '\''BS Key'\''                 entmap off
      column backup_type            format a70                    heading '\''Backup Type'\''            entmap off
      column device_type                                          heading '\''Device Type'\''            entmap off
      column controlfile_included   format a30                    heading '\''Controlfile Included?'\''  entmap off
      column spfile_included        format a30                    heading '\''SPFILE Included?'\''       entmap off
      column incremental_level                                    heading '\''Incremental Level'\''      entmap off
      column pieces                 format 999,999,999,999        heading '\''# of Pieces'\''            entmap off
      column start_time             format a75                    heading '\''Start Time'\''             entmap off
      column completion_time        format a75                    heading '\''End Time'\''               entmap off
      column elapsed_seconds        format 999,999,999,999,999    heading '\''Elapsed Seconds'\''        entmap off
      column tag                                                  heading '\''Tag'\''                    entmap off
      column block_size             format 999,999,999,999,999    heading '\''Block Size'\''             entmap off
      column keep                   format a40                    heading '\''Keep?'\''                  entmap off
      column keep_until             format a75                    heading '\''Keep Until'\''             entmap off
      column keep_options           format a15                    heading '\''Keep Options'\''           entmap off
      
      break on report
      compute sum label '\''Total:'\'' of pieces elapsed_seconds on report
      
      select bs.recid bs_key, backup_type, device_type, controlfile_included, sp.spfile_included, bs.incremental_level, 
             bs.pieces, to_char(bs.start_time, '\''yyyy-mm-dd hh24:mi:ss'\'') start_time,to_char(bs.completion_time, '\''yyyy-mm-dd hh24:mi:ss'\'') completion_time, 
             bs.elapsed_seconds, bp.tag, bs.block_size, bs.keep, TO_CHAR(bs.keep_until, '\''yyyy-mm-dd hh24:mi:ss'\'') keep_until, bs.keep_options keep_options
        from v\$backup_set bs, (select distinct set_stamp, set_count, tag, device_type from v\$backup_piece where status in ('\''A'\'', '\''X'\'')) bp,  
             (select distinct set_stamp, set_count, '\''YES'\'' spfile_included from v\$backup_spfile) sp
       where bs.set_stamp = bp.set_stamp
         and bs.set_count = bp.set_count
         and bs.set_stamp = sp.set_stamp (+)
         and bs.set_count = sp.set_count (+)
       order by bs.recid;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''rman_backup_sets'\'');">close</a>]</center><p></div>
      
      
      -- RMAN BACKUP PIECES
      --
      prompt <div id="rman_backup_pieces" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Pieces</b></font><hr align="left" width="460">
      
      prompt <b>Available backup pieces contained in the control file including available and expired backup sets</b>
      
      clear columns breaks computes
      
      column bs_key              format 9999999999              heading '\''BS Key'\''            entmap off
      column piece#                                             heading '\''Piece #'\''           entmap off
      column copy#                                              heading '\''Copy #'\''            entmap off
      column bp_key                                             heading '\''BP Key'\''            entmap off
      column status                                             heading '\''Status'\''            entmap off
      column handle                                             heading '\''Handle'\''            entmap off
      column start_time          format a75                     heading '\''Start Time'\''        entmap off
      column completion_time     format a75                     heading '\''End Time'\''          entmap off
      column elapsed_seconds     format 999,999,999,999,999     heading '\''Elapsed Seconds'\''   entmap off
      column deleted             format a10                     heading '\''Deleted?'\''          entmap off
      
      break on bs_key
      
      select bs.recid bs_key, bp.piece#, bp.copy#, bp.recid bp_key, status, handle, to_char(bp.start_time, '\''yyyy-mm-dd hh24:mi:ss'\'') start_time,
             to_char(bp.completion_time, '\''yyyy-mm-dd hh24:mi:ss'\'') completion_time, bp.elapsed_seconds
      from v\$backup_set bs, v\$backup_piece bp
      where bs.set_stamp = bp.set_stamp
        and bs.set_count = bp.set_count
        and bp.status in ('\''A'\'', '\''X'\'')
      order by bs.recid, piece#;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''rman_backup_pieces'\'');">close</a>]</center><p></div>
      
      -- RMAN BACKUP CONTROL FILES
      --
      prompt <div id="rman_backup_control_files" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Control Files</b></font><hr align="left" width="460">
      
      prompt <b>Available automatic control files within all available (and expired) backup sets</b>
      
      clear columns breaks computes
      
      column bs_key                 format 9999999999              heading '\''BS Key'\''                 entmap off
      column piece#                                                heading '\''Piece #'\''                entmap off
      column copy#                                                 heading '\''Copy #'\''                 entmap off
      column bp_key                                                heading '\''BP Key'\''                 entmap off
      column controlfile_included   format a75                     heading '\''Controlfile Included?'\''  entmap off
      column status                                                heading '\''Status'\''                 entmap off
      column handle                                                heading '\''Handle'\''                 entmap off
      column start_time             format a40                     heading '\''Start Time'\''             entmap off
      column completion_time        format a40                     heading '\''End Time'\''               entmap off
      column elapsed_seconds        format 999,999,999,999,999     heading '\''Elapsed Seconds'\''        entmap off
      column deleted                format a10                     heading '\''Deleted?'\''               entmap off
      
      break on bs_key
      
      select bs.recid bs_key, bp.piece#, bp.copy#, bp.recid bp_key, decode(bs.controlfile_included, '\''NO'\'', '\''-'\'', 
             bs.controlfile_included) controlfile_included, status, handle
        from v\$backup_set bs, v\$backup_piece bp
       where bs.set_stamp = bp.set_stamp
         and bs.set_count = bp.set_count
         and bp.status in ('\''A'\'', '\''X'\'')
         and bs.controlfile_included != '\''NO'\''
       order by bs.recid,piece#;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''rman_backup_control_files'\'');">close</a>]</center><p></div>
      
      
      -- RMAN BACKUP SPFILE
      --
      prompt <div id="rman_backup_spfile" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup SPFILE</b></font><hr align="left" width="460">
      prompt <b>Available automatic SPFILE backups within all available (and expired) backup sets</b>
      
      clear columns breaks computes
      
      column bs_key                 format 9999999999              heading '\''BS Key'\''           entmap off
      column piece#                                                heading '\''Piece #'\''          entmap off
      column copy#                                                 heading '\''Copy #'\''           entmap off
      column bp_key                                                heading '\''BP Key'\''           entmap off
      column spfile_included        format a75                     heading '\''SPFILE Included?'\'' entmap off
      column status                                                heading '\''Status'\''           entmap off
      column handle                                                heading '\''Handle'\''           entmap off
      column start_time             format a40                     heading '\''Start Time'\''       entmap off
      column completion_time        format a40                     heading '\''End Time'\''         entmap off
      column elapsed_seconds        format 999,999,999,999,999     heading '\''Elapsed Seconds'\''  entmap off
      column deleted                format a10                     heading '\''Deleted?'\''         entmap off
      
      break on bs_key
      
      select bs.recid bs_key, bp.piece#, bp.copy# copy#, bp.recid bp_key, 
             spfile_included, status, handle
        from v\$backup_set bs, v\$backup_piece bp, (select distinct set_stamp, set_count, '\''YES'\'' spfile_included from v\$backup_spfile) sp
       where bs.set_stamp = bp.set_stamp
         and bs.set_count = bp.set_count
         and bp.status in ('\''A'\'', '\''X'\'')
         and bs.set_stamp = sp.set_stamp
         and bs.set_count = sp.set_count
       order by bs.recid, piece#;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''rman_backup_spfile'\'');">close</a>]</center><p></div>

      --awr settings
      --
      prompt <div id="awr_settings" style="DISPLAY: none">      
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>AWR Settings</b></font><hr align="left" width="460">
      
      select * from dba_hist_wr_control;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''awr_settings'\'');">close</a>]</center><p></div>
      
      --autotask
      --
      prompt <div id="autotask" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Auto Task running History</b></font><hr align="left" width="460">
      
      select * from dba_autotask_job_history;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''autotask'\'');">close</a>]</center><p></div>
      
      --sheduler_window
      --
      prompt <div id="sheduler_window" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Sheduler Window</b></font><hr align="left" width="460">
      
      select * from dba_scheduler_windows;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sheduler_window'\'');">close</a>]</center><p></div>
      
      --jobs
      --
      prompt <div id="jobs" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Jobs</b></font><hr align="left" width="460">
      
      select * from dba_jobs; 
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''jobs'\'');">close</a>]</center><p></div>
     
      --invalid_objects
      --
      prompt <div id="invalid_objects" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Invaild Objects</b></font><hr align="left" width="460">
      
      select owner, object_name, object_id last_ddl_time, status from dba_objects d where d.status != '\''VALID'\''
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''invalid_objects'\'');">close</a>]</center><p></div>
      
            
      --dependency
      --
      prompt <div id="dependency" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Object dependency</b></font><hr align="left" width="460">
      prompt <b>If no row selected. the dependency of objects is good, or you need to fixed by running the following script.</b>
      
      select do.obj# d_obj,
             do.name d_name,
             do.type# d_type,
             po.obj# p_obj,
             po.name p_name,
             to_char(p_timestamp, '\''yyyy-mon-dd hh24:mi:ss'\'') "P_Timestamp",
             to_char(po.stime, '\''yyyy-mon-dd hh24:mi:ss'\'') "STIME",
             decode(sign(po.stime - p_timestamp), 0, '\''SAME'\'', '\''*DIFFER*'\'') X
       from sys.obj\$ do, sys.dependency\$ d, sys.obj\$ po
      where P_OBJ# = po.obj#(+)
        and D_OBJ# = do.obj#
        and do.status = 1 /*dependent is valid*/
        and po.status = 1 /*parent is valid*/
        and po.stime != p_timestamp /*parent timestamp not match*/
      order by 2, 1;
      
      prompt <hr align="left" width="200"><b>Fix Method:</b>
      prompt SQL>Shutdown immediate; -
              SQL>Startup upgrade; -
              SQL>@?/rdbms/admin/utlirp.sql; -
              SQL>shutdown immediate; -
              SQL>startup restrict; - 
              SQL>@?/rdbms/admin/utlrp; -
              SQL>Shutdown immediate; -
              SQL>Startup -
             </tr>
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''dependency'\'');">close</a>]</center><p></div>
           
      spool off
      set mark html off
      set feedback on
      exit;
      
      EOF' > /dev/null 2>&1
      ;;
perf)
      echo "  |___ v\$sga_dynamic_components"
      echo "  |___ v\$sgastat"
      echo "  |___ v\$sga_resize_ops"
      echo "  |___ dba_undo_extents"
      echo "  |___ v\$session"
      echo "  |___ dba_hist_active_sess_history"
      echo "  |___ v\$session_longops"
      echo "  |___ v\$lock"
      echo "  |___ dba_kgllock"
      echo "  |___ v\$sort_usage"
      echo "  |___ from dba_temp_free_space"
      echo "  |___ v\$transaction"
      echo "  |___ v\$filestat"
      echo "  |___ v\$tempstat"
      echo "  |___ dba_temp_files"
      echo "  |___ v\$filestat "
      echo "  |___ v\$datafile"
      echo "  |___ v_\$latch"
      echo "  |___ v\$sysstat"
      echo "  |___ v\$sql_plan"
      echo "  |___ full scan tables"
      echo "  |___ invalid indexes"
      echo "  |___ dba_histograms"
      echo "  |___ dba_hist_active_sess_history"
      
      $SU - $ACCOUNT -c 'sqlplus -s /nolog <<EOF
      conn / as sysdba
      alter session set nls_date_format='\''yyyy-mm-dd hh24:mi:ss'\'';
      
      set termout       off
      set echo          off
      set feedback      off
      set verify        off
      set wrap          on
      set trimspool     on
      set serveroutput  on
      set escape        on
      
      set pagesize 50000
      set linesize 175
      set long     2000000000
      
      
      set heading on

      set markup html on spool on preformat off entmap on -
      head '\'' -
        <style type="text/css"> -
          body              {font-family: Lucida Grande,Lucida Sans,Arial,sans-serif; font-size: 13px; background:white;} -
          p                 {font-family: Lucida Grande,Lucida Sans,Arial,sans-serif; font-size: 13px;} -
          table,tr          {color: #000000;font-weight: bold;border-spacing: 0;outline: medium none;font-family: Lucida Grande,Lucida Sans,Arial,sans-serif;font-size: 12px;} -
          td                {background: #F2F5F7; border: 1px solid #AED0EA; font-weight: normal; padding: 5;} -
          th                {background: #D7EBF9;  border: 1px solid #AED0EA; font-size: 13px; font-weight: bold;} -
          h1                {color:blue;} -
          h2                {color:blue; background:white;} -
          a                 {color: #000000;} -
        </style>'\'' -
      body   '\''BGCOLOR="#C0C0C0"'\'' -
      table  '\''WIDTH="90%" BORDER="1"'\''
      
      set markup html on entmap off
      
      spool /tmp/collect.02_performance.html
      
      prompt <script language="JavaScript">  -
                 function ShowHideRegion(divId) -
                 {  if(document.getElementById(divId).style.display == '\''none'\'') -
                    {  -
                       var divlist; -
                       if (document.all || document.getElementById) { divlist = document.getElementsByTagName("div"); } -
                       for(var i = 0; i< divlist.length; i++){ if(divlist[i].id != ""){  -
                          document.getElementById(divlist[i].id).style.display='\''none'\'';}} -
                       document.getElementById(divId).style.display='\''block'\''; -
                    } -
                    else -
                    {  -
                       document.getElementById(divId).style.display = '\''none'\''; } -
                    }  - 
             </script>
      
      --Index
      --
      prompt <a name="index"></a>
      prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Performance Views</b></font><hr align="center" width="250"></center> -
             <table width="90%" border="1"> -
                 <tr><th colspan="8">Database and Instance Information</th></tr> -
                 <tr> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sga_dynamic_components'\'');">SGA Dynamic Components</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sgastat'\'');">SGA Statistics</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sga_resize_ops'\'');">SGA Resize</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''undo_extents'\'');">Undo Extents</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sessions'\'');">Sessions</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sessions_history'\'');">Sessions History</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''session_longops'\'');">Session Long Running</a></td> -  
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''locks'\'');">Locks</a></td> -
                 </tr>
      prompt     <tr> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''temp_usage'\'');">Temp Usage</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''temp_free'\'');">Temp Free</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''undo_usage'\'');">Undo Usage</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''file_io_statistics'\'');">File I/O Statistics</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''file_io_timings'\'');">File I/O Timings</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''average_overall_io_per_sec'\'');">Average Overall I/O per Second</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''redo_log_contention'\'');">Redo Log Contention</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sorts'\'');">Sorts</a></td> -
                 </tr>
     prompt     <tr> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sql_statements_with_most_buffer_gets'\'');">SQL Statements With Most Buffer Gets</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sql_statements_with_most_disk_reads'\'');">SQL Statements With Most Disk Reads</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''sql_plan'\'');">SQL Plans</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''analyze'\'');">Tables/Indexes Analyzation</a></td> - 
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''histograms'\'');">Tables Histograms</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''full_scan_table'\'');">Full Scan Tables</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''invalid_indexes'\'');">Invalid Indexes</a></td> - 
            </table>
      
      --sga_dynamic_components
      --
      prompt <div id="sga_dynamic_components" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SGA Dynamic Components</b></font><hr align="left" width="460">
      
      select * from v\$sga_dynamic_components;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sga_dynamic_components'\'');">close</a>]</center><p></div>
      
      --sgastat
      --
      prompt <div id="sgastat" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SGA Statistics</b></font><hr align="left" width="460">
      
      select * from v\$sgastat order by bytes desc;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sgastat'\'');">close</a>]</center><p></div>
      
      
      --sga_resize_ops
      --
      prompt <div id="sga_resize_ops" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SGA Resize</b></font><hr align="left" width="460">
      
      select * from v\$sga_resize_ops;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sga_resize_ops'\'');">close</a>]</center><p></div>
      
      
      --undo_extents
      --
      prompt <div id="undo_extents" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Undo Extents</b></font><hr align="left" width="460">
      
      select tablespace_name, status, sum(bytes)/1024/1024 mb from dba_undo_extents group by tablespace_name, status;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''undo_extents'\'');">close</a>]</center><p></div>
      
      --sessions
      --
      prompt <div id="sessions" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Sessions</b></font><hr align="left" width="460">
      
      select s.saddr, s.sid, p.pid, p.spid, s.serial#, s.username, s.status, s.status, 
             s.server, s.osuser, s.machine, s.terminal, s.program, s.type, s.sql_hash_value, 
             s.sql_id, s.prev_hash_value, s.prev_sql_id, s.module, s.logon_time, s.state, s.event, 
             s.p1text, s.p1, s.p1raw, s.p2text, s.p2, s.p2raw, s.p3text, s.p3, s.p3raw
        from v\$session s, v\$process p
       where s.paddr = p.addr(+);
        
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sessions'\'');">close</a>]</center><p></div>
    
            
      --sessions_history
      --
      prompt <div id="sessions_history" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Sessions History</b></font><hr align="left" width="460">
      
      set heading off
      
      select decode(count(*), 0, '\''<b>No data collected!</b>'\'', '\''<b>Session history might be very big, so please click <a class="noLink" href="./collect.03_session_history.html" target="mFrame"">03_session_history</a> on left tree to open it.</b>'\'') 
        from dba_hist_active_sess_history d'" 
       where d.sample_time  between to_date('$BEGIN_DATE', 'yyyymmddhh24miss') 
         and to_date('$END_DATE', 'yyyymmddhh24miss')
         and rownum <= 1;"' 
      
      set heading on
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sessions_history'\'');">close</a>]</center><p></div>
      
      --session_longops
      --
      prompt <div id="session_longops" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Sessions Long Running</b></font><hr align="left" width="460">
      
      column serial#         format 999999 heading '\''serial#'\''          entmap off
      column elapsed_seconds format 999999 heading '\''elapsed_seconds'\''  entmap off
      
      
      select s.sid, s.serial#, s.opname, s.target_desc, s.sofar, s.units, s.start_time, s.elapsed_seconds, s.message, 
             s.username, s.sql_id, a.sql_fulltext
        from v\$session_longops s, v\$sqlarea a
       where s.sql_id = a.sql_id(+);
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''session_longops'\'');">close</a>]</center><p></div>
      
      --locks
      --
      prompt <div id="locks" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Lock</b></font><hr align="left" width="460">
          
      prompt <b>Blocking/Blocked Sessions:</b><hr align="left" width="200">
      break on report on id1 on id2
      
       select sid, type, id1, id2, lmode, request, ctime, decode(block, 1, '\''blocking'\'', '\''blocked'\'') block
         from v\$lock a where exists (select 1 from v\$lock b where b.block = 1 and a.id1 = b.id1 and a.id2 = b.id2)
        order by id1, id2, 8 desc;
      
      prompt <b>Library Lock:</b><hr align="left" width="200">
      select '\''session '\'' || d.locker || '\'' lock session '\'' || d.locked ||
             '\'', alter system kill session '\'' || '\'''\'''\'''\'' || d.locker || '\'','\'' ||
             d.serial# || '\'''\'''\'''\'' as "result"
        from (select distinct s.sid locker, s.serial#, w.sid locked
                        from dba_kgllock k, v\$session s, v\$session_wait w
                       where w.event like '\''library cache%'\''
                         and k.kgllkhdl = w.p1raw
                         and k.kgllkuse = s.saddr
                         and s.sid <> w.sid
            ) d
        order by d.locker;
      
      prompt <b>Lock held by Sessions:</b><hr align="left" width="200">
      select s.sid session_id, 
             s.username, 
             decode(lmode, 0, '\''none'\'', 1, '\''null'\'',2, '\''row-s (ss)'\'', 3, '\''row-x (sx)'\'', 4, '\''share'\'', 5, '\''s/row-x (ssx)'\'', 6,'\''exclusive'\'', to_char(lmode)) mode_held, 
             decode(request, 0, '\''none'\'', 1,'\''null'\'', 2, '\''row-s (ss)'\'', 3, '\''row-x (sx)'\'', 4, '\''share'\'', 5, '\''s/row-x(ssx)'\'', 6, '\''exclusive'\'', to_char(request)) mode_requested,
             o.owner||'\''.'\''||o.object_name||'\'' ('\''||o.object_type||'\'')'\'' object, s.type lock_type,
             l.id1 lock_id1, 
             l.id2 lock_id2 
        from v\$lock l, sys.dba_objects o, v\$session s 
       where l.sid = s.sid 
         and l.id1 = o.object_id
       order by s.sid;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''locks'\'');">close</a>]</center><p></div>
      
      
      --temp usage
      --
      prompt <div id="temp_usage" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Temp Usage</b></font><hr align="left" width="460">
      prompt <b>Tempory space used</b>
      
      select distinct a.username,c.sid,c.serial#,d.spid,b.sql_text,a.blocks,a.extents
        from v\$sort_usage a, v\$sql b, v\$session c, v\$process d
       where a.sqladdr = b.address 
         and a.session_addr = c.saddr 
         and c.paddr = d.addr 
       order by a.blocks desc;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''temp_usage'\'');">close</a>]</center><p></div>
      
      --temp_free
      --
      prompt <div id="temp_free" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Temp Free</b></font><hr align="left" width="460">
      
      select * from dba_temp_free_space;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''temp_free'\'');">close</a>]</center><p></div>
      
      --undo_usage
      prompt <div id="undo_usage" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Undo Usage</b></font><hr align="left" width="460">
      prompt <b>Undo space used by current sessions.</b>
      
      select b.sid,a.xidusn,a.used_ublk,c.sql_text
        from v\$transaction a, v\$session b, v\$sqlarea c
       where a.addr=b.taddr
         and b.sql_hash_value=c.hash_value
       order by a.used_ublk desc;
       
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''undo_usage'\'');">close</a>]</center><p></div>
      
      --file io stats
      --
      prompt <div id="file_io_statistics" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>File I/O Statistics</b></font><hr align="left" width="460">
      prompt <b>Ordered by "Physical Reads" since last startup of the Oracle instance</b>
      clear columns breaks computes
      
      column tablespace_name   format a50                   head '\''Tablespace'\''       entmap off
      column file_name                                      head '\''File Name'\''        entmap off
      column phyrds            format 999,999,999,999,999   head '\''Physical Reads'\''   entmap off
      column phywrts           format 999,999,999,999,999   head '\''Physical Writes'\''  entmap off
      column read_pct                                       head '\''Read Pct.'\''        entmap off
      column write_pct                                      head '\''Write Pct.'\''       entmap off
      column total_io          format 999,999,999,999,999   head '\''Total I/O'\''        entmap off
      
      break on report
      compute sum label '\''Total: '\'' of phyrds phywrts total_io on report
      
      select df.tablespace_name, df.file_name fname, fs.phyrds, round((fs.phyrds * 100) / (fst.pr + tst.pr), 2) read_pct, 
             fs.phywrts, round((fs.phywrts * 100) / (fst.pw + tst.pw), 2) write_pct, (fs.phyrds + fs.phywrts) total_io
        from sys.dba_data_files df, v\$filestat fs, (select sum(f.phyrds) pr, sum(f.phywrts) pw from v\$filestat f) fst, 
             (select sum(t.phyrds) pr, sum(t.phywrts) pw from v\$tempstat t) tst
       where df.file_id = fs.file#
       union
      select tf.tablespace_name, tf.file_name, ts.phyrds, round((ts.phyrds * 100) / (fst.pr + tst.pr), 2) read_pct, 
             ts.phywrts, round((ts.phywrts * 100) / (fst.pw + tst.pw), 2) write_pct, (ts.phyrds + ts.phywrts) total_io
        from sys.dba_temp_files  tf, v\$tempstat          ts, (select sum(f.phyrds) pr, sum(f.phywrts) pw from v\$filestat f) fst, 
             (select sum(t.phyrds) pr, sum(t.phywrts) pw from v\$tempstat t) tst
       where tf.file_id = ts.file#
       order by phyrds desc;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''file_io_statistics'\'');">close</a>]</center><p></div>
      
      prompt <div id="file_io_timings" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>File I/O Timings</b></font><hr align="left" width="460">
      prompt <b>Average time (in milliseconds) for an I/O call per datafile since last startup of the Oracle instance - (ordered by Physical Reads)</b>
      
      clear columns breaks computes
      column fname                                           head '\''File Name'\''                                      entmap off
      column phyrds            format 999,999,999,999,999    head '\''Physical Reads'\''                                 entmap off
      column read_rate         format 999,999,999,999,999.99 head '\''Average Read Time<br>(milliseconds per read)'\''   entmap off
      column phywrts           format 999,999,999,999,999    head '\''Physical Writes'\''                                entmap off
      column write_rate        format 999,999,999,999,999.99 head '\''Average Write Time<br>(milliseconds per write)'\'' entmap off
      
      break on report
      compute sum label '\''Total: '\'' of phyrds phywrts on report
      compute avg label '\''Average: '\'' of read_rate write_rate on report
      
      select d.name  fname, s.phyrds, round((s.readtim/greatest(s.phyrds,1)), 2) read_rate, 
             s.phywrts, round((s.writetim/greatest(s.phywrts,1)),2)  write_rate
        from v\$filestat s, v\$datafile d
      where s.file# = d.file#
      union
      select t.name fname, s.phyrds, round((s.readtim/greatest(s.phyrds,1)), 2) read_rate, 
             s.phywrts, round((s.writetim/greatest(s.phywrts,1)),2)  write_rate
        from v\$tempstat  s, v\$tempfile  t
       where s.file# = t.file#
       order by 2 desc;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''file_io_timings'\'');">close</a>]</center><p></div>
      
      --average_overall_io_per_sec
      --
      prompt <div id="average_overall_io_per_sec" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Average Overall I/O per Second</b></font><hr align="left" width="460">
      prompt <b>Average overall I/O calls (physical read/write calls) since last startup of the Oracle instance</b>
      
      clear columns breaks computes
      
      declare
      
          cursor get_file_io is 
           select nvl(sum(a.phyrds + a.phywrts), 0)  sum_datafile_io, to_number(null) sum_tempfile_io
             from v\$filestat a
            union
           select to_number(null) sum_datafile_io, nvl(sum(b.phyrds + b.phywrts), 0)  sum_tempfile_io
             from v\$tempstat b;
      
          current_time           date;
          elapsed_time_seconds   number;
          sum_datafile_io        number;
          sum_datafile_io2       number;
          sum_tempfile_io        number;
          sum_tempfile_io2       number;
          total_io               number;
          datafile_io_per_sec    number;
          tempfile_io_per_sec    number;
          total_io_per_sec       number;
      
      begin
          open get_file_io;
          
          for i in 1..2 loop
            fetch get_file_io into sum_datafile_io, sum_tempfile_io;
            if i = 1 then
              sum_datafile_io2 := sum_datafile_io;
            else
              sum_tempfile_io2 := sum_tempfile_io;
            end if;
          end loop;
      
          total_io := sum_datafile_io2 + sum_tempfile_io2;
          select sysdate into current_time from dual;
          select ceil ((current_time - startup_time)*(60*60*24)) into elapsed_time_seconds from v\$instance;
      
          datafile_io_per_sec := sum_datafile_io2/elapsed_time_seconds;
          tempfile_io_per_sec := sum_tempfile_io2/elapsed_time_seconds;
          total_io_per_sec    := total_io/elapsed_time_seconds;
      
          dbms_output.put_line('\''<table width="90%" border="1">'\'');
      
          dbms_output.put_line('\''<tr><th align="left" width="20%">elapsed time (in seconds)</th><td width="80%">'\'' || to_char(elapsed_time_seconds, '\''9,999,999,999,999'\'') || '\''</td></tr>'\'');
          dbms_output.put_line('\''<tr><th align="left" width="20%">datafile i/o calls per second</th><td width="80%">'\'' || to_char(datafile_io_per_sec, '\''9,999,999,999,999'\'') || '\''</td></tr>'\'');
          dbms_output.put_line('\''<tr><th align="left" width="20%">tempfile i/o calls per second</th><td width="80%">'\'' || to_char(tempfile_io_per_sec, '\''9,999,999,999,999'\'') || '\''</td></tr>'\'');
          dbms_output.put_line('\''<tr><th align="left" width="20%">total i/o calls per second</th><td width="80%">'\'' || to_char(total_io_per_sec, '\''9,999,999,999,999'\'') || '\''</td></tr>'\'');
      
          dbms_output.put_line('\''</table>'\'');
      end;
      /
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''average_overall_io_per_sec'\'');">close</a>]</center><p></div>
      
      --redo_log_contention
      --
      prompt <div id="redo_log_contention" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Redo Log Contention</b></font><hr align="left" width="460">
      prompt <b>All latches like redo% - (ordered by misses)</b>
      clear columns breaks computes
      column name             format a95                        heading '\''Latch Name'\''
      column gets             format 999,999,999,999,999,999    heading '\''Gets'\''
      column misses           format 999,999,999,999            heading '\''Misses'\''
      column sleeps           format 999,999,999,999            heading '\''Sleeps'\''
      column immediate_gets   format 999,999,999,999,999,999    heading '\''Immediate Gets'\''
      column immediate_misses format 999,999,999,999            heading '\''Immediate Misses'\''
      break on report
            
      compute SUM label '\''Total: '\'' of gets misses sleeps immediate_gets immediate_misses on report
            
      select initcap(name) name, gets, misses, sleeps, immediate_gets, immediate_misses
        from sys.v_\$latch
       where name like '\''redo%'\''
       order by 1;
            
      prompt <b>System statistics like redo%</b>
      clear columns breaks computes
      column name    format a95                   heading '\''Statistics Name'\''
      column value   format 999,999,999,999,999   heading '\''Value'\''
            
      select initcap(name) name, value
        from v\$sysstat
       where name like '\''redo%'\''
       order by 1;
            
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''redo_log_contention'\'');">close</a>]</center><p></div>
      
      --sorts
      --
      prompt <div id="sorts" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Sorts</b></font><hr align="left" width="460">
      clear columns breaks computes
      column disk_sorts     format 999,999,999,999,999    heading '\''Disk Sorts'\''       entmap off
      column memory_sorts   format 999,999,999,999,999    heading '\''Memory Sorts'\''     entmap off
      column pct_disk_sorts                               heading '\''Pct. Disk Sorts'\''  entmap off
      
      select a.value   disk_sorts, 
             b.value   memory_sorts, 
             round(100 * a.value/decode((a.value+b.value), 0, 1, (a.value+b.value)), 2) pct_disk_sorts
        from v\$sysstat a, v\$sysstat  b
       where a.name = '\''sorts (disk)'\''
         and b.name = '\''sorts (memory)'\'';
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sorts'\'');">close</a>]</center><p></div>
      
      
      --sql_statements_with_most_buffer_gets
      --
      prompt <div id="sql_statements_with_most_buffer_gets" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SQL Statements With Most Buffer Gets</b></font><hr align="left" width="460">
      prompt <b>Top 100 SQL statements with buffer gets greater than 100</b>
      
      clear columns breaks computes
      column username        format a75                   heading '\''Username'\''                 entmap off
      column buffer_gets     format 999,999,999,999,999   heading '\''Buffer Gets'\''              entmap off
      column executions      format 999,999,999,999,999   heading '\''Executions'\''               entmap off
      column gets_per_exec   format 999,999,999,999,999   heading '\''Buffer Gets / Execution'\''  entmap off
      column sql_text                                     heading '\''SQL Text'\''                 entmap off
      
      select username, a.buffer_gets, a.executions, (a.buffer_gets / decode(a.executions, 0, 1, a.executions)) gets_per_exec, 
             a.sql_text
        from (select ai.buffer_gets, ai.executions, ai.sql_text, ai.parsing_user_id
                from sys.v_\$sqlarea ai
                order by ai.buffer_gets ) a, dba_users b
      where a.parsing_user_id = b.user_id 
        and a.buffer_gets > 100
        and b.username not in ('\''SYS'\'','\''SYSTEM'\'', '\''DBSNMP'\'', '\''ORACLE_OCM'\'')
        and rownum < 101
      order by a.buffer_gets desc;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sql_statements_with_most_buffer_gets'\'');">close</a>]</center><p></div>
      
      --sql_statements_with_most_disk_reads
      --
      prompt <div id="sql_statements_with_most_disk_reads" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SQL Statements With Most Disk Reads</b></font><hr align="left" width="460">
      prompt <b>Top 100 SQL statements with disk reads greater than 100</b>
      clear columns breaks computes
      
      column username        format a75                   heading '\''Username'\''           entmap off
      column disk_reads      format 999,999,999,999,999   heading '\''Disk Reads'\''         entmap off
      column executions      format 999,999,999,999,999   heading '\''Executions'\''         entmap off
      column reads_per_exec  format 999,999,999,999,999   heading '\''Reads / Execution'\''  entmap off
      column sql_text                                     heading '\''SQL Text'\''           entmap off
      
      select  username, a.disk_reads, a.executions, (a.disk_reads / decode(a.executions, 0, 1, a.executions))  reads_per_exec, 
              a.sql_text         sql_text
        from(select ai.disk_reads, ai.executions, ai.sql_text, ai.parsing_user_id
              from sys.v_\$sqlarea ai
             order by ai.buffer_gets) a, dba_users b
       where a.parsing_user_id = b.user_id 
         and a.disk_reads > 100
         and b.username not in ('\''SYS'\'','\''SYSTEM'\'', '\''DBSNMP'\'', '\''ORACLE_OCM'\'')
         and rownum < 101
       order by a.disk_reads desc;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sql_statements_with_most_disk_reads'\'');">close</a>]</center><p></div>
      
      --sql_plan
      --
      prompt <div id="sql_plan" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>SQL Plan</b></font><hr align="left" width="460">
      prompt <b>Sql plans in memory that disk reads or buffer gets greater than 100 </b><hr align="left" width="200">
      break on report on sql_text on sql_id
             
      select k.sql_id, k.id, k.operation, options, object_node, object#, object_owner, object_name, object_alias, object_type, k.optimizer, 
             cost, cardinality, bytes, cpu_cost, io_cost, filter_predicates, projection, j.sql_text
        from v\$sql_plan k, (select distinct sql_id, s.sql_text from v\$sqlarea s
                             where (s.DISK_READS > 100 or s.BUFFER_GETS > 100)
                               and s.PARSING_USER_ID not in
                                   (select user_id from dba_users where username in ('\''SYS'\'', '\''SYSTEM'\'', '\''DBSNMP'\'', '\''ORACLE_OCM'\''))
                           ) j
       where k.sql_id = j.sql_id
       order by k.sql_id, k.id;
      
      prompt <b>Sql plans history that disk reads or buffer gets greater than 100 </b><hr align="left" width="200">   
      break on report on sql_text on sql_id
      
      select h.sql_id, h.id, h.operation, h.options, h.object_node, h.object#, h.object_owner, h.object_name, h.object_alias, h.object_type, h.optimizer,
             h.cost, h.cardinality, h.bytes, h.cost, h.cpu_cost, h.io_cost, h.timestamp, j.sql_text
        from dba_hist_sql_plan h, (select distinct sql_id, s.sql_text from v\$sqlarea s
                                    where (s.DISK_READS > 100 or s.BUFFER_GETS > 100)
                                      and s.PARSING_USER_ID not in
                                          (select user_id from dba_users where username in ('\''SYS'\'', '\''SYSTEM'\'', '\''DBSNMP'\'', '\''ORACLE_OCM'\''))
                                   ) j
      where h.sql_id = j.sql_id
      order by h.sql_id, h.id; 
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''sql_plan'\'');">close</a>]</center><p></div>
      
      --table/index analyze
      --
      prompt <div id="analyze" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tables/Indexes Analyze</b></font><hr align="left" width="460">
      prompt <b>List tables/indexes that last analyzed time are null or less then '"$BEGIN_DATE"'</b><hr align="left" width="200">
      
      select d.owner, d.table_name, d.tablespace_name,
             d.num_rows, d.blocks, d.sample_size, d.last_analyzed
        from dba_tables d 
       where '"owner not in ('SYS', 'SYSTEM', 'DBSNMP') and tablespace_name not in ('SYSTEM', 'SYSAUX')
         and (d.last_analyzed is null or d.last_analyzed < to_date('$BEGIN_DATE', 'yyyy-mm-dd hh24:mi:ss'))"';
        
      
      prompt <hr align="left" width="200"><b>Indexes:</b>
        
      select i.owner, i.index_name, i.index_type, i.table_name,
             i.num_rows, i.blevel, i.leaf_blocks, i.distinct_keys, i.clustering_factor, i.last_analyzed
        from dba_indexes i 
       where '"owner not in ('SYS', 'SYSTEM', 'DBSNMP') and tablespace_name not in ('SYSTEM', 'SYSAUX')
         and (i.last_analyzed is null or i.last_analyzed < to_date('$BEGIN_DATE',  'yyyy-mm-dd hh24:mi:ss'))"'; 
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''analyze'\'');">close</a>]</center><p></div>
      
      --table histograms
      --
      prompt <div id="histograms" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tables Histograms</b></font><hr align="left" width="460">
      prompt <b>List histograms of indexed columns of tables</b><hr align="left" width="200">
      
      select owner, table_name, column_name, d.endpoint_number, d.endpoint_value, d.endpoint_actual_value
       from dba_histograms d
      where d.owner not in('\''SYS'\'', '\''SYSTEM'\'', '\''DBSNMP'\'', '\''WMSYS'\'', '\''ORACLE_OCM'\'', '\''WMSYS'\'')
        and exists(select 1 from dba_ind_columns c 
                    where d.owner = c.table_owner 
                      and d.table_name = c.table_name 
                      and d.column_name = c.column_name
                      and c.index_owner not in('\''SYS'\'', '\''SYSTEM'\'', '\''DBSNMP'\'', '\''WMSYS'\'', '\''ORACLE_OCM'\'', '\''WMSYS'\'')
                  );

      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''histograms'\'');">close</a>]</center><p></div>
      
      --invalid_indexes
      --
      prompt <div id="invalid_indexes" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Invaild Indexes</b></font><hr align="left" width="460">
      
      select * 
       from(
        select owner, index_name, '\'''\'' partition_name, '\'''\'' subpartition_name, status
          from dba_indexes
         where status = '\''UNUSABLE'\''
        union all
        select index_owner owner, index_name, partition_name, '\'''\'' subpartition_name, status
          from dba_ind_partitions
         where status ='\''UNUSABLE'\''
        union all
        select index_owner owner, index_name, partition_name, subpartition_name, status
         from dba_ind_subpartitions
        where status = '\''UNUSABLE'\''
        ) order by owner, index_name;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''invalid_indexes'\'');">close</a>]</center><p></div>
      
      --full_scan_table
      --
      prompt <div id="full_scan_table" style="DISPLAY: block">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Full Scan Tables</b></font><hr align="left" width="460">
      prompt <b>List tables that have not any index or have one or more UNUSABLE indexes.</b>
      
      break on report on owner on table_name
      
      select d.owner, d.table_name, i.index_name, i.status
        from dba_tables d, dba_indexes i
       where d.owner = i.owner
         and d.owner not in('\''SYS'\'', '\''SYSTEM'\'', '\''ORACLE_OCM'\'', '\''TSMSYS'\'', '\''WMSYS'\'', '\''OUTLN'\'', '\''DBSNMP'\'')
         and d.table_name = i.table_name
         and i.status = '\''UNUSABLE'\''
      union all 
      select d.owner, d.table_name, '\'''\'' index_name, '\'''\'' status
        from dba_tables d
       where not exists (select 1 from dba_indexes i where d.owner = i.owner
         and d.owner not in('\''SYS'\'', '\''SYSTEM'\'', '\''ORACLE_OCM'\'', '\''TSMSYS'\'', '\''WMSYS'\'', '\''OUTLN'\'', '\''DBSNMP'\'')
         and d.table_name = i.table_name)
         and d.owner not in('\''SYS'\'', '\''SYSTEM'\'', '\''ORACLE_OCM'\'', '\''TSMSYS'\'', '\''WMSYS'\'', '\''OUTLN'\'', '\''DBSNMP'\'');
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''full_scan_table'\'');">close</a>]</center><p></div>      
      
      spool off
      
      --session history
      --
      spool /tmp/collect.03_session_history.html
      
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Sessions History</b></font><hr align="left" width="460">
      
      select * from dba_hist_active_sess_history d'" 
       where d.sample_time  between to_date('$BEGIN_DATE', 'yyyymmddhh24miss') 
         and to_date('$END_DATE', 'yyyymmddhh24miss');"'
      
      prompt <center>[<a class="noLink" href="./collect.02_performance.html">Back to performance page</a>]</center><p>
         
      spool off
      
      set markup html off
      
      set termout   on
      set echo      on
      set feedback  on
      set verify    on
      
      exit;
      
      EOF' > /dev/null 2>&1
      ;;
      
asmconf)
      echo "  |___ v\$parameter"
      echo "  |___ v\$asm_client"
      echo "  |___ v\$asm_disk"
      echo "  |___ v\$asm_disk_iostat"
      echo "  |___ v\$asm_disk_stat"
      echo "  |___ v\$asm_diskgroup"
      echo "  |___ v\$asm_diskgroup_stat"
      echo "  |___ ASM File information"
      
      $SU - $ACCOUNT -c "export ORACLE_SID=$ORACLE_SID;"' sqlplus -s /nolog <<EOF
      conn / as sysasm
      
      alter session set nls_date_format='\''yyyy-mm-dd hh24:mi:ss'\'';
      
      set termout       off
      set echo          off
      set feedback      off
      set verify        off
      set wrap          on
      set trimspool     on
      set serveroutput  on
      set escape        on
      
      set pagesize 50000
      set linesize 175
      set long     2000000000
      
      
      set heading on

      set markup html on spool on preformat off entmap on -
      head '\'' -
        <style type="text/css"> -
          body              {font-family: Lucida Grande,Lucida Sans,Arial,sans-serif; font-size: 13px; background:white;} -
          p                 {font-family: Lucida Grande,Lucida Sans,Arial,sans-serif; font-size: 13px;} -
          table,tr          {color: #000000;font-weight: bold;border-spacing: 0;outline: medium none;font-family: Lucida Grande,Lucida Sans,Arial,sans-serif;font-size: 12px;} -
          td                {background: #F2F5F7; border: 1px solid #AED0EA; font-weight: normal; padding: 5;} -
          th                {background: #D7EBF9;  border: 1px solid #AED0EA; font-size: 13px; font-weight: bold;} -
          h1                {color:blue;} -
          h2                {color:blue; background:white;} -
          a                 {color: #000000;} -
        </style>'\'' -
      body   '\''BGCOLOR="#C0C0C0"'\'' -
      table  '\''WIDTH="90%" BORDER="1"'\''
      
      set markup html on entmap off
      
      spool /tmp/collect.01_Overview.html
      
      prompt <script language="JavaScript">  -
                 function ShowHideRegion(divId) -
                 {  if(document.getElementById(divId).style.display == '\''none'\'') -
                    {  -
                       var divlist; -
                       if (document.all || document.getElementById) { divlist = document.getElementsByTagName("div"); } -
                       for(var i = 0; i< divlist.length; i++){ if(divlist[i].id != ""){  -
                          document.getElementById(divlist[i].id).style.display='\''none'\'';}} -
                       document.getElementById(divId).style.display='\''block'\''; -
                    } -
                    else -
                    {  -
                       document.getElementById(divId).style.display = '\''none'\''; } -
                    }  - 
             </script>
      
      --Index
      --
      prompt <a name="index"></a>
      prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASM Views</b></font><hr align="center" width="250"></center> -
             <table width="90%" border="1"> -
                 <tr><th colspan="8"></th></tr> -
                 <tr> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''parameter'\'');">Parameter</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''client_info'\'');">Client Information</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''asm_disk'\'');">ASM Disk</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''asm_disk_iostat'\'');">ASM Disk Iostat</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''asm_disk_stat'\'');">ASM Disk Stat</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''asm_diskgroup'\'');">ASM DiskGroup</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''asm_diskgroup_stat'\'');">ASM DiskGroup Stat</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''asm_file_info'\'');">ASM File Info</a></td> -
                 </tr> -     
            </table>
      
      --parameter
      --
      prompt <div id="parameter" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Parameter</b></font><hr align="left" width="460">
     
      select * from v\$parameter;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''parameter'\'');">close</a>]</center><p></div>
      
      --asm_client
      --
      prompt <div id="client_info" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Client Information</b></font><hr align="left" width="460">
     
      select * from v\$asm_client;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''client_info'\'');">close</a>]</center><p></div>
      
      --asm_disk
      --
      prompt <div id="asm_disk" style="DISPLAY: block">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASM Disk</b></font><hr align="left" width="460">
     
      select * from v\$asm_disk;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''asm_disk'\'');">close</a>]</center><p></div>
      
      --asm_disk_iostat
      --
      prompt <div id="asm_disk_iostat" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASM Disk Iostat</b></font><hr align="left" width="460">
      
      select * from v\$asm_disk_iostat;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''asm_disk_iostat'\'');">close</a>]</center><p></div>
      
      --asm_disk_stat
      --
      prompt <div id="asm_disk_stat" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASM Disk Stat</b></font><hr align="left" width="460">
      
      select * from v\$asm_disk_stat;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''asm_disk_stat'\'');">close</a>]</center><p></div>
      
      --asm_diskgroup
      --
      prompt <div id="asm_diskgroup" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASM DiskGroup</b></font><hr align="left" width="460">
      
      select * from v\$asm_diskgroup;
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''asm_diskgroup'\'');">close</a>]</center><p></div>
      
      --asm_diskgroup_stat
      --
      prompt <div id="asm_diskgroup_stat" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASM DiskGroup Stat</b></font><hr align="left" width="460">
      
      select * from v\$asm_diskgroup_stat;
      
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''asm_diskgroup_stat'\'');">close</a>]</center><p></div>
      
      --asm_file_info
      --
      prompt <div id="asm_file_info" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>ASM file information</b></font><hr align="left" width="460">
      
      select g.name,
             g.group_number,
             a.name,
             f.file_number,
             f.block_size,
             f.bytes,
             f.space,
             f.type,
             f.redundancy,
             f.striped,
             f.redundancy_lowered
        from v\$asm_alias a, v\$asm_file f, v\$asm_diskgroup g
       where a.group_number = f.group_number
         and a.file_number = f.file_number
         and a.alias_directory = '\''N'\''
         and system_created = '\''N'\''
         and f.group_number = g.group_number;
      
       prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''asm_file_info'\'');">close</a>]</center><p></div>
      
      spool off
      
      set mark html off
      
      exit;
      EOF' > /dev/null 2>&1
      ;;
      
dg)
      echo "  |___ archive log list"
      echo "  |___ v\$dataguard_status"
      echo "  |___ v\$standby_log"
      echo "  |___ v\$archived_log"
      echo "  |___ v\$archive_gap"
      echo "  |___ v\$managed_standby"
      echo "  |___ v\$archive_dest_status"
      echo "  |___ v\$archive_dest"
      
     $SU - $ACCOUNT -c 'sqlplus -s /nolog <<EOF
     conn / as sysdba
     
     alter session set nls_date_format='\''yyyy-mm-dd hh24:mi:ss'\'';
      
      set termout       off
      set echo          off
      set feedback      off
      set verify        off
      set wrap          on
      set trimspool     on
      set serveroutput  on
      set escape        on
      
      set pagesize 50000
      set linesize 175
      set long     2000000000
      
      
      set heading on

      set markup html on spool on preformat off entmap on -
      head '\'' -
        <style type="text/css"> -
          body              {font-family: Lucida Grande,Lucida Sans,Arial,sans-serif; font-size: 13px; background:white;} -
          p                 {font-family: Lucida Grande,Lucida Sans,Arial,sans-serif; font-size: 13px;} -
          table,tr          {color: #000000;font-weight: bold;border-spacing: 0;outline: medium none;font-family: Lucida Grande,Lucida Sans,Arial,sans-serif;font-size: 12px;} -
          td                {background: #F2F5F7; border: 1px solid #AED0EA; font-weight: normal; padding: 5;} -
          th                {background: #D7EBF9;  border: 1px solid #AED0EA; font-size: 13px; font-weight: bold;} -
          h1                {color:blue;} -
          h2                {color:blue; background:white;} -
          a                 {color: #000000;} -
        </style>'\'' -
      body   '\''BGCOLOR="#C0C0C0"'\'' -
      table  '\''WIDTH="90%" BORDER="1"'\''
      
      set markup html on entmap off
      
      spool /tmp/collect.04_dataguard.html
      
      prompt <script language="JavaScript">  -
                 function ShowHideRegion(divId) -
                 {  if(document.getElementById(divId).style.display == '\''none'\'') -
                    {  -
                       var divlist; -
                       if (document.all || document.getElementById) { divlist = document.getElementsByTagName("div"); } -
                       for(var i = 0; i< divlist.length; i++){ if(divlist[i].id != ""){  -
                          document.getElementById(divlist[i].id).style.display='\''none'\'';}} -
                       document.getElementById(divId).style.display='\''block'\''; -
                    } -
                    else -
                    {  -
                       document.getElementById(divId).style.display = '\''none'\''; } -
                    }  - 
             </script>
      
      --Index
      --
      prompt <a name="index"></a>
      prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Dataguard Views</b></font><hr align="center" width="250"></center> -
             <table width="90%" border="1"> -
                 <tr><th colspan="8"></th></tr> -
                 <tr> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''overview'\'');">Archive Log Overview</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''dataguard_status'\'');">Dataguard Status</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''standby_log'\'');">Standby Logs</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''archived_log'\'');">Archived Log</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''archive_gap'\'');">Archive Gap</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''managed_standby'\'');">Dataguard Process</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''archive_dest_status'\'');">Archive Dest Status</a></td> -
                 <td nowrap align="center" width="25%"><a class="link" href="javascript:ShowHideRegion('\''archive_dest'\'');">Archive Dest</a></td> -
                 </tr> -     
            </table>
      
      --overview
      --
      prompt <div id="overview" style="DISPLAY: block">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archive Log Overview</b></font><hr align="left" width="460">
     
      archive log list;
     
      prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''overview'\'');">close</a>]</center><p></div>
     
      --dataguard_status
      --
      prompt <div id="dataguard_status" style="DISPLAY: none">
      prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Dataguard Status</b></font><hr align="left" width="460">
     
      select message, timestamp 
        from v\$dataguard_status 
       where severity in ('\''Error'\'','\''Fatal'\'') 
       order by timestamp;
     
     prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''dataguard_status'\'');">close</a>]</center><p></div>
     
     --standby_log
     --
     prompt <div id="standby_log" style="DISPLAY: none">
     prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Standby Logs</b></font><hr align="left" width="460">
     
     select group#,sequence#,bytes,used,archived,status from v\$standby_log;
     
     prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''standby_log'\'');">close</a>]</center><p></div>

     --archived_log
     --
     prompt <div id="archived_log" style="DISPLAY: none">
     prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archived Log</b></font><hr align="left" width="460">
     
     select al.thrd "Thread", almax "Last Seq Received", lhmax "Last Seq Applied"
       from (select thread# thrd, max(sequence#) almax
               from v\$archived_log
              where resetlogs_change#=(select resetlogs_change# from v\$database)
              group by thread#) al,
            (select thread# thrd, max(sequence#) lhmax
               from v\$log_history
              where resetlogs_change#=(select resetlogs_change# from v\$database)
              group by thread#) lh
     where al.thrd = lh.thrd;
     
     prompt <b>Archived Log List:</b>
     column size format 999,999,999,999
     select a.thread#, a.name, a.dest_id, a.sequence#, a.blocks * a.block_size "size", a.creator, a.registrar, a.standby_dest, a.archived, a.applied, a.deleted,
            a.status, a.completion_time
      from v\$archived_log a;
     
     prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''archived_log'\'');">close</a>]</center><p></div>
     
     --archive_gap
     --
     prompt <div id="archive_gap" style="DISPLAY: none">
     prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archived Gap</b></font><hr align="left" width="460">
     
     select * from v\$archive_gap; 
     
     prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''archive_gap'\'');">close</a>]</center><p></div>
     
     --managed_standby
     --
     prompt <div id="managed_standby" style="DISPLAY: none">
     prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Dataguard Process</b></font><hr align="left" width="460">
     
     select process,status,client_process,thread#,sequence#,block#,active_agents,known_agents
       from v\$managed_standby;
     
     prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''managed_standby'\'');">close</a>]</center><p></div>
     
     --archive_dest_status
     --
     prompt <div id="archive_dest_status" style="DISPLAY: none">
     prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archive Dest Status</b></font><hr align="left" width="460">
     
     select dest_id id,database_mode db_mode,recovery_mode, 
            protection_mode,standby_logfile_count "SRLs",
            standby_logfile_active ACTIVE, 
            archived_seq# 
       from v\$archive_dest_status;
     
     prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''archive_dest_status'\'');">close</a>]</center><p></div>
     
     --archive_dest
     --
     prompt <div id="archive_dest" style="DISPLAY: none">
     prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Archive Dest</b></font><hr align="left" width="460">
     
     select dest_id "ID",destination,status,target,
            schedule,process,mountid  mid
       from v\$archive_dest order by dest_id;
     
     prompt <center>[<a class="noLink" href="javascript:ShowHideRegion('\''archive_dest'\'');">close</a>]</center><p></div>
       
     spool off
   
     set mark html off
     
     exit;
     EOF' > /dev/null 2 >&1
     ;;
     
hang)
     $ECHO "  |__ v\$wait_chains"  
     
     $SU - $ACCOUNT -c 'sqlplus -s /nolog <<EOF
     conn / as sysdba
     
     set mark html on
     spool /tmp/collect.32_wait_chain.html
     select *
       from (select '\''Current Process: '\'' || osid W_PROC,
                           '\''SID '\'' || i.instance_name INSTANCE,
                           '\''INST #: '\'' || instance INST,
                           '\''Blocking Process: '\'' || decode(blocker_osid, null, '\''<none>'\'', blocker_osid) ||  '\'' from Instance '\'' || blocker_instance blocker_proc,
                           '\''Number of waiters: '\'' || num_waiters waiters,
                           '\''Wait Event: '\'' || wait_event_text wait_event,
                           '\''P1: '\'' || p1 p1,
                           '\''P2: '\'' || p2 p2,
                           '\''P3: '\'' || p3 p3,
                           '\''Seconds in Wait: '\'' || in_wait_secs Seconds,
                           '\''Seconds Since Last Wait: '\'' || time_since_last_wait_secs sincelw,
                           '\''Wait Chain: '\'' || chain_id || '\'': '\'' || chain_signature chain_signature,
                           '\''Blocking Wait Chain: '\'' ||  decode(blocker_chain_id, null, '\''<none>'\'', blocker_chain_id) blocker_chain
                   from v\$wait_chains wc, v\$instance i
                 where wc.instance = i.instance_number(+)
                     and (num_waiters > 0 or   (blocker_osid is not null and in_wait_secs > 10))
       order by chain_id, num_waiters desc)
       where rownum < 101; 

       select *
          from (select '\''Current Process: '\'' || osid W_PROC,
                       '\''SID '\'' || i.instance_name instance,
                       '\''INST #: '\'' || instance INST,
                       '\''Blocking Process: '\'' ||  decode(blocker_osid, null, '\''<none>'\'', blocker_osid) || '\'' from Instance '\'' || blocker_instance BLOCKER_PROC,
                       '\''Number of waiters: '\'' || num_waiters waiters,
                       '\''Final Blocking Process: '\'' || decode(p.spid, null, '\''<none>'\'', p.spid) || '\'' from Instance '\'' || s.final_blocking_instance FBLOCKER_PROC,
                       '\''Program: '\'' || p.program image,
                       '\''Wait Event: '\'' || wait_event_text wait_event,
                       '\''P1: '\'' || wc.p1 p1,
                       '\''P2: '\'' || wc.p2 p2,
                       '\''P3: '\'' || wc.p3 p3,
                       '\''Seconds in Wait: '\'' || in_wait_secs Seconds,
                       '\''Seconds Since Last Wait: '\'' || time_since_last_wait_secs sincelw,
                       '\''Wait Chain: '\'' || chain_id || '\'': '\'' || chain_signature chain_signature,
                       '\''Blocking Wait Chain: '\'' ||  decode(blocker_chain_id, null, '\''<none>'\'', blocker_chain_id) blocker_chain
                  from v\$wait_chains wc,
                       gv\$session    s,
                       gv\$session    bs,
                       gv\$instance   i,
                       gv\$process    p
                 where wc.instance = i.instance_number(+)
                   and (wc.instance = s.inst_id(+) and wc.sid = s.sid(+) and  wc.sess_serial# = s.serial#(+))
                   and (s.inst_id = bs.inst_id(+) and  s.final_blocking_session = bs.sid(+))
                   and (bs.inst_id = p.inst_id(+) and bs.paddr = p.addr(+))
                   and (num_waiters > 0 or  (blocker_osid is not null and in_wait_secs > 10))
                 order by chain_id, num_waiters desc)
      where rownum < 101;
      spool off
     
     exit;
     
     EOF'
     
     $ECHO "  |___ hanganalyze"
     
     $SU - $ACCOUNT -c 'sqlplus -s /nolog <<EOF
     conn / as sysdba
     oradebug setmypid;
     oradebug unlimit;
     oradebug dump hanganalyze 3;
     oradebug tracefile_name;     
     exit;
     
     EOF'
     
     $ECHO "  |___ systemstate"
     
     $SU - $ACCOUNT -c 'sqlplus -s /nolog <<EOF
     conn / as sysdba
     oradebug setmypid;
     oradebug unlimit;
     oradebug dump systemstate 266;
     oradebug tracefile_name;
     exit;
     
     EOF'
     ;;
     
awrid)
     $SU - $ACCOUNT -c 'sqlplus -s /nolog <<EOF
     conn / as sysdba
     set heading off
     set feedback off
     column snap_id  format  9999999
     column dbid     format  999999999999
     column inst_num format  99
     column time     format  a20
     set line 100
     
     select snap_id, dbid, d.instance_number, to_char(begin_interval_time, '\''yyyy-mm-dd hh24:mi:ss'\'') time
       from dba_hist_snapshot d, v\$instance i'"
      where d.instance_number = i.instance_number
        and begin_interval_time between to_date('$BEGIN_DATE', 'yyyymmddhh24miss') 
                                    and to_date('$END_DATE', 'yyyymmddhh24miss')
      order by instance_number, snap_id;
     set heading on
     set feedback on
     exit;     
     EOF"
     ;;
     
awrrpt)             
     REPORT_TYPE="html"
     AWR_REPORT_NAME="/tmp/collect.${INST_NUM}_${BEGIN_DATE}_${END_DATE}_awr.${REPORT_TYPE}"
     ASH_REPORT_NAME="/tmp/collect.${INST_NUM}_${BEGIN_DATE}_${END_DATE}_ash.${REPORT_TYPE}"
     
     echo "  |___ collect.${INST_NUM}_${BEGIN_DATE}_${END_DATE}_awr.${REPORT_TYPE}..."
     echo "  |___ collect.${INST_NUM}_${BEGIN_DATE}_${END_DATE}_ash.${REPORT_TYPE}..."
     
     $SU - $ACCOUNT -c "sqlplus -s /nolog <<EOF
     conn / as sysdba
     define report_type ='$REPORT_TYPE';
     define bsnapid = $BEGIN_DATE;
     define esnapid = $END_DATE;
     define dbid = $DBID;
     define inst_num = $INST_NUM;
     define awr_report_name = '$AWR_REPORT_NAME';
     define ash_report_name = '$ASH_REPORT_NAME';
          
     set echo off;
     set veri off;
     set feedback off;
     set termout on;
     set heading off;
     
     variable dbid number;
     variable inst_num number;
     variable bid number;
     variable eid number;
     
     column ext new_value ext noprint
     column fn_name new_value fn_name noprint;
     column lnsz new_value lnsz noprint;
     select 'txt' ext from dual where lower('&report_type') = 'text';
     select 'html' ext from dual where lower('&report_type') = 'html';
     select 'awr_report_text' fn_name from dual where lower('&report_type') = 'text';
     select 'awr_report_html' fn_name from dual where lower('&report_type') = 'html';
     select '80' lnsz from dual where lower('&report_type') = 'text';
     select '1500' lnsz from dual where lower('&report_type') = 'html';
     
     set linesize &lnsz;
     
     set termout off;
     spool &awr_report_name;
     select output from table(dbms_workload_repository.&fn_name(&dbid, &inst_num,&bsnapid, &esnapid,0));     
     spool off;
     
     set echo off heading on underline on;
     column inst_num  heading \"Inst Num\"  new_value inst_num  format 99999      noprint;
     column inst_name heading \"Instance\"  new_value inst_name format a12        noprint;
     column db_name   heading \"DB Name\"   new_value db_name   format a12        noprint;
     column dbid      heading \"DB Id\"     new_value dbid      format 9999999999 noprint;

     select d.dbid            dbid,
            d.name            db_name,
            i.instance_number inst_num,
            i.instance_name   inst_name
       "'from v\$database d, v\$instance i;'"
       
     column btime new_value btime   noprint;
     column etime new_value etime   noprint;
     
     select to_char(begin_interval_time, 'yyyy-mm-dd hh24:mi:ss') btime from dba_hist_snapshot where dbid = &dbid and instance_number = &inst_num and snap_id = &bsnapid;
     select to_char(begin_interval_time, 'yyyy-mm-dd hh24:mi:ss') etime from dba_hist_snapshot where dbid = &dbid and instance_number = &inst_num and snap_id = &esnapid;
     
     set heading off
     
     spool &ash_report_name;
     
     select output from table(dbms_workload_repository.ash_report_html(l_dbid => &dbid, 
                                                                       l_inst_num => &inst_num,
                                                                       l_btime => to_date('&btime', 'yyyy-mm-dd hh24:mi:ss'),
                                                                       l_etime => to_date('&etime', 'yyyy-mm-dd hh24:mi:ss'), 
                                                                       l_options => 0, 
                                                                       l_slot_width => 0
                                                                      ));
     spool off                                                                       
     
     set termout on;
     clear columns sql;
     ttitle off;
     btitle off;
     repfooter off;
     
     undefine report_name
     undefine report_type
     undefine fn_name
     undefine lnsz
     exit;
     
     EOF"  >> /dev/null 2>&1
     ;;  
*)
     $ECHO "Unkown operator."
     ;;
esac

#clear space line 
sed -i "s/<br>//g" /tmp/collect.*.html > /dev/null 2>&1

#move html file to collecting diretory.
$MV /tmp/collect.*.html $CONF_PATH  > /dev/null 2>&1
