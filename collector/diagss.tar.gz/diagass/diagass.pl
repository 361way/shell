#!/usr/bin/perl

#NAME: diagass.pl
#VERSION: v1.2
#DESCRIPTION: diagass.pl is a tool that collects logs of db, crs, grid, asm and os for diagnosing about database issue. it help you 
#             collect data as more complete as possible in one time. it is main program, you can launch like:
#             ./diagass.pl --collect
#             ./diagass.pl --collect --crs
#             ./diagass.pl --collect --asm
#             ./diagass.pl --collect --perf
#             ./diagass.pl --collect --db --perf --begindate "<yyyy-mm-dd hh24:mi:ss>" --enddate "<yyyy-mm-dd hh24:mi:ss>"
#             ./diagaas.pl --h  for more detail.
# 
#CREATED:  xuanziqiao@huawei.com 2013-08-28
#
#MODIFIED: 
#          xuanziqiao@huawei.com 2013-09-10  avoid packaging the same trace file many times.
#          xuanziqiao@huawei.com 2013-10-10  ignored inexistent paths without exit program.
#          xuanziqiao@huawei.com 2013-10-12  (1) collect cluvfy output for crs. 
#                                            (2) fixed hostname string that contains one or more uppercase alphabets.
#
#          xuanziqiao@huawei.com 2013-10-26  don't colect views & awr\ash of database when it is unavailable.
#          xuanziqiao@huawei.com 2013-10-26  don't use parameter "--after-date" in tar command.
#          xuanziqiao@huawei.com 2013-11-25  fixed missing asm spfile.
#          xuanziqiao@huawei.com 2013-11-25  get /etc/oraInst.loc, /etc/oracle, $ORACLE_HOME/bin/oracle privilege & /var/log/.oracle privilege and contents.
#          xuanziqiao@huawei.com 2013-11-30  fixed missging database views, awr, ash & config files when ORACLE_BASE directory does not exist.
#          xuanziqiao@huawei.com 2013-12-26  add the option "current" in the command for a raising issue of performance.

use Sys::Hostname;
use Getopt::Long;
use POSIX;
use POSIX qw(strftime);
use File::Glob qw(:globally :case);
use File::Spec::Functions;
use File::Find ();
use DirHandle;
use Time::Local;
use constant TRUE  =>  "1";
use constant FALSE =>  "0";

# check if run as super user
my $superUser = "root";
my $usrname = getpwuid($<);
if ($usrname ne $superUser)
{
    printf("[ERROR] Script must be executed by $superUser\n");
    exit 1;
}

$HOSTNAME = hostname;
if ($HOSTNAME eq "")
{
    print "Set HOSTNAME environment variable and then re-invoke this script.\n";
    exit;
}

# If IP address, do not strip.
if ($HOSTNAME !~ /(\d{1,3}\.){3}\d{1,3}/)
{
  $HOSTNAME =~ s/^([^.]+)\..*/$1/; # strip domain name off of host

  #lowercase the hostname
  $HOSTNAME=lc($HOSTNAME);
}

$PLATFORM = $^O;

$HPUX = "hpux";
$LINUX = "linux";
$AIX = "aix";
$SOLARIS = "solaris";

if ($PLATFORM eq $HPUX) 
{
    $GZIP = "/usr/contrib/bin/gzip";
}
else 
{
    $GZIP = "/bin/gzip";
}

$MKDIR = "mkdir";
$COPY = "cp";
$TAR = "/bin/tar ";
$CF = "-cf";
$RF = "-rf";
$RM = "/bin/rm -rf";

#do not show any msg from os command on console.
$NOERRORSHOW = "> /dev/null 2>&1";


#database script name
$SQLSCRIPT = "db.sql";

# get command parameters
GetOptions( "collect" => \$collect,
            "analyze" => \$analyze,
            "db"      => \$db,
            "crs"     => \$crs,
            "asm"     => \$asm,  
            "os"      => \$os,
            "perf"    => \$perf,           
            "hang"    => \$hang,
            "conn"    => \$conn,
            "dg"      => \$dg,
            "begindate:s"  => \$begindate,
            "enddate:s"    => \$enddate,
            "current"      => \$current,
            "noinit"       => \$noinit,
            "oracle:s"     => \$oracle,
            "grid:s"       => \$grid,
            "oraclehome:s" => \$oraclehome,
            "oraclebase:s" => \$oraclebase,
            "dbuniquename:s" => \$dbuniquename,
            "oraclesid:s"    => \$oraclesid,
            "crshome:s"      => \$crshome,
            "gridbase:s"     => \$gridbase,
            "asmsid:s"       => \$asmsid,            
            "clean"          => \$clean,
            "help"           => \$help,
            "h"              => \$help
          );

# show help
if ( $help || (! $collect && ! $analyze && ! $clean) )
{
    help();
    exit 0;
}

$DB_STATUS = "";
$ORACLE_HOME = "";
$ORACLE_BASE = "";
$DB_UNIQUE_NAME = "";
$ORACLE_SID = "";
$ORA_CRS_HOME = "";
$ORA_GRID_BASE = "";
$ORA_ASM_SID = "";

our $CURRENT_PATH;

chop($CURRENT_PATH = `pwd`) || die "Can't find current directory: $!\n";
if (!(-w $CURRENT_PATH))
{ 
    print("Error: current directory $CURRENT_PATH is not writable\n");
    exit;
}

$COLLECT_STORE_PATH = "log";

if ( $clean )
{
    system( "${RM} ${CURRENT_PATH}/${COLLECT_STORE_PATH} ${NOERRORSHOW}");
    exit 0;
}

#get variables by using function "getenv.sh"
if ( ! $noinit )
{
    #$DEBUG =~ /on/ && print "process: noinit is not specified\n";
    my $envresult = system("sh -c \"${CURRENT_PATH}/getenv.sh ${grid} ${oracle}\"");

    if ( $envresult != 0 )
    {
        print "ORACLE environment variables failed to load!\n";
        exit;
    }
    
    #get variables
    getENV();
}
else
{   
    #$DEBUG =~ /on/ && print "process: noinit is specified!\n";
    #you can edit file "comm.config" in manual without specifying any value in comman line.
    getENV();
}

#when user specified some value, use it at first.
if ( $oraclehome && -e $oraclehome )
{
    $ORACLE_HOME = $oraclehome;
}

if ( $oraclebase && -e $oraclebase )
{
    $ORACLE_BASE = $oraclebase;
}

if ( $dbuniquename )
{
    $DB_UNIQUE_NAME = $dbuniquename;
}

if ( $oraclesid )
{
    $ORACLE_SID = $oraclesid;
}

if ( $crshome && -e $crshome )  
{
    $ORA_CRS_HOME = $crshome;
}

 if ( $asmsid )  
{
    $ORA_ASM_SID = $asmsid;
}

if ( $gridbase && -e $gridbase )  
{
    $ORA_GRID_BASE = $gridbase;
}   


#$DEBUG =~ /on/ && print "ORA_GRID_BASE: $ORA_GRID_BASE, ASM_SID: $ORA_ASM_SID\n";
#ORA_GRID_BASE is same to ORACLE BASE in 11gR1 
if ( ! $ORA_GRID_BASE && $ORA_ASM_SID )   
{
    $ORA_GRID_BASE = $ORACLE_BASE;
    
    #$DEBUG =~ /on/ && print "process: ORA_GRID_BASE: $ORA_GRID_BASE\n";
}

if ( $DB_UNIQUE_NAME eq "" )
{
    print "[WARNING] no DB_UNIQUE_NAME is specified or Database is not open, so try to get one. maybe you should set it by '--dbuniquename <value>'\n";
    $DB_UNIQUE_NAME = getDB_UNIQUE_NAME();
    
    if ( $DB_UNIQUE_NAME eq "" )
    {
        print "[WARNING] DB_UNIQUE_NAME is not found, you must specify '--dbuniquename <value>' in command, or db logs would not collected.\n";
    }
}    

if ( ! $grid )
{
    $grid = "grid";
}

if ( ! $oracle )
{
    $oracle = "oracle";
}

print "#\n";
print "#DATABBASE STATUS=$DB_STATUS  <======if the status is INVALID, then views, awr&ash reports of database will be not collected.\n";
print "#ORACLE ACCOUNT=$oracle\n";
print "#GI ACCOUNT=$grid\n";
print "#ORACLE_HOME=$ORACLE_HOME\n";
print "#ORACLE_BASE=$ORACLE_BASE\n";
print "#DB_UNIQUE_NAME=$DB_UNIQUE_NAME\n";
print "#ORACLE_SID=$ORACLE_SID\n";
print "#ORA_CRS_HOME=$ORA_CRS_HOME\n";
print "#ORA_GRID_BASE=$ORA_GRID_BASE\n";
print "#ORA_ASM_SID=$ORA_ASM_SID\n";
print "#\n";

#if all above environment variables are right, then start to collect.
validateVariables();

###command & global variables declare########################################
$CURRTIME = currentTime("%4d-%02d-%02dT%02d%02d%02d");
$MIDIGHT_OF_TODAY = currentTime("%4d-%02d-%02d");

# archive files in chunks to avoid command line length limits
# this is the limit for the command line filename list length
$FLISTLEN = 1024;

$COLLECTING_PATH = "Collect_${HOSTNAME}_${CURRTIME}";

#create dump diretory
$DUMPDIR = catfile($CURRENT_PATH, "${COLLECT_STORE_PATH}/${COLLECTING_PATH}");
system("${MKDIR} -p ${DUMPDIR}");

#copy temp data to DUMPDIR
system("${COPY} template.tar ${DUMPDIR}  ${NOERRORSHOW}; cd ${DUMPDIR}  ${NOERRORSHOW}; ${TAR} xvf template.tar ${NOERRORSHOW}; ${RM} template.tar  ${NOERRORSHOW};");
#create storage path
system("${MKDIR} -p ${DUMPDIR}/lg/database ${DUMPDIR}/lg/awr ${DUMPDIR}/lg/asm ${DUMPDIR}/lg/crs ${DUMPDIR}/lg/os ${NOERRORSHOW};  chmod  -R 777 ${DUMPDIR} ${NOERRORSHOW};");

# TARS
$DBTRACE_TAR = "dbTrace_$HOSTNAME.tar";
$DBALERTCONFIG_TAR = "dbData.$HOSTNAME.tar";

$ASMTRACE_TAR = "asmTrace_$HOSTNAME.tar";
$ASMALERTCONFIG_TAR = "asmData_$HOSTNAME.tar";

$CRSDATA_TAR = "crslog_$HOSTNAME.tar";
$OCRDATA_TAR = "ocrData_$HOSTNAME.tar";

$SYSLOG_TAR = "oslog_$HOSTNAME.tar";

$PACKAGE_NAME = "$COLLECTING_PATH.tar";

#
if ( $collect && (! $db && ! $crs && ! $asm && ! $os) )
{
    $all = true;
}

#the first date that issue raisd.
if ( ! $begindate )
{
    $begindate = "${MIDIGHT_OF_TODAY} 00:00:00";
}

# the end date that investigation
if ( ! $enddate )
{
    $enddate = strftime("%Y-%m-%d %H:%M:%S", localtime(time));
}


$BEGINDATE_IN_INTEGER = getDateLong("${begindate}");
$ENDDATE_IN_INTEGER = getDateLong($enddate);

if ( $collect )
{
    $aftertime = convertTime($begindate);
    $beforetime = convertTime($enddate);
        
    #cllocting database log & trace
    $dir = "${ORACLE_BASE}/diag/rdbms/${DB_UNIQUE_NAME}/${ORACLE_SID}/alert/";
    if ( $db || $all )
    {
        
        print "Collecting database trace files...\n";
        if ( -e $dir )
        {
            collectTraceFromAlert($dir, "${DUMPDIR}/${DBTRACE_TAR}", ${DBTRACE_TAR});
        }
        else
        {  
            print "[ERROR] Database alert diretory \"$dir\" dose not exist, database trace files not collected.\n";
        }
        
        print "Collecting database alert, spfile, listener.log, listener.ora, sqlnet.ora, init.ora....\n"; 
        my @files = collectDBconf();
        
        if ( @files )
        {
            # change to / to remove leading slashes
            chdir("/") || die "unable to change directory to /: $!\n";
        
            @cmd = (${TAR}, ${CF}, "${DUMPDIR}/${DBALERTCONFIG_TAR}", @files);
        
            system("@cmd");
             
            # change back to initial current directory
            chdir($DUMPDIR) || die "Unable to change directory back to $CURRENT_PATH: $!\n";
            system("${GZIP} ${DBALERTCONFIG_TAR}");
        }       
            
        #collect db views\config
        print "Collecting database instance views, parameters, profiler...\n";
        if ( $DB_STATUS ne "INVALID" )
        {
            system("sh -c \"${CURRENT_PATH}/dbcollect.sh ${oracle} dbconf ${DUMPDIR}/lg/database ${ORACLE_SID} ${CURRENT_PATH}/${SQLSCRIPT} ${aftertime} ${beforetime}\"");
        }
        else
        {
            print "  |___ Warning: Database or Instance not open or unavailable!\n";
        }
        
        #collect for performance            
        if ( $perf && $DB_STATUS ne "INVALID" )
        {
            print "Collecting awr & ash...\n";
            
            open(PIPE, "sh -c \"${CURRENT_PATH}/dbcollect.sh ${oracle} awrid '' '' ${CURRENT_PATH}/${SQLSCRIPT} ${aftertime} ${beforetime}\" |");
            @awrids = <PIPE>;
            
            #print "begin:${aftertime}, enddate: ${beforetime}", @awrids, "\n";
            
            if ( @awrids )
            {
                collectAWRnASH(\@awrids);
            }
            else
            {
                print "  |___ (No awr&asr report collected)\n";
            }
            
            #collect db views\config
            print "Collecting views for performance...\n";
            system("sh -c \"${CURRENT_PATH}/dbcollect.sh ${oracle} perf ${DUMPDIR}/lg/database ${ORACLE_SID} ${CURRENT_PATH}/${SQLSCRIPT} ${aftertime} ${beforetime}\"");
        }
        
        #collect for dg.
        if ( $dg && $DB_STATUS ne "INVALID" )
        {
            print "Collecting dataguard views...\n";
            
            system("sh -c \"${CURRENT_PATH}/dbcollect.sh ${oracle} dg '${DUMPDIR}/lg/database' '' ${CURRENT_PATH}/${SQLSCRIPT} ${aftertime} ${beforetime}\"");                
        }
        
        #collect for hanganalyze & systemstate
        if ( $hang && $DB_STATUS ne "INVALID" )
        {
            print "Collecting hanganalyze & systemstate(please wait for a moment)...\n";
            
            open(PIPE, "sh -c \"${CURRENT_PATH}/dbcollect.sh ${oracle} hang '${DUMPDIR}/lg/database' '' ${CURRENT_PATH}/${SQLSCRIPT} ${aftertime} ${beforetime}\" |"); 
            
            @tracefile_names = <PIPE>;
                            
            if ( @tracefile_names )
            {
                while ( $#tracefile_names >= 0 )
                {
                    $line = $tracefile_names[0];
                    if ( $line =~/\|/ )
                    {
                        print "$line";
                    }
                    
                    #trace file
                    if ( $line =~/trc/ )
                    {                            
                        chomp($line);
                        
                        if ( -f $line )
                        {   
                            print "    |___ $line\n";
                            system("$COPY ${line} ${DUMPDIR}"); 
                        }  
                    }
                    
                    shift @tracefile_names;
                }
            }
            
        } #collect for hanganalyze & systemstate.        
    } # end if ( $db || $all )
    
    #collecting asm log & trace
    if ( $asm || $all )
    {
        if ($ORA_ASM_SID)
        {
            $asmaccount = "";
            #11gR2
            if ( $ORA_GRID_BASE && -e $ORA_GRID_BASE && $ORA_GRID_BASE ne $ORACLE_BASE )
            {
                $dir = "${ORA_GRID_BASE}/diag/asm/+asm/${ORA_ASM_SID}/alert/";
                $asmaccount = $grid;
            }
            
            #11gR1
            else
            {
                $dir = "${ORACLE_BASE}/diag/asm/+asm/${ORA_ASM_SID}/alert/";
                $asmaccount = $oracle;
            }
        
            if ( -e $dir )
            {
                print "Collecting ASM trace files...\n";
                collectTraceFromAlert($dir, "${DUMPDIR}/${ASMTRACE_TAR}", $ASMTRACE_TAR);
               
                my @files = collectASMconf();
               
               if ( @files )
                {
                    # change to / to remove leading slashes
                    chdir("/") || die "unable to change directory to /: $!\n";
                
                    @cmd = (${TAR}, ${CF}, "${DUMPDIR}/${ASMALERTCONFIG_TAR}", @files);
                
                    system("@cmd");
                     
                    # change back to initial current directory
                    chdir($DUMPDIR) || die "Unable to change directory back to $CURRENT_PATH: $!\n";
                    system("${GZIP} ${ASMALERTCONFIG_TAR}");
                }
                
                #collect asm views\config                
                system("sh -c \"${CURRENT_PATH}/dbcollect.sh ${asmaccount} asmconf ${DUMPDIR}/lg/asm ${ORA_ASM_SID} ${CURRENT_PATH}/${SQLSCRIPT} ${aftertime} ${beforetime}\""); 
            }
            else
            {
                print "[ERROR] ASM alert diretory \"$dir\" dose not exist, ASM trace files will not be collected.\n";
            }
        }
    }
    
    #crs\\grid log & config
    if ( $crs || $all )
    {
        if ( $ORA_CRS_HOME && -e $ORA_CRS_HOME)
        {
             print "Collecting CRS logs... \n";
             collectCRSlog();
             
             # change back to initial current directory
             chdir($DUMPDIR) || die "Unable to change directory back to $DUMPDIR: $!\n";  
             
             if ( -f "${DUMPDIR}/${CRSDATA_TAR}" )
             {
                 system("${GZIP} ${CRSDATA_TAR}");
             }
                        
             collectCRSconf();            
        }
    }
    
    #collecting os log&config.
    if ( $os || $all )
    {
        collectsyslog();
    }
    
    #generateHTML
    print "Generating html data....\n";
    @db_list  = getFileNamesInDir("${DUMPDIR}/lg/database", ".txt\$|.html\$");
    @awr_list = getFileNamesInDir("${DUMPDIR}/lg/awr", ".html\$");
    @asm_list = getFileNamesInDir("${DUMPDIR}/lg/asm", ".txt\$|.html\$");
    @crs_list = getFileNamesInDir("${DUMPDIR}/lg/crs", ".txt\$");
    @os_list  = getFileNamesInDir("${DUMPDIR}/lg/os", ".txt\$");
    
    system("sh -c \"${CURRENT_PATH}/generateHTML.sh header ${DUMPDIR}/lg/tree.html\"");
    
    if (@db_list && ! @awr_list && ! @asm_list && ! @crs_list && ! @os_list )
    {
       $order = "last";
    }
    else
    {
       $order = "nolast";
    }
    generateHTMLData(\@db_list, "database", 1, $order);
    
    if (@awr_list && ! @asm_list && ! @crs_list && ! @os_list )
    {
       $order = "last";
    }
    else
    {
       $order = "nolast";
    }
    generateHTMLData(\@awr_list, "awr", 2, $order);
    
    if (@asm_list && ! @crs_list && ! @os_list )
    {
       $order = "last";
    }
    else
    {
       $order = "nolast";
    }
    
    generateHTMLData(\@asm_list, "asm", 3, $order);
    
    if (@crs_list && ! @os_list )
    {
       $order = "last";
    }
    else
    {
       $order = "nolast";
    }
    
    generateHTMLData(\@crs_list, "crs", 4, $order);
    
    generateHTMLData(\@os_list, "os", 5, "last");
    
    system("sh -c \"${CURRENT_PATH}/generateHTML.sh bottom ${DUMPDIR}/lg/tree.html\"");
        
    #tar&zip logs then remove \${DUMPDIR}
    print "Packaging collected logs...\n";
    chdir("${CURRENT_PATH}/${COLLECT_STORE_PATH}") || die "unable to change directory to /: $!\n";
    system("$TAR ${CF} ${PACKAGE_NAME} ${COLLECTING_PATH}");
    system("$GZIP ${PACKAGE_NAME}");
    system("$RM ${COLLECTING_PATH}");
    
    print ">>>>Finished. The package is:\n";
    print "--->${CURRENT_PATH}/${COLLECT_STORE_PATH}/Collect_${HOSTNAME}_${CURRTIME}.tar.gz\n";
    
}

#unimplement
if ( $analyze )
{
   #we will implement in further time.
   exit 0;
}


sub collectAWRnASH()
{
    my($awrid_ref) = @_;
    my @awrid = @$awrid_ref;
    
    if ( @awrid )
    {       
        $first = 0;
        $bsnapid = "";
        $esnapid = "";        
        
        my $finst_num = 0;
        
        while ( $#awrid >= 0 )
        {
            
            if ( $awrid[0] =~ /(\d+)\s+(\d+)\s+(\d+)\s+(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})/ )
            {
                my $snapid = $1;
                my $dbid   = $2;
                my $inst_num = $3;
                
                
                $snaptime = "$4-$5-$6 $7:$8:$9";                
                #print "old: $awrid[0], $snaptime, $snapid, $dbid, $inst_num\n";
                #print "$snaptime, $snapid, $dbid, $inst_num\n";
                
                #print "snpid: $id\n";   
                if ( $first == 0 )
                {
                    $bsnapid = $snapid;
                    $first = 1;
                    
                    $finst_num = $inst_num;                    
                }
                else
                {   
                    #first snapid and second snapid are belong to the same instance number.
                    if ( $finst_num == $inst_num )
                    {
                        $esnapid = $snapid;
                        $first = 0;
                    }
                    else
                    {
                        $bsnapid = $snapid;
                        $first = 1;
                    
                        $finst_num = $inst_num;
                    }
                }
                
                #collect awr report
                if ( $bsnapid ne "" && $esnapid ne "" && $bsnapid ne $esnapid )
                {  
                    system("sh -c \"${CURRENT_PATH}/dbcollect.sh ${oracle} awrrpt ${DUMPDIR}/lg/awr ${ORACLE_SID} ${CURRENT_PATH}/${SQLSCRIPT} ${bsnapid} ${esnapid} ${dbid} $inst_num\"");
                    $bsnapid = $esnapid;
                    $first = 1;
                }
            }
            
            shift @awrid;
        }
         #the last awr report.
         if ( $bsnapid ne "" && $esnapid ne "" && $bsnapid ne $esnapid )
         {
             system("sh -c \"${CURRENT_PATH}/dbcollect.sh ${oracle} awrrpt ${DUMPDIR}/lg/awr ${ORACLE_SID} ${CURRENT_PATH}/${SQLSCRIPT} ${bsnapid} ${esnapid} ${dbid} $inst_num\"");
             $bsnapid = $esnapid;
         }
    }
}


#generateHTMLData
sub generateHTMLData
{
    my($list, $catalog, $order, $last)  = @_;
    my @namelist = sort(@$list);
    
    #while ( $#namelist >= 0 )
    #{
    #    print "$list[0]\n";
    #    shift @list;
    #}
    
    if ( $#namelist >= 0 )
    {
        #bodyheader
        system("sh -c \"${CURRENT_PATH}/generateHTML.sh bodyheader ${DUMPDIR}/lg/tree.html ${last} ${catalog}/$namelist[0] $catalog $order\"");
        
        my $i = 0;
        my $num = @namelist;
         
        while( $#namelist >= 0 )
        {
            my $n = $order.$i++;
            @name = split(/\./, $namelist[0]);
            
            if ($i < ($num - 1))
            {
                
                system("sh -c \"${CURRENT_PATH}/generateHTML.sh bodydata ${DUMPDIR}/lg/tree.html ${last} ${catalog}/$namelist[0] $name[1] $n nolast\"");
            }
            else
            {
                system("sh -c \"${CURRENT_PATH}/generateHTML.sh bodydata ${DUMPDIR}/lg/tree.html ${last} ${catalog}/$namelist[0] $name[1] $n last\"");
            }
                        
            shift @namelist;
        }        
        
        #bodybottom
        system("sh -c \"${CURRENT_PATH}/generateHTML.sh bodybottom ${DUMPDIR}/lg/tree.html\"");
    }
}

# match non-core files for find command
sub noncore 
{
    my ($dev,$ino,$mode,$nlink,$uid,$gid);
    
    (($dev,$ino,$mode,$nlink,$uid,$gid) = lstat($_)) &&
    -f $_ &&
    ! /^core.*\z/s &&
    push @filelist, $File::Find::name;
}


# match all files for find command
sub allfiles 
{
    my ($dev,$ino,$mode,$nlink,$uid,$gid);

    (($dev,$ino,$mode,$nlink,$uid,$gid) = lstat($_)) &&
    -f $_ && ( stat $_)[9] >= $BEGINDATE_IN_INTEGER &&
    push @filelist, $File::Find::name;
}

sub collectCRSconf()
{
     
     print "Collecting OCR, Resources... \n";
     
     my $excute_account = "${oracle}";
       
     #11gR2
     if ( -e $ORA_GRID_BASE  && ( $ORA_GRID_BASE ne $ORACLE_BASE ) )
     {
         #set the operating account.
         $excute_account = "${grid}";
     
         print "  |__ ocrdump -local\n";
         system("${ORA_CRS_HOME}/bin/ocrdump -local ${DUMPDIR}/lg/crs/collect.01_ocrdump.txt 2>&1");
         
         print "  |__ crsctl stat res -t\n";
         system("${ORA_CRS_HOME}/bin/crsctl stat res -t > ${DUMPDIR}/lg/crs/collect.06_crsctl_stat_res-t.txt 2>&1");
         
         print "  |__ crsctl stat res -p\n";
         system("${ORA_CRS_HOME}/bin/crsctl stat res -p > ${DUMPDIR}/lg/crs/collect.06_crsctl_stat_res-p.txt 2>&1");
         
         print "  |__ crsctl stat res -t -init\n";         
         system("${ORA_CRS_HOME}/bin/crsctl stat res -t -init > ${DUMPDIR}/lg/crs/collect.06_crsctl_stat_res-t-init.txt 2>&1");
     }
     else
     {     
         print "  |__ ocrdump -local\n"; 
         system("${ORA_CRS_HOME}/bin/ocrdump ${DUMPDIR}/lg/crs/collect.01_ocrdump.txt 2>&1");
         
         print "  |__ crs_stat -u\n";
         system("${ORA_CRS_HOME}/bin/crs_stat -u > ${DUMPDIR}/lg/crs/collect.06_crs_stat-u.txt 2>&1");
         
         print "  |__ crs_stat -p\n";
         system("${ORA_CRS_HOME}/bin/crs_stat -p > ${DUMPDIR}/lg/crs/collect.06_crs_stat-p.txt 2>&1");
     }
     
     print "  |__ ocrcheck\n";
     system("${ORA_CRS_HOME}/bin/ocrcheck > ${DUMPDIR}/lg/crs/collect.02_ocrcheck.txt 2>&1");
     
     print "  |__ ocrconfig -showbackup\n";
     system("${ORA_CRS_HOME}/bin/ocrconfig -showbackup > ${DUMPDIR}/lg/crs/collect.03_ocrbackup.txt 2>&1");
     
     print "Collecting CRS configuration... \n";  
     
     print "  |__ olsnodes -n -i\n";
     system("${ORA_CRS_HOME}/bin/olsnodes -n -i > ${DUMPDIR}/lg/crs/collect.04_nodesinfo.txt 2>&1");
     
     print "  |__ crsctl check css\n";
     system("${ORA_CRS_HOME}/bin/crsctl check css > ${DUMPDIR}/lg/crs/collect.04_csscheck.txt 2>&1");
     
     print "  |__ crsctl check crs\n";
     system("${ORA_CRS_HOME}/bin/crsctl check crs > ${DUMPDIR}/lg/crs/collect.04_crscheck.txt 2>&1");
     
     print "  |__ crsctl check crsd\n";
     system("${ORA_CRS_HOME}/bin/crsctl check crsd > ${DUMPDIR}/lg/crs/collect.04_crsdcheck.txt 2>&1");
     
     print "  |__ crsctl check evmd\n";
     system("${ORA_CRS_HOME}/bin/crsctl check evmd > ${DUMPDIR}/lg/crs/collect.04_evmdcheck.txt 2>&1");
     
     print "  |__ crsctl check votedisk\n";
     system("${ORA_CRS_HOME}/bin/crsctl query css votedisk > ${DUMPDIR}/lg/crs/collect.05_votedisk.txt 2>&1");
     
     #11gR2
     if ( $ORA_CRS_HOME ne $ORACLE_HOME )
     {
         print "  |__ crsctl get proprity\n";
         system("${ORA_CRS_HOME}/bin/crsctl get css priority > ${DUMPDIR}/lg/crs/collect.05_priority.txt 2>&1");
     }
     
     print "  |__ crsctl get diagwait\n";
     system("${ORA_CRS_HOME}/bin/crsctl get css diagwait > ${DUMPDIR}/lg/crs/collect.05_diagwait.txt 2>&1");
     
     print "  |__ crsctl get disktimeout\n";
     system("${ORA_CRS_HOME}/bin/crsctl get css disktimeout > ${DUMPDIR}/lg/crs/collect.05_disktimeout.txt 2>&1");
     
     print "  |__ crsctl get misscount\n";
     system("${ORA_CRS_HOME}/bin/crsctl get css misscount > ${DUMPDIR}/lg/crs/collect.05_misscount.txt 2>&1");
     
     print "  |__ crsctl get reboottime\n";
     system("${ORA_CRS_HOME}/bin/crsctl get css reboottime > ${DUMPDIR}/lg/crs/collect.05_reboottime.txt 2>&1");
     
     print "  |__ crsctl check softwareversion\n";
     system("${ORA_CRS_HOME}/bin/crsctl query crs softwareversion > ${DUMPDIR}/lg/crs/collect.05_softwareversion.txt 2>&1");
     
     print "  |__ crsctl check activeversion\n";
     system("${ORA_CRS_HOME}/bin/crsctl query crs activeversion > ${DUMPDIR}/lg/crs/collect.05_activeversion.txt 2>&1");
     
     print "  |__ cluvfy stage -pre crsinst -n ${HOSTNAME} -verbose\n";        
     system("su - ${excute_account} -c \"${ORA_CRS_HOME}/bin/cluvfy stage -pre crsinst -n ${HOSTNAME} -verbose > ${DUMPDIR}/lg/crs/collect.05_cluvfy_pre_crsinst.txt 2>&1\"");
    
     print "  |__ cluvfy stage -post crsinst -n ${HOSTNAME} -verbose\n";
     system("su - ${excute_account} -c \"${ORA_CRS_HOME}/bin/cluvfy stage -post crsinst -n $HOSTNAME -verbose > ${DUMPDIR}/lg/crs/collect.05_cluvfy_post_crsinst.txt 2>&1\"");
     
     print "  |__ oifcfg iflist\n";
     system("${ORA_CRS_HOME}/bin/oifcfg iflist > ${DUMPDIR}/lg/crs/collect.07_iflist.txt 2>&1");
     
     print "  |__ oifcfg getif\n";
     system("${ORA_CRS_HOME}/bin/oifcfg getif > ${DUMPDIR}/lg/crs/collect.07_getif.txt 2>&1");     
}

#collecting crs logs for 11gR2
sub collectCRSlog()
{
    my @log_list;
    my $patchlogs;
    
    # alert file
    $alertfile = "${ORA_CRS_HOME}/log/${HOSTNAME}/alert${HOSTNAME}.log"; 
    
    #get the first 1000 line in alert file.    
    if ( -f $alertfile )
    {
        print "  |___ $alertfile...\n";
        #get last 1000 lines from alert
        system("tail -1000 $alertfile > ${DUMPDIR}/lg/crs/collect.00_alert.txt");
    }

    # logs under <crs home>/install/*.log
    opendir(LOG, catfile(${ORA_CRS_HOME}, "install"));
    @log_list = sort(grep(/.log$/, readdir(LOG)));
    closedir(LOG);
    
    if (scalar(@log_list) >= 1)
    {
        $patchlogs="${ORA_CRS_HOME}/install/\*.log";
    }
     
    # make install log file names relative to CRS home
    grep($_ = catfile("install", $_), @log_list);

    # change to CRS home to shorten archive path names for tar
    chdir($ORA_CRS_HOME) || die "unable to change directory to ${ORA_CRS_HOME}: $!\n";

    our @filelist;

    @filelist = @log_list;

    # Traverse desired directories
    File::Find::find({wanted => \&allfiles}, "log/${HOSTNAME}");
    File::Find::find({wanted => \&allfiles}, "cfgtoollogs");
    
    #show collected files.
    $i = 0;
    while ( $i < @filelist )
    {
        print "  |___ $filelist[$i++]\n";
    }
    
    $first_tar = 1;
    $opt = ${CF};
    
    while ($#filelist >= 0) 
    {
	@cmdlist = ();
        $cmdpos = 0;	 	# file # in cmdlist
        $cmdlistlen = 0;
        
        # put $FLISTLEN chars of filenames at a time into cmdlist
	while ($cmdlistlen < $FLISTLEN) 
	{
	    $cmdlist[$cmdpos++] = $filelist[0];
	    shift(@filelist);
            $cmdlistlen = length(join(' ', @cmdlist));
            last if(!defined($filelist[0])); 
	}
        
        #the first running tar with the option "-cf"
        if ( $first_tar == 1 )
        {
            $opt = ${CF};
            $first_tar = 0;
        }
        else
        {
            $opt = ${RF};
        }
        
        #don't need the switch --after-date
        @cmd = (${TAR}, ${opt}, "${DUMPDIR}/${CRSDATA_TAR}", @cmdlist, ${NOERRORSHOW});
        system("@cmd");
    }
    
    # archive remaining files
    if ($#filelist > 0) 
    {
        #don't need the switch --after-date
        @cmd = (${TAR}, ${RF}, "${DUMPDIR}/${CRSDATA_TAR}", @filelist, ${NOERRORSHOW} );
        system("@cmd");
    }
}

##collecting database config
sub collectDBconf()
{   
    my @files = ();
    
    #listener config & log
    $LISTENER_PATH = "${ORACLE_HOME}/network/admin";
    
    # change to CRS home to shorten archive path names for tar
    if ( -e $LISTENER_PATH)
    {
        print "  |___ $LISTENER_PATH/*.log, *.ora ...\n"; 
        chdir($LISTENER_PATH) || die "unable to change directory to ${LISTENER_PATH}: $!\n";    
        @files = getFilesInDir(${LISTENER_PATH}, "\.log\$|\.ora\$");
    }
    
    
    $ALERT_PATH = "${ORACLE_BASE}/diag/tnslsnr/${HOSTNAME}/listener/trace/listener.log";  
    
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n"; 
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    $ALERT_PATH = "${ORACLE_BASE}/diag/tnslsnr/${HOSTNAME}/listener_${HOSTNAME}/trace/listener_${HOSTNAME}.log";
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n"; 
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    #alert log
    $ALERT_PATH = "${ORACLE_BASE}/diag/rdbms/${DB_UNIQUE_NAME}/${ORACLE_SID}/trace/alert_${ORACLE_SID}.log";    
        
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n"; 
        system("tail -1000 $ALERT_PATH > ${DUMPDIR}/lg/database/collect.00_alert.txt");
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    #collecting spfile$ORACLE_SID.ora or init$ORACLE_SID.ora
    $ALERT_PATH = "${ORACLE_HOME}/dbs/spfile$ORACLE_SID.ora";
    
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n"; 
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    
    $ALERT_PATH = "${ORACLE_HOME}/dbs/init$ORACLE_SID.ora";
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n"; 
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    #get oracle instance config
    $ORAINST = "/etc/oraInst.loc";
    if ( -f $ORAINST )
    {
        print "  |___ $ORAINST...\n";
        grep(s#^/##, $ORAINST);    
        push @files, $ORAINST;
    }
    
    #get crs start config
    $CRS_START_CONFIG = "/etc/oracle";
    if ( -e $CRS_START_CONFIG )
    {
        print "  |___ $CRS_START_CONFIG...\n";
        grep(s#^/##, $CRS_START_CONFIG);    
        push @files, $CRS_START_CONFIG;
    }
    
    #get $ORACLE_HOME/bin/oracle priv.
    $ORACLE_PRIV = "$ORACLE_HOME/bin/oracle";
    if ( -f $ORACLE_PRIV )
    {
        print "  |___ $ORACLE_PRIV privs...\n";
        system("su - ${oracle} -c \"ls -l $ORACLE_HOME/bin/oracle > /tmp/collect.02_oracle_excutable_privs.txt\"");
        system("mv /tmp/collect.02_oracle_excutable_privs.txt ${DUMPDIR}/lg/database $NOERRORSHOW");
    }
    
    #get /var/tmp/.oracle priv & contents.
    $HIDE_CONFIG = "/var/tmp/.oracle";
    if ( -e $HIDE_CONFIG )
    {
        print "  |___ $HIDE_CONFIG privs and contents...\n";
        system("ls -la /var/tmp | grep \".oracle\" > /tmp/collect.03_oracle_hide_config.txt");
        system("ls -l $HIDE_CONFIG >> /tmp/collect.03_oracle_hide_config.txt");      
        system("mv /tmp/collect.03_oracle_hide_config.txt ${DUMPDIR}/lg/database $NOERRORSHOW");
    } 
    
    #ORACLE patches
    #get the lastest patch tool.
    @patch_paths = getFileNamesInDir("${ORACLE_HOME}", "^[O|o][P|p]atch");
    $PATCH = "";
    
    #print "@patch_paths\n";
    if ( @patch_paths > 0 )
    {
        my $time = (stat "${ORACLE_HOME}/${patch_paths[0]}")[9];
        while ( $#patch_paths >= 0 )
        {
             my $mtime = (stat "${ORACLE_HOME}/${patch_paths[0]}")[9];
             
             ###��Ϊ�ļ���
             if ( $mtime >= $time && -d "${ORACLE_HOME}/${patch_paths[0]}" )
             {
                 $PATCH = "${ORACLE_HOME}/${patch_paths[0]}";
             }
             
             shift @patch_paths;
        }
    }
    
    if ( $PATCH )
    {
        print "Collecting database patches...\n";  
        print "  |___ ${PATCH}/opatch lsinventory -all\n";  
        system("su - ${oracle} -c \"${PATCH}/opatch lsinventory -all > /tmp/collect.01_patches.txt 2>&1\"");         
        
    }
    
    #get oracle patches again.
    system("su - ${oracle} -c \"opatch lsinventory -all >> /tmp/collect.01_patches.txt 2>&1\"");
    system("mv /tmp/collect.01_patches.txt ${DUMPDIR}/lg/database $NOERRORSHOW");
    
    return @files;   
    
}

##collecting ASM config
sub collectASMconf()
{
    #listener config & log
    my @files = ();
    
    $LISTENER_PATH = "${ORA_CRS_HOME}/network/admin";
        
    # change to CRS home to shorten archive path names for tar
    if ( -e $LISTENER_PATH)
    {
        print "  |___ $LISTENER_PATH/*.log, *.ora ...\n";
        chdir($LISTENER_PATH) || die "unable to change directory to ${LISTENER_PATH}: $!\n";        
        @files = getFilesInDir(${LISTENER_PATH}, "\.log\$|\.ora\$");
    }
    
    #
    $ALERT_PATH = "${ORA_GRID_BASE}/diag/tnslsnr/${HOSTNAME}/listener/trace/listener.log";
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n";
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    $ALERT_PATH = "${ORA_GRID_BASE}/diag/tnslsnr/${HOSTNAME}/listener_${HOSTNAME}/trace/listener_${HOSTNAME}.log";
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n";
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    #alert log
    $ALERT_PATH = "${ORA_GRID_BASE}/diag/asm/+asm/${ORA_ASM_SID}/trace/alert_${ORA_ASM_SID}.log";
    #print "collectASMconf: $ALERT_PATH\n";
    
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n";
        system("tail -1000 $ALERT_PATH > ${DUMPDIR}/lg/asm/collect.00_alert.txt");
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    #collecting spfile$ORACLE_SID.ora or init$ORA_ASM_SID.ora
    $ALERT_PATH = "${ORA_CRS_HOME}/dbs/spfile$ORA_ASM_SID.ora";
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n";
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    
    $ALERT_PATH = "${ORA_CRS_HOME}/dbs/init$ORA_ASM_SID.ora";
    if ( -f $ALERT_PATH )
    {
        print "  |___ $ALERT_PATH...\n";
        grep(s#^/##, $ALERT_PATH);    
        push @files, $ALERT_PATH;
    }
    
    return @files; 
}

##collect trace files for database&asm
sub collectTraceFromAlert()
{    
    $alert_path = shift;
    $tarpath = shift;
    $tarname = shift;
    
    @tracelist = ();
    $counter = 0;
    
    my @namelist = getFileNamesInDir($alert_path, "\.xml\$");
    
    while ( $#namelist >= 0 )
    {
        $alertFileName = catfile($alert_path, $namelist[0]); 
        
        #those files will be ignored that their mtime less then begindate.
        my $mtime = (stat $alertFileName)[9] or next;
        if ( $mtime < $BEGINDATE_IN_INTEGER )
        {   
            #print "$alertFileName\n";
            #print strftime("mtime: %Y-%m-%d %H:%M:%S\n", localtime($mtime));
            
            shift @namelist;
            next;
        }
  
        open (FILE_DBALERT, $alertFileName) || die ("Could not open file");
        while ( $line = <FILE_DBALERT> )
        {
            #find the flag <msg time> and when the date of record is great than or equal to the date specified by user, we will get those message. 
            if ( $line =~/msg time/  )
            {
                
                $pattern = '(\d{4})-(\d{2})-(\d{2})\w+(\d{2}):(\d{2}):(\d{2}).(\d{3})';
                
                if ( $line =~ /$pattern/ )
                {                
                    $dt = getDateLong("$1-$2-$3 $4:$5:$6");
                    if ( $BEGINDATE_IN_INTEGER <= $dt && $dt <= $ENDDATE_IN_INTEGER )
                    {
                        $needRecord = 1;
                    }
                } 
             }    
            
            #now we need to find those trace files.
            if ( $needRecord == 1 )
            {
                $posDetail_path = index($line, "detail_path");
                $posEnd         = index($line, ">");
        
                if ($posDetail_path != -1 && $posEnd != -1)
                {
                    $detailpath = substr($line, $posDetail_path + 13, $posEnd - ($posDetail_path + 13 + 1));
                    
                    #if file exists, record it.
                    if ( -e $detailpath )
                    { 
                        print "  |___ $detailpath\n";
                        
                        # remove leading slashes to convert absolute pathnames to relative
                        #  paths to avoid warning messages from TAR.
                       
                        grep(s#^/##, $detailpath);
                        
                        if ( ! grep(/^$detailpath/, $tracelist) )
                        {
                            $tracelist[$counter++] = $detailpath;
                            #print "$detailpath\n";
                        }
                    }
                }
            
                $posIncident = index($line, "Incident details in");
                $posEnd      = index($line, "trc");
                
                if ( $posIncident != -1 && $posEnd > $posIncident)
                {
                    $incidentPath = substr($line, $posIncident + 21, $posEnd + 3 - ($posIncident + 21));
                    
                    if ( -e $incidentPath )
                    {
                        print "  |___ $incidentPath\n";
                        
                        # remove leading slashes to convert absolute pathnames to relative
                        #  paths to avoid warning messages from TAR.
                        grep(s#^/##, $incidentPath);
                        
                        if ( ! grep(/^$incidentPath/, $tracelist) )
                        {
                            $tracelist[$counter++] = $incidentPath; 
                            #print "$incidentPath\n";
                        }
                    }
                }  
               
                $posError = index($line, "Errors in file");
                $posEnd   = index($line, "trc");
                if ( $posError != -1 && $posEnd > $posError)
                {
                    $errorFilePath = substr($line, $posError + 15, $posEnd + 3 - ($posError + 15));
                    
                    if ( -e $errorFilePath )
                    {
                        
                        print "  |___ $errorFilePath\n";
                        
                        # remove leading slashes to convert absolute pathnames to relative
                        #  paths to avoid warning messages from TAR.
                        grep(s#^/##, $errorFilePath);
                        
                        #new file will be added. 
                        if ( ! grep(/^$errorFilePath/, $tracelist) )
                        {
                            $tracelist[$counter++] = $errorFilePath;
                            #print "$errorFilePath\n";
                        }
                    }
                }
                
                $posSysDump = index($line, "System State dumped to trace file");
                $posEnd   = index($line, "trc");
                if ( $posSysDump != -1 && $posEnd > $posSysDump)
                {
                    $errorFilePath = substr($line, $posSysDump + 34, $posEnd + 3 - ($posSysDump + 34));
                    
                    if ( -e $errorFilePath )
                    {
                        
                        print "  |___ $errorFilePath\n";
                        
                        # remove leading slashes to convert absolute pathnames to relative
                        #  paths to avoid warning messages from TAR.
                        grep(s#^/##, $errorFilePath);
                        
                        #new file will be added. 
                        if ( ! grep(/^$errorFilePath/, $tracelist) )
                        {
                            $tracelist[$counter++] = $errorFilePath;
                            #print "$errorFilePath\n";
                        }
                    }
                }
                 
           }
        
           #indicate the end of the block <msg time></msg time>
           if ( $line =~/<\/msg>/ )
           {  
               $needRecord = 0;
           }
        }
        
        close(FILE_DBALERT);
        shift @namelist;
    }
           
    #clean duplicate file names from array.
    my %saw;
    my @result = grep(!$saw{$_}++, @tracelist);
        
    if ( @result )
    {        
        # change to / to remove leading slashes
        chdir("/") || die "unable to change directory to /: $!\n";
        
        $first_tar = 1;        
        $opt = ${CF};
        
         while ($#result >= 0) 
        {
	    @cmdlist = ();
            $cmdpos = 0;	 	# file # in cmdlist
            $cmdlistlen = 0;
            
            # put $FLISTLEN chars of filenames at a time into cmdlist
	    while ($cmdlistlen < $FLISTLEN) 
	    {
	        $cmdlist[$cmdpos++] = $result[0];
	        shift(@result);
                $cmdlistlen = length(join(' ', @cmdlist));
                last if(!defined($result[0])); 
	    }
            
            if ($first_tar == 1)
            {
                $opt = ${CF};
                $first_tar = 0;
            }
            else
            {                
                $opt = ${RF};
            }
                    
            @cmd = (${TAR}, ${opt}, "${tarpath}", @cmdlist, ${NOERRORSHOW});
            system("@cmd");
        }
        
        # archive remaining files
        if ($#result > 0) 
        {
            @cmd = (${TAR}, ${RF}, "${tarpath}", @result, ${NOERRORSHOW});
            system("@cmd");
        }   
                  
        # change back to initial current directory
        chdir($DUMPDIR) || die "Unable to change directory back to $CURRENT_PATH: $!\n";
        
        system("${GZIP} ${tarname}");
    }
    else
    {
        print "  |___ (No trace files collected)\n";
    }
}

#collect os system logs
#linux system logs are /var/log/messages*
#solaris system logs are /var/adm/messages*
#hpux system logs are /var/adm/syslog/*syslog.log
#aix system logs are /var/adm/ras/*log*
#  System log locations should be defined as absolute paths, but
#   will be converted to relative paths for archiving
sub collectsyslog() 
{
  my @file_list = ();
  my $system_logs = "";
  my $current_log = "";
  
  if ($PLATFORM eq $LINUX)
  {
    @file_list = getFilesInDir("/var/log/", "messages*");
    
    $system_logs = "/var/log/messages*";
    $current_log = "/var/log/messages";
  }
  elsif ($PLATFORM eq $SOLARIS)
  {
    @file_list = getFilesInDir("/var/adm/", "messages*");
    
    $system_logs = "/var/adm/messages*";
    $current_log = "/var/log/messages";
  }
  elsif ($PLATFORM eq $HPUX)
  {
    @file_list = getFilesInDir("/var/adm/syslog/", "syslog.log\$");
    
    $system_logs = "/var/adm/syslog/*syslog.log";
    $current_log = "/var/log/syslog.log";
  }
  elsif ($PLATFORM eq $AIX)
  {
    @file_list = getFilesInDir("/var/adm/ras/", "log");
    
    $system_logs = "/var/adm/ras/*log*";
    $current_log = "/var/adm/ras/errlog";
  }
  else
  {
    print "No support for OS log collection on this platform: $PLATFORM\n";
    return;
  }
  
  print "Collecting OS logs...\n";
  print "  |___ $system_logs\n";
  
  #get crsctl trace files.    
  my @crsclt_list = getFilesInDir("/tmp", "crsctl.*");
  
  push(@file_list, @crsclt_list);  
  
  print "Collecting OS configuration...\n";
  
  #collects information for performance and the issue raising now.
  if ( $perf && $current)
  {
      $PERF = "perf";
  }
  
  $oslog_path = "${DUMPDIR}/lg/os";  
  system("sh -c \"${CURRENT_PATH}/oscollect.sh ${oslog_path} ${PERF}\""); 

  #get the last 1000 lines from os log.
  system ("tail -1000 $current_log > ${DUMPDIR}/lg/os/collect.00_log.txt");

  # change to / to remove leading slashes 
  chdir("/") || die "unable to change directory to /: $!\n";
    
  @cmdlist = (); 
  $cmdpos = 0;
  
  while ($#file_list >= 0) 
  {
      $filename = $file_list[0];             
  
      # select the files that their mtime greater then begindate
      if ( -f $filename && (stat $filename)[9] >= $BEGINDATE_IN_INTEGER )
      {
          $cmdlist[$cmdpos++] = $filename;
      }
      	    
      shift(@file_list);
  }
  
  if ($#cmdlist >= 0)
  {
      #don't need the switch --after-date
      @cmd = (${TAR}, ${CF}, "${DUMPDIR}/${SYSLOG_TAR}", @cmdlist, ${NOERRORSHOW});
      
      system("@cmd");
     
      # change back to initial current directory
      chdir($DUMPDIR) || die "Unable to change directory back to $DUMPDIR: $!\n";
     
      system("${GZIP} ${SYSLOG_TAR}");  
  }
  
}

sub getDB_UNIQUE_NAME()
{
    @dir_names = getFileNamesInDir("${ORACLE_BASE}/diag/rdbms");  
    $db_unique_name = "";
    
    #$DEBUG =~/on/ && print "getDB_UNIQUE_NAME: dirnames:", @dir_names, "\n";
    #print "getDB_UNIQUE_NAME:", @dir_names, "\n";
    
    if ( @dir_names > 0 )
    {
        while ( $#dir_names >= 0 )
        {
            $alert_path = "${ORACLE_BASE}/diag/rdbms/$dir_names[0]/$ORACLE_SID/alert/log.xml";
                        
            #print "getDB_UNIQUE_NAME: $alert_path\n";            
            #$DEBUG =~ /on/ && print "getDB_UNIQUE_NAME: $alert_print, mtime: $mtime, begin_date: $BEGINDATE_IN_INTEGER\n";
            if ( -f $alert_path && (stat $alert_path)[9] >= $BEGINDATE_IN_INTEGER )
            {
                $db_unique_name = $dir_names[0];
            }            
            
            shift @dir_names;
        }   
    }
        
    return $db_unique_name;
}

sub getFilesInDir()
{
    my $dir = shift;
    my $pattern = shift;
    
    if ( ! -e $dir )
    {
        print "[ERROR] the diretory \"$dir\" dose not exists.\n";
        return ();
    }

    my $dh = DirHandle->new($dir); #die "can't opendir $dir: $!";
    
    my @files = grep {  !/^\./   } 
                grep  { /$pattern/ }
                $dh->read();
    
    grep(s#^/##, $dir);
    
    @list = ();
    
    while( $#files >= 0 )
    {
        push @list, catfile("${dir}/", $files[0]);
        shift @files; 
    }
    
    return @list; 
}

sub getFileNamesInDir()
{
    my $dir = shift;
    my $pattern = shift;
    
    
    #$DEBUG =~/on/ && print "getFileNamesInDir: $dir\n";
    
    if ( ! -e $dir )
    {
        print "[ERROR] the diretory \"$dir\" dose not exists.\n";
        return ();
    }

    my $dh = DirHandle->new($dir); #die "can't opendir $dir: $!";
    
    my @filenames = grep {  !/^\./   } 
                grep  { /$pattern/ }
                $dh->read();
    
    #if ( $DEBUG =~/on/ )
    #{
    #    $i = 0;
    #    while ( $i < @filenames )
    #    {
    #        print "getFileNamesInDir: $filenames[$i++]\n";
    #    }
    #}
    
    return @filenames; 
}

#get variables
#get database status
sub getENV()
{
    open(VAR, "./comm.config") or die("Can not open comm.config");

    while ( $line = <VAR> )
    {
        
        @keyvalue = split("=", $line);
        
        if ($keyvalue[0] =~ /DB_STATUS/ )
        {
            $DB_STATUS = $keyvalue[1]; 
             chomp($DB_STATUS);
        }
        
        if ( $keyvalue[0] =~ /ORACLE_HOME/ )
        {
             $ORACLE_HOME = $keyvalue[1]; 
             chomp($ORACLE_HOME);
        }
        elsif( $keyvalue[0] =~ /ORACLE_BASE/ )
        {
             $ORACLE_BASE = $keyvalue[1];
             chomp($ORACLE_BASE);
        }
        elsif ( $keyvalue[0] =~ /DB_UNIQUE_NAME/ )
        { 
             $DB_UNIQUE_NAME = $keyvalue[1];
             chomp($DB_UNIQUE_NAME);
        }
        elsif ( $keyvalue[0] =~ /ORACLE_SID/ )
        {
             $ORACLE_SID = $keyvalue[1];
             chomp($ORACLE_SID);
        }
        elsif ( $keyvalue[0] =~ /ORA_CRS_HOME/ )
        {
             $ORA_CRS_HOME = $keyvalue[1];
             chomp($ORA_CRS_HOME);
        }
        elsif( $keyvalue[0] =~ /ORA_ASM_SID/ )
        {
             $ORA_ASM_SID = $keyvalue[1];
             chomp($ORA_ASM_SID);
        }
        elsif( $keyvalue[0] =~ /ORA_GRID_BASE/ )
        {
             $ORA_GRID_BASE = $keyvalue[1];
             chomp($ORA_GRID_BASE);
        }
    }

    close(VAR);
}

#time transfer integer, it used to compare.
sub getDateLong()
{
    $_ = shift;
    /(\d\d\d\d)-(\d\d)-(\d\d)\s+(\d+):(\d+):(\d+)/  or 
    /(\d\d\d\d)-(\d\d)-(\d\d)\s+(\d+):(\d+):(\d+)/  or die "Not a date $_";

    $mday = $3;
    $mon = $2 - 1;
    $year = $1 - 1900;
    ($h, $m, $s) = ($4, $5, $6);
    return timelocal($s,$m,$h,$mday,$mon,$year) || die ($dt);
}

#
# currentTime 
# getlocal time for use in filenames
#
sub currentTime()   
{
     
    $format = shift;
    
    ($sec,$min,$hour,$day,$month,$year,$wday,$yday,$isdst) = localtime();

    $year += 1900;
    $month += 1;
    return sprintf($format, $year, $month, $day, $hour, $min, $sec);

}

# convertTime
sub convertTime   
{
    my $timetoconvert = shift;
    
    #print "convertTime: $timetoconvert\n";
    
    # if time is not passed, get the local time 
    if ($timetoconvert eq "")
    {
        ($sec,$min,$hour,$day,$month,$year,$wday,$yday,$isdst) = localtime();
        
        $year += 1900;
        
        return"$year$month$day$hour$min$sec";
    }
    else 
    {
        if ( $timetoconvert =~ /(\d\d\d\d)-(\d\d)-(\d\d)\s+(\d+):(\d+):(\d+)/ )
        {             
            return "$1$2$3$4$5$6";
        }
    }
    
    #print "convertTime: $result\n";
    #return $result;   
}

sub validateVariables
{
    while (1)
    {
        # display the prompt
        print "Are you sure all above items[Yes] or [No], defult [Y]: ";
        chomp (my $get = <>);
        if ( $get eq 'N' || $get eq 'n' || $get eq 'No' || $get eq 'NO' || $get eq 'no' )
        {
            print "*NOTE: if any item above error, please specify in command or edit comm.config then run again with --noinit. see HELP for more detail.\n";
            
            exit;
        }
        elsif( $get eq '' || $get eq 'Y' || $get eq 'y' || $get eq 'yes' || $get eq 'Yes' || $get eq 'YES' )
        {
            last;
        }
        else
        {
            print "[$get]error input.\n";
        }
    }
}
          
#
sub help()
{
    print "diagass\n";
    print "   --collect\n";
    print "        [--db]      Collecting alert, trace files, config files, pfile\\spfile and db views for database.\n";
    print "        [--crs]     Collecting crs logs, ocr, oifcfg, status of crs resources\n";
    print "        [--asm]     Collecting alert,trace files, config files, pfile\\spfile views for asm instance.\n";
    print "        [--os]      Collecting os log, kernel, host, network, sar, and so on.\n";
    print "\n";
    print "        Note: If all of above options ignored, then collecting all.\n";
    print "\n";
    print "        [--perf]   Collecting awr,ash,sqlplan,history sqlplan for performance issue.\n";
    print "        [--hang]   Collecting systemstate,hanganalyze,short stack.\n";
    print "        [--dg]     Collecting views about dataguard.\n";
    print "\n";
    print "        [--begindate]\n";
    print "            [<yyyy-mm-dd hh24:mi:ss>] The date issue raised, if empty, the default is the early morning of current day.\n";
    print "        [--enddate]\n";
    print "            [<yyyy-mm-dd hh24:mi:ss>] The end of date of investigation, if empty, the default is current time.\n";
    print "\n";
    print "        [--current] The issue is raising now, specified the option for os performane like netstat, vmstat, iostat.\n";
    print "        [--noinit]    Do not collect environment variables, you need to edit comm.config or setting one or more\n";
    print "                      than the following parameters.\n";
    print "        [--oracle]\n";
    print "           [<oracle>] The default OS account of installing database sofware is oracle, you do not need to setting it\n";
    print "                      in the most case,  but if the account is not oracle, you must set, or diagass can not \n";
    print "                      collecting any log about database\n";
    print "        [--grid]\n";
    print "           [<grid>]   The default OS account of install crs sofware is grid, you do not need to setting\n";
    print "                      it in the most case,  but if the account is not grid, you must set, or diagass can\n";
    print "                      not collecting any log about grid\n";
    print "        [--oraclehome]\n";
    print "           [<\$ORACLE_HOME>] Get it automatically, but if you find it is empty, you must set it or diagass can not\n";
    print "                            collec any log about database.\n";
    print "        [--oraclebase]\n";
    print "           [<\$ORACLE_BASE>] Get it automatically, but if you find it is empty, you must set it or diagass can not collect\n";
    print "                             any log about database.\n";    
    print "        [--dbuniquename]\n";
    print "           [<db_unique_name>] When database is open or nomount, diagass can got it from database, but if database is close, \n";
    print "                              diagass use $ORACLE_SID as db_unique_name at first. if <\$ORACLE_HOME>/diag/rdbms/\$ORACLE_BASE \n";
    print "                              does not exist, then try to get one in the diretory <\$ORACLE_BASE>/diag/rdbms/, so the value\n";
    print "                              might be not right one, if you find the DB_UNIQUE_NAME is empty on console, you need to set it.\n";
    print "        [--oraclesid]\n";
    print "           [<\$ORACLE_SID>]   Get it automatically, but if you find it is empty, you must set it or diagass can not collect \n";
    print "                              any log about database.\n";
    print "        [--crshome]\n";
    print "           [<\$ORA_CRS_HOME> or \$ORACLE_HOME of grid] Get it automatically, but if you find it is empty, you must set it or \n";
    print "                                                     diagass can not collect any log about grid.\n";
    print "        [--gridbase]\n";
    print "           [$ORACLE_BASE of grid] Get it automatically, but if you find it is empty, you must set it or \n";
    print "                                                     diagass can not collect any log about grid.\n";
    print "        [--asmid]\n";
    print "           [<\$ORACLE_SID> of asm instance] Get it automatically, but if you find it is empty, you must set it or diagass can\n"; 
    print "                                           not collect any log about asm instance.\n";
    print "\n";    
    print "   --analyze       Unimplement\n";
    print "   --clean         Clean the diretory \"log\"\n";
    print "   --help          Show help\n";
    print "   --h             Show help\n";
    
    exit 0; 
}