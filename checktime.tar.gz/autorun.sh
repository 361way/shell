#!/usr/bin/expect

if {$argc!=4} {
echo  "Usage: $argv0 {Array IP} {User} {Password} {CMD}\n\n"
exit
}

set IP [lindex $argv 0]
set User [lindex $argv 1]
set Password [lindex $argv 2]
set CMD [lindex $argv 3]
#add by litao 90006394
#for encrypt password
#set Password [ exec /opt/dms/linux-addon/dms_decrypt $Password ]

spawn ssh $User@$IP
expect {
	"Password:" {
		#exec sleep 1
		send "${Password}\r"
		}
	"password:" {
		#exec sleep 1
		send "${Password}\r"
		}		
	"*continue connecting*" {
			 #exec sleep 1
			 send "yes\r"
			 expect { 
			 	  "*Password:" {
				                exec sleep 1
		 		                send "${Password}\r"
		 		               }
		 		  "*password:" {
				                exec sleep 1
		 		                send "${Password}\r"
		 		               }             
		 		}	 
			 }
	#����ssh�޷���¼ʱ
        "Host key verification failed" {
                send_user "\nCannot SSH to Array!\n"
                exit
        }
}

expect {
"*Password*" { send_user "\n1:Password error!\n"
               exit
             }
"*Permission denied*" { send_user "\n1:Password error!\n"
               exit  
            }           
"*logining in*" { send_user "\n2:Repeated login!\n"
              exit
            }
"*already*" { send_user "\n2:Repeated login!\n"
              exit
            }            
"*password error*" { send_user "\n2:Unauthorized user!\n"
              exit
            }                
"Error: Too many users" { send_user "\n3:exceed 32 user!\n"
              exit
            }                           
"OceanStor: $User>" { send "${CMD}\r"
                    }
"$User:/>" { send "${CMD}\r"
                    }                    
}

expect 	"*>"  { 
               send "exit\r" 
               }
       
expect { 
	"*closed*" {exit }
         "*sure to exit*" { send "y\r"    
                                  }             
        }       
  
expect "*closed*" 
exit   
