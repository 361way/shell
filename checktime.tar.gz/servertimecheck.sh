#!/bin/sh
rm result/servertime.result
rm log/debug.log

while read serverinfo; do
	sp=${serverinfo:0:1}
	if [ $sp == '#' ]; then
		continue
	fi

	IP1=`echo $serverinfo | awk -F',' '{print $1}'`
	USER1=`echo $serverinfo | awk -F',' '{print $2}'`
	PASSWD1=`echo $serverinfo | awk -F',' '{print $3}'`

	echo "Starting to check ${IP1}............."
./autorun.sh $IP1 $USER1 $PASSWD1 'showsys' >> log/debug.log
	TIME=`./autorun.sh $IP1 $USER1 $PASSWD1 'showsys' |grep -A14 'showsys' | grep 'Time'`
	
	TIMEALL=`echo $TIME| awk -F '|' '{print $2}'`
	#TIME=`./autorun.sh $IP1 $USER1 $PASSWD1 'showsys' | grep 'System Time'`
	echo  "${IP1}------->${TIMEALL}" >> result/servertime.result
	 echo "End to check ${IP1}............."
done < serverinfo.list
